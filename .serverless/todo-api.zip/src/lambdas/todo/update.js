/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchExecuteStatementCommand": () => (/* binding */ BatchExecuteStatementCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var BatchExecuteStatementCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(BatchExecuteStatementCommand, _super);
    function BatchExecuteStatementCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    BatchExecuteStatementCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "BatchExecuteStatementCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchExecuteStatementInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchExecuteStatementOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    BatchExecuteStatementCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0BatchExecuteStatementCommand)(input, context);
    };
    BatchExecuteStatementCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0BatchExecuteStatementCommand)(output, context);
    };
    return BatchExecuteStatementCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchGetItemCommand.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchGetItemCommand.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchGetItemCommand": () => (/* binding */ BatchGetItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var BatchGetItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(BatchGetItemCommand, _super);
    function BatchGetItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    BatchGetItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "BatchGetItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchGetItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchGetItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    BatchGetItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0BatchGetItemCommand)(input, context);
    };
    BatchGetItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0BatchGetItemCommand)(output, context);
    };
    return BatchGetItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchWriteItemCommand.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchWriteItemCommand.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchWriteItemCommand": () => (/* binding */ BatchWriteItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var BatchWriteItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(BatchWriteItemCommand, _super);
    function BatchWriteItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    BatchWriteItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "BatchWriteItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchWriteItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.BatchWriteItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    BatchWriteItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0BatchWriteItemCommand)(input, context);
    };
    BatchWriteItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0BatchWriteItemCommand)(output, context);
    };
    return BatchWriteItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteItemCommand.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteItemCommand.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteItemCommand": () => (/* binding */ DeleteItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var DeleteItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(DeleteItemCommand, _super);
    function DeleteItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    DeleteItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "DeleteItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.DeleteItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.DeleteItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    DeleteItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0DeleteItemCommand)(input, context);
    };
    DeleteItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0DeleteItemCommand)(output, context);
    };
    return DeleteItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteStatementCommand.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteStatementCommand.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExecuteStatementCommand": () => (/* binding */ ExecuteStatementCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var ExecuteStatementCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(ExecuteStatementCommand, _super);
    function ExecuteStatementCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    ExecuteStatementCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "ExecuteStatementCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ExecuteStatementInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ExecuteStatementOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    ExecuteStatementCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0ExecuteStatementCommand)(input, context);
    };
    ExecuteStatementCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0ExecuteStatementCommand)(output, context);
    };
    return ExecuteStatementCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteTransactionCommand.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteTransactionCommand.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExecuteTransactionCommand": () => (/* binding */ ExecuteTransactionCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var ExecuteTransactionCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(ExecuteTransactionCommand, _super);
    function ExecuteTransactionCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    ExecuteTransactionCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "ExecuteTransactionCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ExecuteTransactionInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ExecuteTransactionOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    ExecuteTransactionCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0ExecuteTransactionCommand)(input, context);
    };
    ExecuteTransactionCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0ExecuteTransactionCommand)(output, context);
    };
    return ExecuteTransactionCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/GetItemCommand.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/GetItemCommand.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetItemCommand": () => (/* binding */ GetItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var GetItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(GetItemCommand, _super);
    function GetItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    GetItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "GetItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.GetItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.GetItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    GetItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0GetItemCommand)(input, context);
    };
    GetItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0GetItemCommand)(output, context);
    };
    return GetItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/PutItemCommand.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/PutItemCommand.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PutItemCommand": () => (/* binding */ PutItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var PutItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(PutItemCommand, _super);
    function PutItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    PutItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "PutItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.PutItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.PutItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    PutItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0PutItemCommand)(input, context);
    };
    PutItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0PutItemCommand)(output, context);
    };
    return PutItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/QueryCommand.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/QueryCommand.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QueryCommand": () => (/* binding */ QueryCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var QueryCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(QueryCommand, _super);
    function QueryCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    QueryCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "QueryCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.QueryInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.QueryOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    QueryCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0QueryCommand)(input, context);
    };
    QueryCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0QueryCommand)(output, context);
    };
    return QueryCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ScanCommand.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ScanCommand.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanCommand": () => (/* binding */ ScanCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var ScanCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(ScanCommand, _super);
    function ScanCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    ScanCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "ScanCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ScanInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.ScanOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    ScanCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0ScanCommand)(input, context);
    };
    ScanCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0ScanCommand)(output, context);
    };
    return ScanCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactGetItemsCommand.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactGetItemsCommand.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactGetItemsCommand": () => (/* binding */ TransactGetItemsCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var TransactGetItemsCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(TransactGetItemsCommand, _super);
    function TransactGetItemsCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    TransactGetItemsCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "TransactGetItemsCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.TransactGetItemsInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.TransactGetItemsOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    TransactGetItemsCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0TransactGetItemsCommand)(input, context);
    };
    TransactGetItemsCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0TransactGetItemsCommand)(output, context);
    };
    return TransactGetItemsCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactWriteItemsCommand.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactWriteItemsCommand.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactWriteItemsCommand": () => (/* binding */ TransactWriteItemsCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var TransactWriteItemsCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(TransactWriteItemsCommand, _super);
    function TransactWriteItemsCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    TransactWriteItemsCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "TransactWriteItemsCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.TransactWriteItemsInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.TransactWriteItemsOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    TransactWriteItemsCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0TransactWriteItemsCommand)(input, context);
    };
    TransactWriteItemsCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0TransactWriteItemsCommand)(output, context);
    };
    return TransactWriteItemsCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateItemCommand.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateItemCommand.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateItemCommand": () => (/* binding */ UpdateItemCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-serde */ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");
/* harmony import */ var _protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../protocols/Aws_json1_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js");





var UpdateItemCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(UpdateItemCommand, _super);
    function UpdateItemCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        return _this;
    }
    UpdateItemCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        this.middlewareStack.use((0,_aws_sdk_middleware_serde__WEBPACK_IMPORTED_MODULE_0__.getSerdePlugin)(configuration, this.serialize, this.deserialize));
        var stack = clientStack.concat(this.middlewareStack);
        var logger = configuration.logger;
        var clientName = "DynamoDBClient";
        var commandName = "UpdateItemCommand";
        var handlerExecutionContext = {
            logger: logger,
            clientName: clientName,
            commandName: commandName,
            inputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.UpdateItemInputFilterSensitiveLog,
            outputFilterSensitiveLog: _models_models_0__WEBPACK_IMPORTED_MODULE_3__.UpdateItemOutputFilterSensitiveLog,
        };
        var requestHandler = configuration.requestHandler;
        return stack.resolve(function (request) {
            return requestHandler.handle(request.request, options || {});
        }, handlerExecutionContext);
    };
    UpdateItemCommand.prototype.serialize = function (input, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.serializeAws_json1_0UpdateItemCommand)(input, context);
    };
    UpdateItemCommand.prototype.deserialize = function (output, context) {
        return (0,_protocols_Aws_json1_0__WEBPACK_IMPORTED_MODULE_4__.deserializeAws_json1_0UpdateItemCommand)(output, context);
    };
    return UpdateItemCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamoDBServiceException": () => (/* binding */ DynamoDBServiceException)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");


var DynamoDBServiceException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(DynamoDBServiceException, _super);
    function DynamoDBServiceException(options) {
        var _this = _super.call(this, options) || this;
        Object.setPrototypeOf(_this, DynamoDBServiceException.prototype);
        return _this;
    }
    return DynamoDBServiceException;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__.ServiceException));



/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArchivalSummaryFilterSensitiveLog": () => (/* binding */ ArchivalSummaryFilterSensitiveLog),
/* harmony export */   "AttributeDefinitionFilterSensitiveLog": () => (/* binding */ AttributeDefinitionFilterSensitiveLog),
/* harmony export */   "AttributeValue": () => (/* binding */ AttributeValue),
/* harmony export */   "AttributeValueFilterSensitiveLog": () => (/* binding */ AttributeValueFilterSensitiveLog),
/* harmony export */   "AttributeValueUpdateFilterSensitiveLog": () => (/* binding */ AttributeValueUpdateFilterSensitiveLog),
/* harmony export */   "AutoScalingPolicyDescriptionFilterSensitiveLog": () => (/* binding */ AutoScalingPolicyDescriptionFilterSensitiveLog),
/* harmony export */   "AutoScalingPolicyUpdateFilterSensitiveLog": () => (/* binding */ AutoScalingPolicyUpdateFilterSensitiveLog),
/* harmony export */   "AutoScalingSettingsDescriptionFilterSensitiveLog": () => (/* binding */ AutoScalingSettingsDescriptionFilterSensitiveLog),
/* harmony export */   "AutoScalingSettingsUpdateFilterSensitiveLog": () => (/* binding */ AutoScalingSettingsUpdateFilterSensitiveLog),
/* harmony export */   "AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog": () => (/* binding */ AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog),
/* harmony export */   "AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog": () => (/* binding */ AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog),
/* harmony export */   "BackupDescriptionFilterSensitiveLog": () => (/* binding */ BackupDescriptionFilterSensitiveLog),
/* harmony export */   "BackupDetailsFilterSensitiveLog": () => (/* binding */ BackupDetailsFilterSensitiveLog),
/* harmony export */   "BackupInUseException": () => (/* binding */ BackupInUseException),
/* harmony export */   "BackupNotFoundException": () => (/* binding */ BackupNotFoundException),
/* harmony export */   "BackupSummaryFilterSensitiveLog": () => (/* binding */ BackupSummaryFilterSensitiveLog),
/* harmony export */   "BackupType": () => (/* binding */ BackupType),
/* harmony export */   "BackupTypeFilter": () => (/* binding */ BackupTypeFilter),
/* harmony export */   "BatchExecuteStatementInputFilterSensitiveLog": () => (/* binding */ BatchExecuteStatementInputFilterSensitiveLog),
/* harmony export */   "BatchExecuteStatementOutputFilterSensitiveLog": () => (/* binding */ BatchExecuteStatementOutputFilterSensitiveLog),
/* harmony export */   "BatchGetItemInputFilterSensitiveLog": () => (/* binding */ BatchGetItemInputFilterSensitiveLog),
/* harmony export */   "BatchGetItemOutputFilterSensitiveLog": () => (/* binding */ BatchGetItemOutputFilterSensitiveLog),
/* harmony export */   "BatchStatementErrorCodeEnum": () => (/* binding */ BatchStatementErrorCodeEnum),
/* harmony export */   "BatchStatementErrorFilterSensitiveLog": () => (/* binding */ BatchStatementErrorFilterSensitiveLog),
/* harmony export */   "BatchStatementRequestFilterSensitiveLog": () => (/* binding */ BatchStatementRequestFilterSensitiveLog),
/* harmony export */   "BatchStatementResponseFilterSensitiveLog": () => (/* binding */ BatchStatementResponseFilterSensitiveLog),
/* harmony export */   "BatchWriteItemInputFilterSensitiveLog": () => (/* binding */ BatchWriteItemInputFilterSensitiveLog),
/* harmony export */   "BatchWriteItemOutputFilterSensitiveLog": () => (/* binding */ BatchWriteItemOutputFilterSensitiveLog),
/* harmony export */   "BillingModeSummaryFilterSensitiveLog": () => (/* binding */ BillingModeSummaryFilterSensitiveLog),
/* harmony export */   "CancellationReasonFilterSensitiveLog": () => (/* binding */ CancellationReasonFilterSensitiveLog),
/* harmony export */   "CapacityFilterSensitiveLog": () => (/* binding */ CapacityFilterSensitiveLog),
/* harmony export */   "ConditionCheckFilterSensitiveLog": () => (/* binding */ ConditionCheckFilterSensitiveLog),
/* harmony export */   "ConditionFilterSensitiveLog": () => (/* binding */ ConditionFilterSensitiveLog),
/* harmony export */   "ConditionalCheckFailedException": () => (/* binding */ ConditionalCheckFailedException),
/* harmony export */   "ConsumedCapacityFilterSensitiveLog": () => (/* binding */ ConsumedCapacityFilterSensitiveLog),
/* harmony export */   "ContinuousBackupsDescriptionFilterSensitiveLog": () => (/* binding */ ContinuousBackupsDescriptionFilterSensitiveLog),
/* harmony export */   "ContinuousBackupsUnavailableException": () => (/* binding */ ContinuousBackupsUnavailableException),
/* harmony export */   "ContributorInsightsSummaryFilterSensitiveLog": () => (/* binding */ ContributorInsightsSummaryFilterSensitiveLog),
/* harmony export */   "CreateBackupInputFilterSensitiveLog": () => (/* binding */ CreateBackupInputFilterSensitiveLog),
/* harmony export */   "CreateBackupOutputFilterSensitiveLog": () => (/* binding */ CreateBackupOutputFilterSensitiveLog),
/* harmony export */   "CreateGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* binding */ CreateGlobalSecondaryIndexActionFilterSensitiveLog),
/* harmony export */   "CreateGlobalTableInputFilterSensitiveLog": () => (/* binding */ CreateGlobalTableInputFilterSensitiveLog),
/* harmony export */   "CreateGlobalTableOutputFilterSensitiveLog": () => (/* binding */ CreateGlobalTableOutputFilterSensitiveLog),
/* harmony export */   "CreateReplicaActionFilterSensitiveLog": () => (/* binding */ CreateReplicaActionFilterSensitiveLog),
/* harmony export */   "CreateReplicationGroupMemberActionFilterSensitiveLog": () => (/* binding */ CreateReplicationGroupMemberActionFilterSensitiveLog),
/* harmony export */   "CreateTableInputFilterSensitiveLog": () => (/* binding */ CreateTableInputFilterSensitiveLog),
/* harmony export */   "CreateTableOutputFilterSensitiveLog": () => (/* binding */ CreateTableOutputFilterSensitiveLog),
/* harmony export */   "CsvOptionsFilterSensitiveLog": () => (/* binding */ CsvOptionsFilterSensitiveLog),
/* harmony export */   "DeleteBackupInputFilterSensitiveLog": () => (/* binding */ DeleteBackupInputFilterSensitiveLog),
/* harmony export */   "DeleteBackupOutputFilterSensitiveLog": () => (/* binding */ DeleteBackupOutputFilterSensitiveLog),
/* harmony export */   "DeleteFilterSensitiveLog": () => (/* binding */ DeleteFilterSensitiveLog),
/* harmony export */   "DeleteGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* binding */ DeleteGlobalSecondaryIndexActionFilterSensitiveLog),
/* harmony export */   "DeleteItemInputFilterSensitiveLog": () => (/* binding */ DeleteItemInputFilterSensitiveLog),
/* harmony export */   "DeleteItemOutputFilterSensitiveLog": () => (/* binding */ DeleteItemOutputFilterSensitiveLog),
/* harmony export */   "DeleteReplicaActionFilterSensitiveLog": () => (/* binding */ DeleteReplicaActionFilterSensitiveLog),
/* harmony export */   "DeleteReplicationGroupMemberActionFilterSensitiveLog": () => (/* binding */ DeleteReplicationGroupMemberActionFilterSensitiveLog),
/* harmony export */   "DeleteRequestFilterSensitiveLog": () => (/* binding */ DeleteRequestFilterSensitiveLog),
/* harmony export */   "DeleteTableInputFilterSensitiveLog": () => (/* binding */ DeleteTableInputFilterSensitiveLog),
/* harmony export */   "DeleteTableOutputFilterSensitiveLog": () => (/* binding */ DeleteTableOutputFilterSensitiveLog),
/* harmony export */   "DescribeBackupInputFilterSensitiveLog": () => (/* binding */ DescribeBackupInputFilterSensitiveLog),
/* harmony export */   "DescribeBackupOutputFilterSensitiveLog": () => (/* binding */ DescribeBackupOutputFilterSensitiveLog),
/* harmony export */   "DescribeContinuousBackupsInputFilterSensitiveLog": () => (/* binding */ DescribeContinuousBackupsInputFilterSensitiveLog),
/* harmony export */   "DescribeContinuousBackupsOutputFilterSensitiveLog": () => (/* binding */ DescribeContinuousBackupsOutputFilterSensitiveLog),
/* harmony export */   "DescribeContributorInsightsInputFilterSensitiveLog": () => (/* binding */ DescribeContributorInsightsInputFilterSensitiveLog),
/* harmony export */   "DescribeContributorInsightsOutputFilterSensitiveLog": () => (/* binding */ DescribeContributorInsightsOutputFilterSensitiveLog),
/* harmony export */   "DescribeEndpointsRequestFilterSensitiveLog": () => (/* binding */ DescribeEndpointsRequestFilterSensitiveLog),
/* harmony export */   "DescribeEndpointsResponseFilterSensitiveLog": () => (/* binding */ DescribeEndpointsResponseFilterSensitiveLog),
/* harmony export */   "DescribeExportInputFilterSensitiveLog": () => (/* binding */ DescribeExportInputFilterSensitiveLog),
/* harmony export */   "DescribeExportOutputFilterSensitiveLog": () => (/* binding */ DescribeExportOutputFilterSensitiveLog),
/* harmony export */   "DescribeGlobalTableInputFilterSensitiveLog": () => (/* binding */ DescribeGlobalTableInputFilterSensitiveLog),
/* harmony export */   "DescribeGlobalTableOutputFilterSensitiveLog": () => (/* binding */ DescribeGlobalTableOutputFilterSensitiveLog),
/* harmony export */   "DescribeGlobalTableSettingsInputFilterSensitiveLog": () => (/* binding */ DescribeGlobalTableSettingsInputFilterSensitiveLog),
/* harmony export */   "DescribeGlobalTableSettingsOutputFilterSensitiveLog": () => (/* binding */ DescribeGlobalTableSettingsOutputFilterSensitiveLog),
/* harmony export */   "DescribeImportInputFilterSensitiveLog": () => (/* binding */ DescribeImportInputFilterSensitiveLog),
/* harmony export */   "DescribeImportOutputFilterSensitiveLog": () => (/* binding */ DescribeImportOutputFilterSensitiveLog),
/* harmony export */   "DescribeKinesisStreamingDestinationInputFilterSensitiveLog": () => (/* binding */ DescribeKinesisStreamingDestinationInputFilterSensitiveLog),
/* harmony export */   "DescribeKinesisStreamingDestinationOutputFilterSensitiveLog": () => (/* binding */ DescribeKinesisStreamingDestinationOutputFilterSensitiveLog),
/* harmony export */   "DescribeLimitsInputFilterSensitiveLog": () => (/* binding */ DescribeLimitsInputFilterSensitiveLog),
/* harmony export */   "DescribeLimitsOutputFilterSensitiveLog": () => (/* binding */ DescribeLimitsOutputFilterSensitiveLog),
/* harmony export */   "DescribeTableInputFilterSensitiveLog": () => (/* binding */ DescribeTableInputFilterSensitiveLog),
/* harmony export */   "DescribeTableOutputFilterSensitiveLog": () => (/* binding */ DescribeTableOutputFilterSensitiveLog),
/* harmony export */   "DescribeTableReplicaAutoScalingInputFilterSensitiveLog": () => (/* binding */ DescribeTableReplicaAutoScalingInputFilterSensitiveLog),
/* harmony export */   "DescribeTableReplicaAutoScalingOutputFilterSensitiveLog": () => (/* binding */ DescribeTableReplicaAutoScalingOutputFilterSensitiveLog),
/* harmony export */   "DescribeTimeToLiveInputFilterSensitiveLog": () => (/* binding */ DescribeTimeToLiveInputFilterSensitiveLog),
/* harmony export */   "DescribeTimeToLiveOutputFilterSensitiveLog": () => (/* binding */ DescribeTimeToLiveOutputFilterSensitiveLog),
/* harmony export */   "DuplicateItemException": () => (/* binding */ DuplicateItemException),
/* harmony export */   "EndpointFilterSensitiveLog": () => (/* binding */ EndpointFilterSensitiveLog),
/* harmony export */   "ExecuteStatementInputFilterSensitiveLog": () => (/* binding */ ExecuteStatementInputFilterSensitiveLog),
/* harmony export */   "ExecuteStatementOutputFilterSensitiveLog": () => (/* binding */ ExecuteStatementOutputFilterSensitiveLog),
/* harmony export */   "ExecuteTransactionInputFilterSensitiveLog": () => (/* binding */ ExecuteTransactionInputFilterSensitiveLog),
/* harmony export */   "ExecuteTransactionOutputFilterSensitiveLog": () => (/* binding */ ExecuteTransactionOutputFilterSensitiveLog),
/* harmony export */   "ExpectedAttributeValueFilterSensitiveLog": () => (/* binding */ ExpectedAttributeValueFilterSensitiveLog),
/* harmony export */   "ExportConflictException": () => (/* binding */ ExportConflictException),
/* harmony export */   "ExportDescriptionFilterSensitiveLog": () => (/* binding */ ExportDescriptionFilterSensitiveLog),
/* harmony export */   "ExportFormat": () => (/* binding */ ExportFormat),
/* harmony export */   "ExportNotFoundException": () => (/* binding */ ExportNotFoundException),
/* harmony export */   "ExportStatus": () => (/* binding */ ExportStatus),
/* harmony export */   "ExportSummaryFilterSensitiveLog": () => (/* binding */ ExportSummaryFilterSensitiveLog),
/* harmony export */   "ExportTableToPointInTimeInputFilterSensitiveLog": () => (/* binding */ ExportTableToPointInTimeInputFilterSensitiveLog),
/* harmony export */   "ExportTableToPointInTimeOutputFilterSensitiveLog": () => (/* binding */ ExportTableToPointInTimeOutputFilterSensitiveLog),
/* harmony export */   "FailureExceptionFilterSensitiveLog": () => (/* binding */ FailureExceptionFilterSensitiveLog),
/* harmony export */   "GetFilterSensitiveLog": () => (/* binding */ GetFilterSensitiveLog),
/* harmony export */   "GetItemInputFilterSensitiveLog": () => (/* binding */ GetItemInputFilterSensitiveLog),
/* harmony export */   "GetItemOutputFilterSensitiveLog": () => (/* binding */ GetItemOutputFilterSensitiveLog),
/* harmony export */   "GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog": () => (/* binding */ GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog),
/* harmony export */   "GlobalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* binding */ GlobalSecondaryIndexDescriptionFilterSensitiveLog),
/* harmony export */   "GlobalSecondaryIndexFilterSensitiveLog": () => (/* binding */ GlobalSecondaryIndexFilterSensitiveLog),
/* harmony export */   "GlobalSecondaryIndexInfoFilterSensitiveLog": () => (/* binding */ GlobalSecondaryIndexInfoFilterSensitiveLog),
/* harmony export */   "GlobalSecondaryIndexUpdateFilterSensitiveLog": () => (/* binding */ GlobalSecondaryIndexUpdateFilterSensitiveLog),
/* harmony export */   "GlobalTableAlreadyExistsException": () => (/* binding */ GlobalTableAlreadyExistsException),
/* harmony export */   "GlobalTableDescriptionFilterSensitiveLog": () => (/* binding */ GlobalTableDescriptionFilterSensitiveLog),
/* harmony export */   "GlobalTableFilterSensitiveLog": () => (/* binding */ GlobalTableFilterSensitiveLog),
/* harmony export */   "GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog": () => (/* binding */ GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog),
/* harmony export */   "GlobalTableNotFoundException": () => (/* binding */ GlobalTableNotFoundException),
/* harmony export */   "IdempotentParameterMismatchException": () => (/* binding */ IdempotentParameterMismatchException),
/* harmony export */   "ImportConflictException": () => (/* binding */ ImportConflictException),
/* harmony export */   "ImportNotFoundException": () => (/* binding */ ImportNotFoundException),
/* harmony export */   "ImportStatus": () => (/* binding */ ImportStatus),
/* harmony export */   "ImportSummaryFilterSensitiveLog": () => (/* binding */ ImportSummaryFilterSensitiveLog),
/* harmony export */   "ImportTableDescriptionFilterSensitiveLog": () => (/* binding */ ImportTableDescriptionFilterSensitiveLog),
/* harmony export */   "ImportTableInputFilterSensitiveLog": () => (/* binding */ ImportTableInputFilterSensitiveLog),
/* harmony export */   "ImportTableOutputFilterSensitiveLog": () => (/* binding */ ImportTableOutputFilterSensitiveLog),
/* harmony export */   "IndexNotFoundException": () => (/* binding */ IndexNotFoundException),
/* harmony export */   "InputCompressionType": () => (/* binding */ InputCompressionType),
/* harmony export */   "InputFormat": () => (/* binding */ InputFormat),
/* harmony export */   "InputFormatOptionsFilterSensitiveLog": () => (/* binding */ InputFormatOptionsFilterSensitiveLog),
/* harmony export */   "InternalServerError": () => (/* binding */ InternalServerError),
/* harmony export */   "InvalidEndpointException": () => (/* binding */ InvalidEndpointException),
/* harmony export */   "InvalidExportTimeException": () => (/* binding */ InvalidExportTimeException),
/* harmony export */   "InvalidRestoreTimeException": () => (/* binding */ InvalidRestoreTimeException),
/* harmony export */   "ItemCollectionMetricsFilterSensitiveLog": () => (/* binding */ ItemCollectionMetricsFilterSensitiveLog),
/* harmony export */   "ItemCollectionSizeLimitExceededException": () => (/* binding */ ItemCollectionSizeLimitExceededException),
/* harmony export */   "ItemResponseFilterSensitiveLog": () => (/* binding */ ItemResponseFilterSensitiveLog),
/* harmony export */   "KeySchemaElementFilterSensitiveLog": () => (/* binding */ KeySchemaElementFilterSensitiveLog),
/* harmony export */   "KeysAndAttributesFilterSensitiveLog": () => (/* binding */ KeysAndAttributesFilterSensitiveLog),
/* harmony export */   "KinesisDataStreamDestinationFilterSensitiveLog": () => (/* binding */ KinesisDataStreamDestinationFilterSensitiveLog),
/* harmony export */   "KinesisStreamingDestinationInputFilterSensitiveLog": () => (/* binding */ KinesisStreamingDestinationInputFilterSensitiveLog),
/* harmony export */   "KinesisStreamingDestinationOutputFilterSensitiveLog": () => (/* binding */ KinesisStreamingDestinationOutputFilterSensitiveLog),
/* harmony export */   "LimitExceededException": () => (/* binding */ LimitExceededException),
/* harmony export */   "ListBackupsInputFilterSensitiveLog": () => (/* binding */ ListBackupsInputFilterSensitiveLog),
/* harmony export */   "ListBackupsOutputFilterSensitiveLog": () => (/* binding */ ListBackupsOutputFilterSensitiveLog),
/* harmony export */   "ListContributorInsightsInputFilterSensitiveLog": () => (/* binding */ ListContributorInsightsInputFilterSensitiveLog),
/* harmony export */   "ListContributorInsightsOutputFilterSensitiveLog": () => (/* binding */ ListContributorInsightsOutputFilterSensitiveLog),
/* harmony export */   "ListExportsInputFilterSensitiveLog": () => (/* binding */ ListExportsInputFilterSensitiveLog),
/* harmony export */   "ListExportsOutputFilterSensitiveLog": () => (/* binding */ ListExportsOutputFilterSensitiveLog),
/* harmony export */   "ListGlobalTablesInputFilterSensitiveLog": () => (/* binding */ ListGlobalTablesInputFilterSensitiveLog),
/* harmony export */   "ListGlobalTablesOutputFilterSensitiveLog": () => (/* binding */ ListGlobalTablesOutputFilterSensitiveLog),
/* harmony export */   "ListImportsInputFilterSensitiveLog": () => (/* binding */ ListImportsInputFilterSensitiveLog),
/* harmony export */   "ListImportsOutputFilterSensitiveLog": () => (/* binding */ ListImportsOutputFilterSensitiveLog),
/* harmony export */   "ListTablesInputFilterSensitiveLog": () => (/* binding */ ListTablesInputFilterSensitiveLog),
/* harmony export */   "ListTablesOutputFilterSensitiveLog": () => (/* binding */ ListTablesOutputFilterSensitiveLog),
/* harmony export */   "ListTagsOfResourceInputFilterSensitiveLog": () => (/* binding */ ListTagsOfResourceInputFilterSensitiveLog),
/* harmony export */   "ListTagsOfResourceOutputFilterSensitiveLog": () => (/* binding */ ListTagsOfResourceOutputFilterSensitiveLog),
/* harmony export */   "LocalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* binding */ LocalSecondaryIndexDescriptionFilterSensitiveLog),
/* harmony export */   "LocalSecondaryIndexFilterSensitiveLog": () => (/* binding */ LocalSecondaryIndexFilterSensitiveLog),
/* harmony export */   "LocalSecondaryIndexInfoFilterSensitiveLog": () => (/* binding */ LocalSecondaryIndexInfoFilterSensitiveLog),
/* harmony export */   "ParameterizedStatementFilterSensitiveLog": () => (/* binding */ ParameterizedStatementFilterSensitiveLog),
/* harmony export */   "PointInTimeRecoveryDescriptionFilterSensitiveLog": () => (/* binding */ PointInTimeRecoveryDescriptionFilterSensitiveLog),
/* harmony export */   "PointInTimeRecoverySpecificationFilterSensitiveLog": () => (/* binding */ PointInTimeRecoverySpecificationFilterSensitiveLog),
/* harmony export */   "PointInTimeRecoveryUnavailableException": () => (/* binding */ PointInTimeRecoveryUnavailableException),
/* harmony export */   "ProjectionFilterSensitiveLog": () => (/* binding */ ProjectionFilterSensitiveLog),
/* harmony export */   "ProvisionedThroughputDescriptionFilterSensitiveLog": () => (/* binding */ ProvisionedThroughputDescriptionFilterSensitiveLog),
/* harmony export */   "ProvisionedThroughputExceededException": () => (/* binding */ ProvisionedThroughputExceededException),
/* harmony export */   "ProvisionedThroughputFilterSensitiveLog": () => (/* binding */ ProvisionedThroughputFilterSensitiveLog),
/* harmony export */   "ProvisionedThroughputOverrideFilterSensitiveLog": () => (/* binding */ ProvisionedThroughputOverrideFilterSensitiveLog),
/* harmony export */   "PutFilterSensitiveLog": () => (/* binding */ PutFilterSensitiveLog),
/* harmony export */   "PutItemInputFilterSensitiveLog": () => (/* binding */ PutItemInputFilterSensitiveLog),
/* harmony export */   "PutItemOutputFilterSensitiveLog": () => (/* binding */ PutItemOutputFilterSensitiveLog),
/* harmony export */   "PutRequestFilterSensitiveLog": () => (/* binding */ PutRequestFilterSensitiveLog),
/* harmony export */   "QueryInputFilterSensitiveLog": () => (/* binding */ QueryInputFilterSensitiveLog),
/* harmony export */   "QueryOutputFilterSensitiveLog": () => (/* binding */ QueryOutputFilterSensitiveLog),
/* harmony export */   "ReplicaAlreadyExistsException": () => (/* binding */ ReplicaAlreadyExistsException),
/* harmony export */   "ReplicaAutoScalingDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaAutoScalingDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaAutoScalingUpdateFilterSensitiveLog": () => (/* binding */ ReplicaAutoScalingUpdateFilterSensitiveLog),
/* harmony export */   "ReplicaDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaFilterSensitiveLog": () => (/* binding */ ReplicaFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog": () => (/* binding */ ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog),
/* harmony export */   "ReplicaNotFoundException": () => (/* binding */ ReplicaNotFoundException),
/* harmony export */   "ReplicaSettingsDescriptionFilterSensitiveLog": () => (/* binding */ ReplicaSettingsDescriptionFilterSensitiveLog),
/* harmony export */   "ReplicaSettingsUpdateFilterSensitiveLog": () => (/* binding */ ReplicaSettingsUpdateFilterSensitiveLog),
/* harmony export */   "ReplicaUpdateFilterSensitiveLog": () => (/* binding */ ReplicaUpdateFilterSensitiveLog),
/* harmony export */   "ReplicationGroupUpdateFilterSensitiveLog": () => (/* binding */ ReplicationGroupUpdateFilterSensitiveLog),
/* harmony export */   "RequestLimitExceeded": () => (/* binding */ RequestLimitExceeded),
/* harmony export */   "ResourceInUseException": () => (/* binding */ ResourceInUseException),
/* harmony export */   "ResourceNotFoundException": () => (/* binding */ ResourceNotFoundException),
/* harmony export */   "RestoreSummaryFilterSensitiveLog": () => (/* binding */ RestoreSummaryFilterSensitiveLog),
/* harmony export */   "RestoreTableFromBackupInputFilterSensitiveLog": () => (/* binding */ RestoreTableFromBackupInputFilterSensitiveLog),
/* harmony export */   "RestoreTableFromBackupOutputFilterSensitiveLog": () => (/* binding */ RestoreTableFromBackupOutputFilterSensitiveLog),
/* harmony export */   "RestoreTableToPointInTimeInputFilterSensitiveLog": () => (/* binding */ RestoreTableToPointInTimeInputFilterSensitiveLog),
/* harmony export */   "RestoreTableToPointInTimeOutputFilterSensitiveLog": () => (/* binding */ RestoreTableToPointInTimeOutputFilterSensitiveLog),
/* harmony export */   "S3BucketSourceFilterSensitiveLog": () => (/* binding */ S3BucketSourceFilterSensitiveLog),
/* harmony export */   "SSEDescriptionFilterSensitiveLog": () => (/* binding */ SSEDescriptionFilterSensitiveLog),
/* harmony export */   "SSESpecificationFilterSensitiveLog": () => (/* binding */ SSESpecificationFilterSensitiveLog),
/* harmony export */   "ScanInputFilterSensitiveLog": () => (/* binding */ ScanInputFilterSensitiveLog),
/* harmony export */   "ScanOutputFilterSensitiveLog": () => (/* binding */ ScanOutputFilterSensitiveLog),
/* harmony export */   "SourceTableDetailsFilterSensitiveLog": () => (/* binding */ SourceTableDetailsFilterSensitiveLog),
/* harmony export */   "SourceTableFeatureDetailsFilterSensitiveLog": () => (/* binding */ SourceTableFeatureDetailsFilterSensitiveLog),
/* harmony export */   "StreamSpecificationFilterSensitiveLog": () => (/* binding */ StreamSpecificationFilterSensitiveLog),
/* harmony export */   "TableAlreadyExistsException": () => (/* binding */ TableAlreadyExistsException),
/* harmony export */   "TableAutoScalingDescriptionFilterSensitiveLog": () => (/* binding */ TableAutoScalingDescriptionFilterSensitiveLog),
/* harmony export */   "TableClass": () => (/* binding */ TableClass),
/* harmony export */   "TableClassSummaryFilterSensitiveLog": () => (/* binding */ TableClassSummaryFilterSensitiveLog),
/* harmony export */   "TableCreationParametersFilterSensitiveLog": () => (/* binding */ TableCreationParametersFilterSensitiveLog),
/* harmony export */   "TableDescriptionFilterSensitiveLog": () => (/* binding */ TableDescriptionFilterSensitiveLog),
/* harmony export */   "TableInUseException": () => (/* binding */ TableInUseException),
/* harmony export */   "TableNotFoundException": () => (/* binding */ TableNotFoundException),
/* harmony export */   "TagFilterSensitiveLog": () => (/* binding */ TagFilterSensitiveLog),
/* harmony export */   "TagResourceInputFilterSensitiveLog": () => (/* binding */ TagResourceInputFilterSensitiveLog),
/* harmony export */   "TimeToLiveDescriptionFilterSensitiveLog": () => (/* binding */ TimeToLiveDescriptionFilterSensitiveLog),
/* harmony export */   "TimeToLiveSpecificationFilterSensitiveLog": () => (/* binding */ TimeToLiveSpecificationFilterSensitiveLog),
/* harmony export */   "TransactGetItemFilterSensitiveLog": () => (/* binding */ TransactGetItemFilterSensitiveLog),
/* harmony export */   "TransactGetItemsInputFilterSensitiveLog": () => (/* binding */ TransactGetItemsInputFilterSensitiveLog),
/* harmony export */   "TransactGetItemsOutputFilterSensitiveLog": () => (/* binding */ TransactGetItemsOutputFilterSensitiveLog),
/* harmony export */   "TransactWriteItemFilterSensitiveLog": () => (/* binding */ TransactWriteItemFilterSensitiveLog),
/* harmony export */   "TransactWriteItemsInputFilterSensitiveLog": () => (/* binding */ TransactWriteItemsInputFilterSensitiveLog),
/* harmony export */   "TransactWriteItemsOutputFilterSensitiveLog": () => (/* binding */ TransactWriteItemsOutputFilterSensitiveLog),
/* harmony export */   "TransactionCanceledException": () => (/* binding */ TransactionCanceledException),
/* harmony export */   "TransactionConflictException": () => (/* binding */ TransactionConflictException),
/* harmony export */   "TransactionInProgressException": () => (/* binding */ TransactionInProgressException),
/* harmony export */   "UntagResourceInputFilterSensitiveLog": () => (/* binding */ UntagResourceInputFilterSensitiveLog),
/* harmony export */   "UpdateContinuousBackupsInputFilterSensitiveLog": () => (/* binding */ UpdateContinuousBackupsInputFilterSensitiveLog),
/* harmony export */   "UpdateContinuousBackupsOutputFilterSensitiveLog": () => (/* binding */ UpdateContinuousBackupsOutputFilterSensitiveLog),
/* harmony export */   "UpdateContributorInsightsInputFilterSensitiveLog": () => (/* binding */ UpdateContributorInsightsInputFilterSensitiveLog),
/* harmony export */   "UpdateContributorInsightsOutputFilterSensitiveLog": () => (/* binding */ UpdateContributorInsightsOutputFilterSensitiveLog),
/* harmony export */   "UpdateFilterSensitiveLog": () => (/* binding */ UpdateFilterSensitiveLog),
/* harmony export */   "UpdateGlobalSecondaryIndexActionFilterSensitiveLog": () => (/* binding */ UpdateGlobalSecondaryIndexActionFilterSensitiveLog),
/* harmony export */   "UpdateGlobalTableInputFilterSensitiveLog": () => (/* binding */ UpdateGlobalTableInputFilterSensitiveLog),
/* harmony export */   "UpdateGlobalTableOutputFilterSensitiveLog": () => (/* binding */ UpdateGlobalTableOutputFilterSensitiveLog),
/* harmony export */   "UpdateGlobalTableSettingsInputFilterSensitiveLog": () => (/* binding */ UpdateGlobalTableSettingsInputFilterSensitiveLog),
/* harmony export */   "UpdateGlobalTableSettingsOutputFilterSensitiveLog": () => (/* binding */ UpdateGlobalTableSettingsOutputFilterSensitiveLog),
/* harmony export */   "UpdateItemInputFilterSensitiveLog": () => (/* binding */ UpdateItemInputFilterSensitiveLog),
/* harmony export */   "UpdateItemOutputFilterSensitiveLog": () => (/* binding */ UpdateItemOutputFilterSensitiveLog),
/* harmony export */   "UpdateReplicationGroupMemberActionFilterSensitiveLog": () => (/* binding */ UpdateReplicationGroupMemberActionFilterSensitiveLog),
/* harmony export */   "UpdateTableInputFilterSensitiveLog": () => (/* binding */ UpdateTableInputFilterSensitiveLog),
/* harmony export */   "UpdateTableOutputFilterSensitiveLog": () => (/* binding */ UpdateTableOutputFilterSensitiveLog),
/* harmony export */   "UpdateTableReplicaAutoScalingInputFilterSensitiveLog": () => (/* binding */ UpdateTableReplicaAutoScalingInputFilterSensitiveLog),
/* harmony export */   "UpdateTableReplicaAutoScalingOutputFilterSensitiveLog": () => (/* binding */ UpdateTableReplicaAutoScalingOutputFilterSensitiveLog),
/* harmony export */   "UpdateTimeToLiveInputFilterSensitiveLog": () => (/* binding */ UpdateTimeToLiveInputFilterSensitiveLog),
/* harmony export */   "UpdateTimeToLiveOutputFilterSensitiveLog": () => (/* binding */ UpdateTimeToLiveOutputFilterSensitiveLog),
/* harmony export */   "WriteRequestFilterSensitiveLog": () => (/* binding */ WriteRequestFilterSensitiveLog)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DynamoDBServiceException */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js");


var BackupType;
(function (BackupType) {
    BackupType["AWS_BACKUP"] = "AWS_BACKUP";
    BackupType["SYSTEM"] = "SYSTEM";
    BackupType["USER"] = "USER";
})(BackupType || (BackupType = {}));
var BackupInUseException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(BackupInUseException, _super);
    function BackupInUseException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "BackupInUseException", $fault: "client" }, opts)) || this;
        _this.name = "BackupInUseException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, BackupInUseException.prototype);
        return _this;
    }
    return BackupInUseException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var BackupNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(BackupNotFoundException, _super);
    function BackupNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "BackupNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "BackupNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, BackupNotFoundException.prototype);
        return _this;
    }
    return BackupNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var BackupTypeFilter;
(function (BackupTypeFilter) {
    BackupTypeFilter["ALL"] = "ALL";
    BackupTypeFilter["AWS_BACKUP"] = "AWS_BACKUP";
    BackupTypeFilter["SYSTEM"] = "SYSTEM";
    BackupTypeFilter["USER"] = "USER";
})(BackupTypeFilter || (BackupTypeFilter = {}));
var BatchStatementErrorCodeEnum;
(function (BatchStatementErrorCodeEnum) {
    BatchStatementErrorCodeEnum["AccessDenied"] = "AccessDenied";
    BatchStatementErrorCodeEnum["ConditionalCheckFailed"] = "ConditionalCheckFailed";
    BatchStatementErrorCodeEnum["DuplicateItem"] = "DuplicateItem";
    BatchStatementErrorCodeEnum["InternalServerError"] = "InternalServerError";
    BatchStatementErrorCodeEnum["ItemCollectionSizeLimitExceeded"] = "ItemCollectionSizeLimitExceeded";
    BatchStatementErrorCodeEnum["ProvisionedThroughputExceeded"] = "ProvisionedThroughputExceeded";
    BatchStatementErrorCodeEnum["RequestLimitExceeded"] = "RequestLimitExceeded";
    BatchStatementErrorCodeEnum["ResourceNotFound"] = "ResourceNotFound";
    BatchStatementErrorCodeEnum["ThrottlingError"] = "ThrottlingError";
    BatchStatementErrorCodeEnum["TransactionConflict"] = "TransactionConflict";
    BatchStatementErrorCodeEnum["ValidationError"] = "ValidationError";
})(BatchStatementErrorCodeEnum || (BatchStatementErrorCodeEnum = {}));
var InternalServerError = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InternalServerError, _super);
    function InternalServerError(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "InternalServerError", $fault: "server" }, opts)) || this;
        _this.name = "InternalServerError";
        _this.$fault = "server";
        Object.setPrototypeOf(_this, InternalServerError.prototype);
        return _this;
    }
    return InternalServerError;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var RequestLimitExceeded = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(RequestLimitExceeded, _super);
    function RequestLimitExceeded(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "RequestLimitExceeded", $fault: "client" }, opts)) || this;
        _this.name = "RequestLimitExceeded";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, RequestLimitExceeded.prototype);
        return _this;
    }
    return RequestLimitExceeded;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var InvalidEndpointException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InvalidEndpointException, _super);
    function InvalidEndpointException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "InvalidEndpointException", $fault: "client" }, opts)) || this;
        _this.name = "InvalidEndpointException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, InvalidEndpointException.prototype);
        _this.Message = opts.Message;
        return _this;
    }
    return InvalidEndpointException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ProvisionedThroughputExceededException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ProvisionedThroughputExceededException, _super);
    function ProvisionedThroughputExceededException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ProvisionedThroughputExceededException", $fault: "client" }, opts)) || this;
        _this.name = "ProvisionedThroughputExceededException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ProvisionedThroughputExceededException.prototype);
        return _this;
    }
    return ProvisionedThroughputExceededException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ResourceNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ResourceNotFoundException, _super);
    function ResourceNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ResourceNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "ResourceNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ResourceNotFoundException.prototype);
        return _this;
    }
    return ResourceNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ItemCollectionSizeLimitExceededException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ItemCollectionSizeLimitExceededException, _super);
    function ItemCollectionSizeLimitExceededException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ItemCollectionSizeLimitExceededException", $fault: "client" }, opts)) || this;
        _this.name = "ItemCollectionSizeLimitExceededException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ItemCollectionSizeLimitExceededException.prototype);
        return _this;
    }
    return ItemCollectionSizeLimitExceededException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ConditionalCheckFailedException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ConditionalCheckFailedException, _super);
    function ConditionalCheckFailedException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ConditionalCheckFailedException", $fault: "client" }, opts)) || this;
        _this.name = "ConditionalCheckFailedException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ConditionalCheckFailedException.prototype);
        return _this;
    }
    return ConditionalCheckFailedException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ContinuousBackupsUnavailableException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ContinuousBackupsUnavailableException, _super);
    function ContinuousBackupsUnavailableException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ContinuousBackupsUnavailableException", $fault: "client" }, opts)) || this;
        _this.name = "ContinuousBackupsUnavailableException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ContinuousBackupsUnavailableException.prototype);
        return _this;
    }
    return ContinuousBackupsUnavailableException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var LimitExceededException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(LimitExceededException, _super);
    function LimitExceededException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "LimitExceededException", $fault: "client" }, opts)) || this;
        _this.name = "LimitExceededException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, LimitExceededException.prototype);
        return _this;
    }
    return LimitExceededException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TableInUseException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TableInUseException, _super);
    function TableInUseException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TableInUseException", $fault: "client" }, opts)) || this;
        _this.name = "TableInUseException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TableInUseException.prototype);
        return _this;
    }
    return TableInUseException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TableNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TableNotFoundException, _super);
    function TableNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TableNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "TableNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TableNotFoundException.prototype);
        return _this;
    }
    return TableNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TableClass;
(function (TableClass) {
    TableClass["STANDARD"] = "STANDARD";
    TableClass["STANDARD_INFREQUENT_ACCESS"] = "STANDARD_INFREQUENT_ACCESS";
})(TableClass || (TableClass = {}));
var GlobalTableAlreadyExistsException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(GlobalTableAlreadyExistsException, _super);
    function GlobalTableAlreadyExistsException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "GlobalTableAlreadyExistsException", $fault: "client" }, opts)) || this;
        _this.name = "GlobalTableAlreadyExistsException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, GlobalTableAlreadyExistsException.prototype);
        return _this;
    }
    return GlobalTableAlreadyExistsException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ResourceInUseException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ResourceInUseException, _super);
    function ResourceInUseException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ResourceInUseException", $fault: "client" }, opts)) || this;
        _this.name = "ResourceInUseException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ResourceInUseException.prototype);
        return _this;
    }
    return ResourceInUseException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TransactionConflictException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TransactionConflictException, _super);
    function TransactionConflictException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TransactionConflictException", $fault: "client" }, opts)) || this;
        _this.name = "TransactionConflictException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TransactionConflictException.prototype);
        return _this;
    }
    return TransactionConflictException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ExportFormat;
(function (ExportFormat) {
    ExportFormat["DYNAMODB_JSON"] = "DYNAMODB_JSON";
    ExportFormat["ION"] = "ION";
})(ExportFormat || (ExportFormat = {}));
var ExportStatus;
(function (ExportStatus) {
    ExportStatus["COMPLETED"] = "COMPLETED";
    ExportStatus["FAILED"] = "FAILED";
    ExportStatus["IN_PROGRESS"] = "IN_PROGRESS";
})(ExportStatus || (ExportStatus = {}));
var ExportNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ExportNotFoundException, _super);
    function ExportNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ExportNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "ExportNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ExportNotFoundException.prototype);
        return _this;
    }
    return ExportNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var GlobalTableNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(GlobalTableNotFoundException, _super);
    function GlobalTableNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "GlobalTableNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "GlobalTableNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, GlobalTableNotFoundException.prototype);
        return _this;
    }
    return GlobalTableNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ImportStatus;
(function (ImportStatus) {
    ImportStatus["CANCELLED"] = "CANCELLED";
    ImportStatus["CANCELLING"] = "CANCELLING";
    ImportStatus["COMPLETED"] = "COMPLETED";
    ImportStatus["FAILED"] = "FAILED";
    ImportStatus["IN_PROGRESS"] = "IN_PROGRESS";
})(ImportStatus || (ImportStatus = {}));
var InputCompressionType;
(function (InputCompressionType) {
    InputCompressionType["GZIP"] = "GZIP";
    InputCompressionType["NONE"] = "NONE";
    InputCompressionType["ZSTD"] = "ZSTD";
})(InputCompressionType || (InputCompressionType = {}));
var InputFormat;
(function (InputFormat) {
    InputFormat["CSV"] = "CSV";
    InputFormat["DYNAMODB_JSON"] = "DYNAMODB_JSON";
    InputFormat["ION"] = "ION";
})(InputFormat || (InputFormat = {}));
var ImportNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ImportNotFoundException, _super);
    function ImportNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ImportNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "ImportNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ImportNotFoundException.prototype);
        return _this;
    }
    return ImportNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var DuplicateItemException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(DuplicateItemException, _super);
    function DuplicateItemException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "DuplicateItemException", $fault: "client" }, opts)) || this;
        _this.name = "DuplicateItemException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, DuplicateItemException.prototype);
        return _this;
    }
    return DuplicateItemException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var IdempotentParameterMismatchException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(IdempotentParameterMismatchException, _super);
    function IdempotentParameterMismatchException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "IdempotentParameterMismatchException", $fault: "client" }, opts)) || this;
        _this.name = "IdempotentParameterMismatchException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, IdempotentParameterMismatchException.prototype);
        _this.Message = opts.Message;
        return _this;
    }
    return IdempotentParameterMismatchException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TransactionInProgressException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TransactionInProgressException, _super);
    function TransactionInProgressException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TransactionInProgressException", $fault: "client" }, opts)) || this;
        _this.name = "TransactionInProgressException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TransactionInProgressException.prototype);
        _this.Message = opts.Message;
        return _this;
    }
    return TransactionInProgressException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ExportConflictException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ExportConflictException, _super);
    function ExportConflictException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ExportConflictException", $fault: "client" }, opts)) || this;
        _this.name = "ExportConflictException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ExportConflictException.prototype);
        return _this;
    }
    return ExportConflictException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var InvalidExportTimeException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InvalidExportTimeException, _super);
    function InvalidExportTimeException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "InvalidExportTimeException", $fault: "client" }, opts)) || this;
        _this.name = "InvalidExportTimeException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, InvalidExportTimeException.prototype);
        return _this;
    }
    return InvalidExportTimeException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var PointInTimeRecoveryUnavailableException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(PointInTimeRecoveryUnavailableException, _super);
    function PointInTimeRecoveryUnavailableException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "PointInTimeRecoveryUnavailableException", $fault: "client" }, opts)) || this;
        _this.name = "PointInTimeRecoveryUnavailableException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, PointInTimeRecoveryUnavailableException.prototype);
        return _this;
    }
    return PointInTimeRecoveryUnavailableException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ImportConflictException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ImportConflictException, _super);
    function ImportConflictException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ImportConflictException", $fault: "client" }, opts)) || this;
        _this.name = "ImportConflictException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ImportConflictException.prototype);
        return _this;
    }
    return ImportConflictException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var TableAlreadyExistsException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TableAlreadyExistsException, _super);
    function TableAlreadyExistsException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TableAlreadyExistsException", $fault: "client" }, opts)) || this;
        _this.name = "TableAlreadyExistsException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TableAlreadyExistsException.prototype);
        return _this;
    }
    return TableAlreadyExistsException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var InvalidRestoreTimeException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InvalidRestoreTimeException, _super);
    function InvalidRestoreTimeException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "InvalidRestoreTimeException", $fault: "client" }, opts)) || this;
        _this.name = "InvalidRestoreTimeException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, InvalidRestoreTimeException.prototype);
        return _this;
    }
    return InvalidRestoreTimeException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ReplicaAlreadyExistsException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ReplicaAlreadyExistsException, _super);
    function ReplicaAlreadyExistsException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ReplicaAlreadyExistsException", $fault: "client" }, opts)) || this;
        _this.name = "ReplicaAlreadyExistsException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ReplicaAlreadyExistsException.prototype);
        return _this;
    }
    return ReplicaAlreadyExistsException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ReplicaNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ReplicaNotFoundException, _super);
    function ReplicaNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "ReplicaNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "ReplicaNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, ReplicaNotFoundException.prototype);
        return _this;
    }
    return ReplicaNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var IndexNotFoundException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(IndexNotFoundException, _super);
    function IndexNotFoundException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "IndexNotFoundException", $fault: "client" }, opts)) || this;
        _this.name = "IndexNotFoundException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, IndexNotFoundException.prototype);
        return _this;
    }
    return IndexNotFoundException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var AttributeValue;
(function (AttributeValue) {
    AttributeValue.visit = function (value, visitor) {
        if (value.S !== undefined)
            return visitor.S(value.S);
        if (value.N !== undefined)
            return visitor.N(value.N);
        if (value.B !== undefined)
            return visitor.B(value.B);
        if (value.SS !== undefined)
            return visitor.SS(value.SS);
        if (value.NS !== undefined)
            return visitor.NS(value.NS);
        if (value.BS !== undefined)
            return visitor.BS(value.BS);
        if (value.M !== undefined)
            return visitor.M(value.M);
        if (value.L !== undefined)
            return visitor.L(value.L);
        if (value.NULL !== undefined)
            return visitor.NULL(value.NULL);
        if (value.BOOL !== undefined)
            return visitor.BOOL(value.BOOL);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(AttributeValue || (AttributeValue = {}));
var TransactionCanceledException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(TransactionCanceledException, _super);
    function TransactionCanceledException(opts) {
        var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ name: "TransactionCanceledException", $fault: "client" }, opts)) || this;
        _this.name = "TransactionCanceledException";
        _this.$fault = "client";
        Object.setPrototypeOf(_this, TransactionCanceledException.prototype);
        _this.Message = opts.Message;
        _this.CancellationReasons = opts.CancellationReasons;
        return _this;
    }
    return TransactionCanceledException;
}(_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_1__.DynamoDBServiceException));

var ArchivalSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AttributeDefinitionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingTargetTrackingScalingPolicyConfigurationDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingPolicyDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingTargetTrackingScalingPolicyConfigurationUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingPolicyUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingSettingsDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AutoScalingSettingsUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var BackupDetailsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var KeySchemaElementFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ProvisionedThroughputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var SourceTableDetailsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ProjectionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalSecondaryIndexInfoFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var LocalSecondaryIndexInfoFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var SSEDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var StreamSpecificationFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TimeToLiveDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var SourceTableFeatureDetailsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var BackupDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var BackupSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CapacityFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ConsumedCapacityFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var BatchStatementErrorFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var BillingModeSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var PointInTimeRecoveryDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ContinuousBackupsDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ContributorInsightsSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateBackupInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateBackupOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateGlobalSecondaryIndexActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateGlobalTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ProvisionedThroughputOverrideFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TableClassSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalTableDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateGlobalTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateReplicaActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateReplicationGroupMemberActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalSecondaryIndexFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var LocalSecondaryIndexFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var SSESpecificationFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TagFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ProvisionedThroughputDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalSecondaryIndexDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var LocalSecondaryIndexDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var RestoreSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TableDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CreateTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var CsvOptionsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteBackupInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteBackupOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteGlobalSecondaryIndexActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteReplicaActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteReplicationGroupMemberActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DeleteTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeBackupInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeBackupOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeContinuousBackupsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeContinuousBackupsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeContributorInsightsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var FailureExceptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeContributorInsightsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeEndpointsRequestFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var EndpointFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeEndpointsResponseFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeExportInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ExportDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeExportOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeGlobalTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeGlobalTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeGlobalTableSettingsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexSettingsDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaSettingsDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeGlobalTableSettingsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeImportInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var InputFormatOptionsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var S3BucketSourceFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TableCreationParametersFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ImportTableDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeImportOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeKinesisStreamingDestinationInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var KinesisDataStreamDestinationFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeKinesisStreamingDestinationOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeLimitsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeLimitsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTableReplicaAutoScalingInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexAutoScalingDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaAutoScalingDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TableAutoScalingDescriptionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTableReplicaAutoScalingOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTimeToLiveInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var DescribeTimeToLiveOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var KinesisStreamingDestinationInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var KinesisStreamingDestinationOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ExportTableToPointInTimeInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ExportTableToPointInTimeOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ImportTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ImportTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListBackupsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListBackupsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListContributorInsightsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListContributorInsightsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListExportsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ExportSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListExportsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListGlobalTablesInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalTableFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListGlobalTablesOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListImportsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ImportSummaryFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListImportsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListTablesInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListTablesOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListTagsOfResourceInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ListTagsOfResourceOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var RestoreTableFromBackupInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var RestoreTableFromBackupOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var RestoreTableToPointInTimeInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var RestoreTableToPointInTimeOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TagResourceInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UntagResourceInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var PointInTimeRecoverySpecificationFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateContinuousBackupsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateContinuousBackupsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateContributorInsightsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateContributorInsightsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateGlobalTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateGlobalTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalTableGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexSettingsUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaSettingsUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateGlobalTableSettingsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateGlobalTableSettingsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateGlobalSecondaryIndexActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalSecondaryIndexUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateReplicationGroupMemberActionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicationGroupUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTableInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTableOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var GlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaGlobalSecondaryIndexAutoScalingUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var ReplicaAutoScalingUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTableReplicaAutoScalingInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTableReplicaAutoScalingOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var TimeToLiveSpecificationFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTimeToLiveInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var UpdateTimeToLiveOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj)); };
var AttributeValueFilterSensitiveLog = function (obj) {
    var _a;
    if (obj.S !== undefined)
        return { S: obj.S };
    if (obj.N !== undefined)
        return { N: obj.N };
    if (obj.B !== undefined)
        return { B: obj.B };
    if (obj.SS !== undefined)
        return { SS: obj.SS };
    if (obj.NS !== undefined)
        return { NS: obj.NS };
    if (obj.BS !== undefined)
        return { BS: obj.BS };
    if (obj.M !== undefined)
        return {
            M: Object.entries(obj.M).reduce(function (acc, _a) {
                var _b;
                var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
                return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
            }, {}),
        };
    if (obj.L !== undefined)
        return { L: obj.L.map(function (item) { return AttributeValueFilterSensitiveLog(item); }) };
    if (obj.NULL !== undefined)
        return { NULL: obj.NULL };
    if (obj.BOOL !== undefined)
        return { BOOL: obj.BOOL };
    if (obj.$unknown !== undefined)
        return _a = {}, _a[obj.$unknown[0]] = "UNKNOWN", _a;
};
var AttributeValueUpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Value && { Value: AttributeValueFilterSensitiveLog(obj.Value) }))); };
var BatchStatementRequestFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Parameters && { Parameters: obj.Parameters.map(function (item) { return AttributeValueFilterSensitiveLog(item); }) }))); };
var BatchStatementResponseFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var CancellationReasonFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ConditionFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.AttributeValueList && {
    AttributeValueList: obj.AttributeValueList.map(function (item) { return AttributeValueFilterSensitiveLog(item); }),
}))); };
var DeleteRequestFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ExecuteStatementInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Parameters && { Parameters: obj.Parameters.map(function (item) { return AttributeValueFilterSensitiveLog(item); }) }))); };
var GetFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var GetItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var GetItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ItemCollectionMetricsFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.ItemCollectionKey && {
    ItemCollectionKey: Object.entries(obj.ItemCollectionKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ItemResponseFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ParameterizedStatementFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Parameters && { Parameters: obj.Parameters.map(function (item) { return AttributeValueFilterSensitiveLog(item); }) }))); };
var PutRequestFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var KeysAndAttributesFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Keys && {
    Keys: obj.Keys.map(function (item) {
        return Object.entries(item).reduce(function (acc, _a) {
            var _b;
            var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
            return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
        }, {});
    }),
}))); };
var TransactGetItemFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Get && { Get: GetFilterSensitiveLog(obj.Get) }))); };
var BatchExecuteStatementInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Statements && { Statements: obj.Statements.map(function (item) { return BatchStatementRequestFilterSensitiveLog(item); }) }))); };
var BatchExecuteStatementOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Responses && { Responses: obj.Responses.map(function (item) { return BatchStatementResponseFilterSensitiveLog(item); }) }))); };
var ExecuteTransactionInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.TransactStatements && {
    TransactStatements: obj.TransactStatements.map(function (item) { return ParameterizedStatementFilterSensitiveLog(item); }),
}))); };
var ExecuteTransactionOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Responses && { Responses: obj.Responses.map(function (item) { return ItemResponseFilterSensitiveLog(item); }) }))); };
var TransactGetItemsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Responses && { Responses: obj.Responses.map(function (item) { return ItemResponseFilterSensitiveLog(item); }) }))); };
var BatchGetItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.RequestItems && {
    RequestItems: Object.entries(obj.RequestItems).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = KeysAndAttributesFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ExpectedAttributeValueFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Value && { Value: AttributeValueFilterSensitiveLog(obj.Value) })), (obj.AttributeValueList && {
    AttributeValueList: obj.AttributeValueList.map(function (item) { return AttributeValueFilterSensitiveLog(item); }),
}))); };
var TransactGetItemsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.TransactItems && { TransactItems: obj.TransactItems.map(function (item) { return TransactGetItemFilterSensitiveLog(item); }) }))); };
var TransactWriteItemsOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.ItemCollectionMetrics && {
    ItemCollectionMetrics: Object.entries(obj.ItemCollectionMetrics).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = value.map(function (item) { return ItemCollectionMetricsFilterSensitiveLog(item); }), _b)));
    }, {}),
}))); };
var ConditionCheckFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var DeleteFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var PutFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var UpdateFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var DeleteItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Attributes && {
    Attributes: Object.entries(obj.Attributes).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ItemCollectionMetrics && {
    ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
}))); };
var ExecuteStatementOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Items && {
    Items: obj.Items.map(function (item) {
        return Object.entries(item).reduce(function (acc, _a) {
            var _b;
            var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
            return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
        }, {});
    }),
})), (obj.LastEvaluatedKey && {
    LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var PutItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Attributes && {
    Attributes: Object.entries(obj.Attributes).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ItemCollectionMetrics && {
    ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
}))); };
var QueryOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Items && {
    Items: obj.Items.map(function (item) {
        return Object.entries(item).reduce(function (acc, _a) {
            var _b;
            var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
            return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
        }, {});
    }),
})), (obj.LastEvaluatedKey && {
    LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ScanOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Items && {
    Items: obj.Items.map(function (item) {
        return Object.entries(item).reduce(function (acc, _a) {
            var _b;
            var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
            return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
        }, {});
    }),
})), (obj.LastEvaluatedKey && {
    LastEvaluatedKey: Object.entries(obj.LastEvaluatedKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var UpdateItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Attributes && {
    Attributes: Object.entries(obj.Attributes).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ItemCollectionMetrics && {
    ItemCollectionMetrics: ItemCollectionMetricsFilterSensitiveLog(obj.ItemCollectionMetrics),
}))); };
var WriteRequestFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.PutRequest && { PutRequest: PutRequestFilterSensitiveLog(obj.PutRequest) })), (obj.DeleteRequest && { DeleteRequest: DeleteRequestFilterSensitiveLog(obj.DeleteRequest) }))); };
var BatchGetItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Responses && {
    Responses: Object.entries(obj.Responses).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = value.map(function (item) {
            return Object.entries(item).reduce(function (acc, _a) {
                var _b;
                var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
                return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
            }, {});
        }), _b)));
    }, {}),
})), (obj.UnprocessedKeys && {
    UnprocessedKeys: Object.entries(obj.UnprocessedKeys).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = KeysAndAttributesFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var ScanInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.ScanFilter && {
    ScanFilter: Object.entries(obj.ScanFilter).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ConditionFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExclusiveStartKey && {
    ExclusiveStartKey: Object.entries(obj.ExclusiveStartKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var BatchWriteItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.RequestItems && {
    RequestItems: Object.entries(obj.RequestItems).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = value.map(function (item) { return WriteRequestFilterSensitiveLog(item); }), _b)));
    }, {}),
}))); };
var DeleteItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.Expected && {
    Expected: Object.entries(obj.Expected).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ExpectedAttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var PutItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Item && {
    Item: Object.entries(obj.Item).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.Expected && {
    Expected: Object.entries(obj.Expected).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ExpectedAttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var QueryInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.KeyConditions && {
    KeyConditions: Object.entries(obj.KeyConditions).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ConditionFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.QueryFilter && {
    QueryFilter: Object.entries(obj.QueryFilter).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ConditionFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExclusiveStartKey && {
    ExclusiveStartKey: Object.entries(obj.ExclusiveStartKey).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var BatchWriteItemOutputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.UnprocessedItems && {
    UnprocessedItems: Object.entries(obj.UnprocessedItems).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = value.map(function (item) { return WriteRequestFilterSensitiveLog(item); }), _b)));
    }, {}),
})), (obj.ItemCollectionMetrics && {
    ItemCollectionMetrics: Object.entries(obj.ItemCollectionMetrics).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = value.map(function (item) { return ItemCollectionMetricsFilterSensitiveLog(item); }), _b)));
    }, {}),
}))); };
var UpdateItemInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.Key && {
    Key: Object.entries(obj.Key).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.AttributeUpdates && {
    AttributeUpdates: Object.entries(obj.AttributeUpdates).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueUpdateFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.Expected && {
    Expected: Object.entries(obj.Expected).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = ExpectedAttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
})), (obj.ExpressionAttributeValues && {
    ExpressionAttributeValues: Object.entries(obj.ExpressionAttributeValues).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = AttributeValueFilterSensitiveLog(value), _b)));
    }, {}),
}))); };
var TransactWriteItemFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.ConditionCheck && { ConditionCheck: ConditionCheckFilterSensitiveLog(obj.ConditionCheck) })), (obj.Put && { Put: PutFilterSensitiveLog(obj.Put) })), (obj.Delete && { Delete: DeleteFilterSensitiveLog(obj.Delete) })), (obj.Update && { Update: UpdateFilterSensitiveLog(obj.Update) }))); };
var TransactWriteItemsInputFilterSensitiveLog = function (obj) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, obj), (obj.TransactItems && {
    TransactItems: obj.TransactItems.map(function (item) { return TransactWriteItemFilterSensitiveLog(item); }),
}))); };


/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/dist-es/protocols/Aws_json1_0.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deserializeAws_json1_0BatchExecuteStatementCommand": () => (/* binding */ deserializeAws_json1_0BatchExecuteStatementCommand),
/* harmony export */   "deserializeAws_json1_0BatchGetItemCommand": () => (/* binding */ deserializeAws_json1_0BatchGetItemCommand),
/* harmony export */   "deserializeAws_json1_0BatchWriteItemCommand": () => (/* binding */ deserializeAws_json1_0BatchWriteItemCommand),
/* harmony export */   "deserializeAws_json1_0CreateBackupCommand": () => (/* binding */ deserializeAws_json1_0CreateBackupCommand),
/* harmony export */   "deserializeAws_json1_0CreateGlobalTableCommand": () => (/* binding */ deserializeAws_json1_0CreateGlobalTableCommand),
/* harmony export */   "deserializeAws_json1_0CreateTableCommand": () => (/* binding */ deserializeAws_json1_0CreateTableCommand),
/* harmony export */   "deserializeAws_json1_0DeleteBackupCommand": () => (/* binding */ deserializeAws_json1_0DeleteBackupCommand),
/* harmony export */   "deserializeAws_json1_0DeleteItemCommand": () => (/* binding */ deserializeAws_json1_0DeleteItemCommand),
/* harmony export */   "deserializeAws_json1_0DeleteTableCommand": () => (/* binding */ deserializeAws_json1_0DeleteTableCommand),
/* harmony export */   "deserializeAws_json1_0DescribeBackupCommand": () => (/* binding */ deserializeAws_json1_0DescribeBackupCommand),
/* harmony export */   "deserializeAws_json1_0DescribeContinuousBackupsCommand": () => (/* binding */ deserializeAws_json1_0DescribeContinuousBackupsCommand),
/* harmony export */   "deserializeAws_json1_0DescribeContributorInsightsCommand": () => (/* binding */ deserializeAws_json1_0DescribeContributorInsightsCommand),
/* harmony export */   "deserializeAws_json1_0DescribeEndpointsCommand": () => (/* binding */ deserializeAws_json1_0DescribeEndpointsCommand),
/* harmony export */   "deserializeAws_json1_0DescribeExportCommand": () => (/* binding */ deserializeAws_json1_0DescribeExportCommand),
/* harmony export */   "deserializeAws_json1_0DescribeGlobalTableCommand": () => (/* binding */ deserializeAws_json1_0DescribeGlobalTableCommand),
/* harmony export */   "deserializeAws_json1_0DescribeGlobalTableSettingsCommand": () => (/* binding */ deserializeAws_json1_0DescribeGlobalTableSettingsCommand),
/* harmony export */   "deserializeAws_json1_0DescribeImportCommand": () => (/* binding */ deserializeAws_json1_0DescribeImportCommand),
/* harmony export */   "deserializeAws_json1_0DescribeKinesisStreamingDestinationCommand": () => (/* binding */ deserializeAws_json1_0DescribeKinesisStreamingDestinationCommand),
/* harmony export */   "deserializeAws_json1_0DescribeLimitsCommand": () => (/* binding */ deserializeAws_json1_0DescribeLimitsCommand),
/* harmony export */   "deserializeAws_json1_0DescribeTableCommand": () => (/* binding */ deserializeAws_json1_0DescribeTableCommand),
/* harmony export */   "deserializeAws_json1_0DescribeTableReplicaAutoScalingCommand": () => (/* binding */ deserializeAws_json1_0DescribeTableReplicaAutoScalingCommand),
/* harmony export */   "deserializeAws_json1_0DescribeTimeToLiveCommand": () => (/* binding */ deserializeAws_json1_0DescribeTimeToLiveCommand),
/* harmony export */   "deserializeAws_json1_0DisableKinesisStreamingDestinationCommand": () => (/* binding */ deserializeAws_json1_0DisableKinesisStreamingDestinationCommand),
/* harmony export */   "deserializeAws_json1_0EnableKinesisStreamingDestinationCommand": () => (/* binding */ deserializeAws_json1_0EnableKinesisStreamingDestinationCommand),
/* harmony export */   "deserializeAws_json1_0ExecuteStatementCommand": () => (/* binding */ deserializeAws_json1_0ExecuteStatementCommand),
/* harmony export */   "deserializeAws_json1_0ExecuteTransactionCommand": () => (/* binding */ deserializeAws_json1_0ExecuteTransactionCommand),
/* harmony export */   "deserializeAws_json1_0ExportTableToPointInTimeCommand": () => (/* binding */ deserializeAws_json1_0ExportTableToPointInTimeCommand),
/* harmony export */   "deserializeAws_json1_0GetItemCommand": () => (/* binding */ deserializeAws_json1_0GetItemCommand),
/* harmony export */   "deserializeAws_json1_0ImportTableCommand": () => (/* binding */ deserializeAws_json1_0ImportTableCommand),
/* harmony export */   "deserializeAws_json1_0ListBackupsCommand": () => (/* binding */ deserializeAws_json1_0ListBackupsCommand),
/* harmony export */   "deserializeAws_json1_0ListContributorInsightsCommand": () => (/* binding */ deserializeAws_json1_0ListContributorInsightsCommand),
/* harmony export */   "deserializeAws_json1_0ListExportsCommand": () => (/* binding */ deserializeAws_json1_0ListExportsCommand),
/* harmony export */   "deserializeAws_json1_0ListGlobalTablesCommand": () => (/* binding */ deserializeAws_json1_0ListGlobalTablesCommand),
/* harmony export */   "deserializeAws_json1_0ListImportsCommand": () => (/* binding */ deserializeAws_json1_0ListImportsCommand),
/* harmony export */   "deserializeAws_json1_0ListTablesCommand": () => (/* binding */ deserializeAws_json1_0ListTablesCommand),
/* harmony export */   "deserializeAws_json1_0ListTagsOfResourceCommand": () => (/* binding */ deserializeAws_json1_0ListTagsOfResourceCommand),
/* harmony export */   "deserializeAws_json1_0PutItemCommand": () => (/* binding */ deserializeAws_json1_0PutItemCommand),
/* harmony export */   "deserializeAws_json1_0QueryCommand": () => (/* binding */ deserializeAws_json1_0QueryCommand),
/* harmony export */   "deserializeAws_json1_0RestoreTableFromBackupCommand": () => (/* binding */ deserializeAws_json1_0RestoreTableFromBackupCommand),
/* harmony export */   "deserializeAws_json1_0RestoreTableToPointInTimeCommand": () => (/* binding */ deserializeAws_json1_0RestoreTableToPointInTimeCommand),
/* harmony export */   "deserializeAws_json1_0ScanCommand": () => (/* binding */ deserializeAws_json1_0ScanCommand),
/* harmony export */   "deserializeAws_json1_0TagResourceCommand": () => (/* binding */ deserializeAws_json1_0TagResourceCommand),
/* harmony export */   "deserializeAws_json1_0TransactGetItemsCommand": () => (/* binding */ deserializeAws_json1_0TransactGetItemsCommand),
/* harmony export */   "deserializeAws_json1_0TransactWriteItemsCommand": () => (/* binding */ deserializeAws_json1_0TransactWriteItemsCommand),
/* harmony export */   "deserializeAws_json1_0UntagResourceCommand": () => (/* binding */ deserializeAws_json1_0UntagResourceCommand),
/* harmony export */   "deserializeAws_json1_0UpdateContinuousBackupsCommand": () => (/* binding */ deserializeAws_json1_0UpdateContinuousBackupsCommand),
/* harmony export */   "deserializeAws_json1_0UpdateContributorInsightsCommand": () => (/* binding */ deserializeAws_json1_0UpdateContributorInsightsCommand),
/* harmony export */   "deserializeAws_json1_0UpdateGlobalTableCommand": () => (/* binding */ deserializeAws_json1_0UpdateGlobalTableCommand),
/* harmony export */   "deserializeAws_json1_0UpdateGlobalTableSettingsCommand": () => (/* binding */ deserializeAws_json1_0UpdateGlobalTableSettingsCommand),
/* harmony export */   "deserializeAws_json1_0UpdateItemCommand": () => (/* binding */ deserializeAws_json1_0UpdateItemCommand),
/* harmony export */   "deserializeAws_json1_0UpdateTableCommand": () => (/* binding */ deserializeAws_json1_0UpdateTableCommand),
/* harmony export */   "deserializeAws_json1_0UpdateTableReplicaAutoScalingCommand": () => (/* binding */ deserializeAws_json1_0UpdateTableReplicaAutoScalingCommand),
/* harmony export */   "deserializeAws_json1_0UpdateTimeToLiveCommand": () => (/* binding */ deserializeAws_json1_0UpdateTimeToLiveCommand),
/* harmony export */   "serializeAws_json1_0BatchExecuteStatementCommand": () => (/* binding */ serializeAws_json1_0BatchExecuteStatementCommand),
/* harmony export */   "serializeAws_json1_0BatchGetItemCommand": () => (/* binding */ serializeAws_json1_0BatchGetItemCommand),
/* harmony export */   "serializeAws_json1_0BatchWriteItemCommand": () => (/* binding */ serializeAws_json1_0BatchWriteItemCommand),
/* harmony export */   "serializeAws_json1_0CreateBackupCommand": () => (/* binding */ serializeAws_json1_0CreateBackupCommand),
/* harmony export */   "serializeAws_json1_0CreateGlobalTableCommand": () => (/* binding */ serializeAws_json1_0CreateGlobalTableCommand),
/* harmony export */   "serializeAws_json1_0CreateTableCommand": () => (/* binding */ serializeAws_json1_0CreateTableCommand),
/* harmony export */   "serializeAws_json1_0DeleteBackupCommand": () => (/* binding */ serializeAws_json1_0DeleteBackupCommand),
/* harmony export */   "serializeAws_json1_0DeleteItemCommand": () => (/* binding */ serializeAws_json1_0DeleteItemCommand),
/* harmony export */   "serializeAws_json1_0DeleteTableCommand": () => (/* binding */ serializeAws_json1_0DeleteTableCommand),
/* harmony export */   "serializeAws_json1_0DescribeBackupCommand": () => (/* binding */ serializeAws_json1_0DescribeBackupCommand),
/* harmony export */   "serializeAws_json1_0DescribeContinuousBackupsCommand": () => (/* binding */ serializeAws_json1_0DescribeContinuousBackupsCommand),
/* harmony export */   "serializeAws_json1_0DescribeContributorInsightsCommand": () => (/* binding */ serializeAws_json1_0DescribeContributorInsightsCommand),
/* harmony export */   "serializeAws_json1_0DescribeEndpointsCommand": () => (/* binding */ serializeAws_json1_0DescribeEndpointsCommand),
/* harmony export */   "serializeAws_json1_0DescribeExportCommand": () => (/* binding */ serializeAws_json1_0DescribeExportCommand),
/* harmony export */   "serializeAws_json1_0DescribeGlobalTableCommand": () => (/* binding */ serializeAws_json1_0DescribeGlobalTableCommand),
/* harmony export */   "serializeAws_json1_0DescribeGlobalTableSettingsCommand": () => (/* binding */ serializeAws_json1_0DescribeGlobalTableSettingsCommand),
/* harmony export */   "serializeAws_json1_0DescribeImportCommand": () => (/* binding */ serializeAws_json1_0DescribeImportCommand),
/* harmony export */   "serializeAws_json1_0DescribeKinesisStreamingDestinationCommand": () => (/* binding */ serializeAws_json1_0DescribeKinesisStreamingDestinationCommand),
/* harmony export */   "serializeAws_json1_0DescribeLimitsCommand": () => (/* binding */ serializeAws_json1_0DescribeLimitsCommand),
/* harmony export */   "serializeAws_json1_0DescribeTableCommand": () => (/* binding */ serializeAws_json1_0DescribeTableCommand),
/* harmony export */   "serializeAws_json1_0DescribeTableReplicaAutoScalingCommand": () => (/* binding */ serializeAws_json1_0DescribeTableReplicaAutoScalingCommand),
/* harmony export */   "serializeAws_json1_0DescribeTimeToLiveCommand": () => (/* binding */ serializeAws_json1_0DescribeTimeToLiveCommand),
/* harmony export */   "serializeAws_json1_0DisableKinesisStreamingDestinationCommand": () => (/* binding */ serializeAws_json1_0DisableKinesisStreamingDestinationCommand),
/* harmony export */   "serializeAws_json1_0EnableKinesisStreamingDestinationCommand": () => (/* binding */ serializeAws_json1_0EnableKinesisStreamingDestinationCommand),
/* harmony export */   "serializeAws_json1_0ExecuteStatementCommand": () => (/* binding */ serializeAws_json1_0ExecuteStatementCommand),
/* harmony export */   "serializeAws_json1_0ExecuteTransactionCommand": () => (/* binding */ serializeAws_json1_0ExecuteTransactionCommand),
/* harmony export */   "serializeAws_json1_0ExportTableToPointInTimeCommand": () => (/* binding */ serializeAws_json1_0ExportTableToPointInTimeCommand),
/* harmony export */   "serializeAws_json1_0GetItemCommand": () => (/* binding */ serializeAws_json1_0GetItemCommand),
/* harmony export */   "serializeAws_json1_0ImportTableCommand": () => (/* binding */ serializeAws_json1_0ImportTableCommand),
/* harmony export */   "serializeAws_json1_0ListBackupsCommand": () => (/* binding */ serializeAws_json1_0ListBackupsCommand),
/* harmony export */   "serializeAws_json1_0ListContributorInsightsCommand": () => (/* binding */ serializeAws_json1_0ListContributorInsightsCommand),
/* harmony export */   "serializeAws_json1_0ListExportsCommand": () => (/* binding */ serializeAws_json1_0ListExportsCommand),
/* harmony export */   "serializeAws_json1_0ListGlobalTablesCommand": () => (/* binding */ serializeAws_json1_0ListGlobalTablesCommand),
/* harmony export */   "serializeAws_json1_0ListImportsCommand": () => (/* binding */ serializeAws_json1_0ListImportsCommand),
/* harmony export */   "serializeAws_json1_0ListTablesCommand": () => (/* binding */ serializeAws_json1_0ListTablesCommand),
/* harmony export */   "serializeAws_json1_0ListTagsOfResourceCommand": () => (/* binding */ serializeAws_json1_0ListTagsOfResourceCommand),
/* harmony export */   "serializeAws_json1_0PutItemCommand": () => (/* binding */ serializeAws_json1_0PutItemCommand),
/* harmony export */   "serializeAws_json1_0QueryCommand": () => (/* binding */ serializeAws_json1_0QueryCommand),
/* harmony export */   "serializeAws_json1_0RestoreTableFromBackupCommand": () => (/* binding */ serializeAws_json1_0RestoreTableFromBackupCommand),
/* harmony export */   "serializeAws_json1_0RestoreTableToPointInTimeCommand": () => (/* binding */ serializeAws_json1_0RestoreTableToPointInTimeCommand),
/* harmony export */   "serializeAws_json1_0ScanCommand": () => (/* binding */ serializeAws_json1_0ScanCommand),
/* harmony export */   "serializeAws_json1_0TagResourceCommand": () => (/* binding */ serializeAws_json1_0TagResourceCommand),
/* harmony export */   "serializeAws_json1_0TransactGetItemsCommand": () => (/* binding */ serializeAws_json1_0TransactGetItemsCommand),
/* harmony export */   "serializeAws_json1_0TransactWriteItemsCommand": () => (/* binding */ serializeAws_json1_0TransactWriteItemsCommand),
/* harmony export */   "serializeAws_json1_0UntagResourceCommand": () => (/* binding */ serializeAws_json1_0UntagResourceCommand),
/* harmony export */   "serializeAws_json1_0UpdateContinuousBackupsCommand": () => (/* binding */ serializeAws_json1_0UpdateContinuousBackupsCommand),
/* harmony export */   "serializeAws_json1_0UpdateContributorInsightsCommand": () => (/* binding */ serializeAws_json1_0UpdateContributorInsightsCommand),
/* harmony export */   "serializeAws_json1_0UpdateGlobalTableCommand": () => (/* binding */ serializeAws_json1_0UpdateGlobalTableCommand),
/* harmony export */   "serializeAws_json1_0UpdateGlobalTableSettingsCommand": () => (/* binding */ serializeAws_json1_0UpdateGlobalTableSettingsCommand),
/* harmony export */   "serializeAws_json1_0UpdateItemCommand": () => (/* binding */ serializeAws_json1_0UpdateItemCommand),
/* harmony export */   "serializeAws_json1_0UpdateTableCommand": () => (/* binding */ serializeAws_json1_0UpdateTableCommand),
/* harmony export */   "serializeAws_json1_0UpdateTableReplicaAutoScalingCommand": () => (/* binding */ serializeAws_json1_0UpdateTableReplicaAutoScalingCommand),
/* harmony export */   "serializeAws_json1_0UpdateTimeToLiveCommand": () => (/* binding */ serializeAws_json1_0UpdateTimeToLiveCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_protocol_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/protocol-http */ "./node_modules/@aws-sdk/protocol-http/dist-es/index.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid */ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/v4.js");
/* harmony import */ var _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/DynamoDBServiceException */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/DynamoDBServiceException.js");
/* harmony import */ var _models_models_0__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/models_0 */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/models/models_0.js");






var serializeAws_json1_0BatchExecuteStatementCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.BatchExecuteStatement",
        };
        body = JSON.stringify(serializeAws_json1_0BatchExecuteStatementInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0BatchGetItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.BatchGetItem",
        };
        body = JSON.stringify(serializeAws_json1_0BatchGetItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0BatchWriteItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.BatchWriteItem",
        };
        body = JSON.stringify(serializeAws_json1_0BatchWriteItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0CreateBackupCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.CreateBackup",
        };
        body = JSON.stringify(serializeAws_json1_0CreateBackupInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0CreateGlobalTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.CreateGlobalTable",
        };
        body = JSON.stringify(serializeAws_json1_0CreateGlobalTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0CreateTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.CreateTable",
        };
        body = JSON.stringify(serializeAws_json1_0CreateTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DeleteBackupCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DeleteBackup",
        };
        body = JSON.stringify(serializeAws_json1_0DeleteBackupInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DeleteItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DeleteItem",
        };
        body = JSON.stringify(serializeAws_json1_0DeleteItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DeleteTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DeleteTable",
        };
        body = JSON.stringify(serializeAws_json1_0DeleteTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeBackupCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeBackup",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeBackupInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeContinuousBackupsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeContinuousBackups",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeContinuousBackupsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeContributorInsightsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeContributorInsights",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeContributorInsightsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeEndpointsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeEndpoints",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeEndpointsRequest(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeExportCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeExport",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeExportInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeGlobalTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeGlobalTable",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeGlobalTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeGlobalTableSettingsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeGlobalTableSettings",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeGlobalTableSettingsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeImportCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeImport",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeImportInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeKinesisStreamingDestinationCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeKinesisStreamingDestination",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeKinesisStreamingDestinationInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeLimitsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeLimits",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeLimitsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeTable",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeTableReplicaAutoScalingCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeTableReplicaAutoScaling",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeTableReplicaAutoScalingInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DescribeTimeToLiveCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DescribeTimeToLive",
        };
        body = JSON.stringify(serializeAws_json1_0DescribeTimeToLiveInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0DisableKinesisStreamingDestinationCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.DisableKinesisStreamingDestination",
        };
        body = JSON.stringify(serializeAws_json1_0KinesisStreamingDestinationInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0EnableKinesisStreamingDestinationCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.EnableKinesisStreamingDestination",
        };
        body = JSON.stringify(serializeAws_json1_0KinesisStreamingDestinationInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ExecuteStatementCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ExecuteStatement",
        };
        body = JSON.stringify(serializeAws_json1_0ExecuteStatementInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ExecuteTransactionCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ExecuteTransaction",
        };
        body = JSON.stringify(serializeAws_json1_0ExecuteTransactionInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ExportTableToPointInTimeCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ExportTableToPointInTime",
        };
        body = JSON.stringify(serializeAws_json1_0ExportTableToPointInTimeInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0GetItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.GetItem",
        };
        body = JSON.stringify(serializeAws_json1_0GetItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ImportTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ImportTable",
        };
        body = JSON.stringify(serializeAws_json1_0ImportTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListBackupsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListBackups",
        };
        body = JSON.stringify(serializeAws_json1_0ListBackupsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListContributorInsightsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListContributorInsights",
        };
        body = JSON.stringify(serializeAws_json1_0ListContributorInsightsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListExportsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListExports",
        };
        body = JSON.stringify(serializeAws_json1_0ListExportsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListGlobalTablesCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListGlobalTables",
        };
        body = JSON.stringify(serializeAws_json1_0ListGlobalTablesInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListImportsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListImports",
        };
        body = JSON.stringify(serializeAws_json1_0ListImportsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListTablesCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListTables",
        };
        body = JSON.stringify(serializeAws_json1_0ListTablesInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ListTagsOfResourceCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.ListTagsOfResource",
        };
        body = JSON.stringify(serializeAws_json1_0ListTagsOfResourceInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0PutItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.PutItem",
        };
        body = JSON.stringify(serializeAws_json1_0PutItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0QueryCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.Query",
        };
        body = JSON.stringify(serializeAws_json1_0QueryInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0RestoreTableFromBackupCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.RestoreTableFromBackup",
        };
        body = JSON.stringify(serializeAws_json1_0RestoreTableFromBackupInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0RestoreTableToPointInTimeCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.RestoreTableToPointInTime",
        };
        body = JSON.stringify(serializeAws_json1_0RestoreTableToPointInTimeInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0ScanCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.Scan",
        };
        body = JSON.stringify(serializeAws_json1_0ScanInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0TagResourceCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.TagResource",
        };
        body = JSON.stringify(serializeAws_json1_0TagResourceInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0TransactGetItemsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.TransactGetItems",
        };
        body = JSON.stringify(serializeAws_json1_0TransactGetItemsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0TransactWriteItemsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.TransactWriteItems",
        };
        body = JSON.stringify(serializeAws_json1_0TransactWriteItemsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UntagResourceCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UntagResource",
        };
        body = JSON.stringify(serializeAws_json1_0UntagResourceInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateContinuousBackupsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateContinuousBackups",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateContinuousBackupsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateContributorInsightsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateContributorInsights",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateContributorInsightsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateGlobalTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateGlobalTable",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateGlobalTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateGlobalTableSettingsCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateGlobalTableSettings",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateGlobalTableSettingsInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateItemCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateItem",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateItemInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateTableCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateTable",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateTableInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateTableReplicaAutoScalingCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateTableReplicaAutoScaling",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateTableReplicaAutoScalingInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var serializeAws_json1_0UpdateTimeToLiveCommand = function (input, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var headers, body;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        headers = {
            "content-type": "application/x-amz-json-1.0",
            "x-amz-target": "DynamoDB_20120810.UpdateTimeToLive",
        };
        body = JSON.stringify(serializeAws_json1_0UpdateTimeToLiveInput(input, context));
        return [2, buildHttpRpcRequest(context, headers, "/", undefined, body)];
    });
}); };
var deserializeAws_json1_0BatchExecuteStatementCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0BatchExecuteStatementCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0BatchExecuteStatementOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0BatchExecuteStatementCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "RequestLimitExceeded": return [3, 4];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0BatchGetItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0BatchGetItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0BatchGetItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0BatchGetItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0BatchWriteItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0BatchWriteItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0BatchWriteItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0BatchWriteItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ItemCollectionSizeLimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException": return [3, 6];
                    case "ProvisionedThroughputExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 8];
                    case "RequestLimitExceeded": return [3, 10];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 10];
                    case "ResourceNotFoundException": return [3, 12];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 12];
                }
                return [3, 14];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 15;
            case 15: return [2];
        }
    });
}); };
var deserializeAws_json1_0CreateBackupCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0CreateBackupCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0CreateBackupOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0CreateBackupCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "BackupInUseException": return [3, 2];
                    case "com.amazonaws.dynamodb#BackupInUseException": return [3, 2];
                    case "ContinuousBackupsUnavailableException": return [3, 4];
                    case "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException": return [3, 4];
                    case "InternalServerError": return [3, 6];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 6];
                    case "InvalidEndpointException": return [3, 8];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 8];
                    case "LimitExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 10];
                    case "TableInUseException": return [3, 12];
                    case "com.amazonaws.dynamodb#TableInUseException": return [3, 12];
                    case "TableNotFoundException": return [3, 14];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 14];
                }
                return [3, 16];
            case 2: return [4, deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 17;
            case 17: return [2];
        }
    });
}); };
var deserializeAws_json1_0CreateGlobalTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0CreateGlobalTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0CreateGlobalTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0CreateGlobalTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "GlobalTableAlreadyExistsException": return [3, 2];
                    case "com.amazonaws.dynamodb#GlobalTableAlreadyExistsException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "LimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 8];
                    case "TableNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0GlobalTableAlreadyExistsExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0CreateTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0CreateTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0CreateTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0CreateTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                }
                return [3, 10];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 11;
            case 11: return [2];
        }
    });
}); };
var deserializeAws_json1_0DeleteBackupCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DeleteBackupCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DeleteBackupOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DeleteBackupCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "BackupInUseException": return [3, 2];
                    case "com.amazonaws.dynamodb#BackupInUseException": return [3, 2];
                    case "BackupNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#BackupNotFoundException": return [3, 4];
                    case "InternalServerError": return [3, 6];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 6];
                    case "InvalidEndpointException": return [3, 8];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 8];
                    case "LimitExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0DeleteItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DeleteItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DeleteItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DeleteItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ConditionalCheckFailedException": return [3, 2];
                    case "com.amazonaws.dynamodb#ConditionalCheckFailedException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "ProvisionedThroughputExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 10];
                    case "RequestLimitExceeded": return [3, 12];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 12];
                    case "ResourceNotFoundException": return [3, 14];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 14];
                    case "TransactionConflictException": return [3, 16];
                    case "com.amazonaws.dynamodb#TransactionConflictException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0DeleteTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DeleteTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DeleteTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DeleteTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeBackupCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeBackupCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeBackupOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeBackupCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "BackupNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#BackupNotFoundException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeContinuousBackupsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeContinuousBackupsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeContinuousBackupsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeContinuousBackupsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "TableNotFoundException": return [3, 6];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeContributorInsightsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeContributorInsightsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeContributorInsightsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeContributorInsightsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "ResourceNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeEndpointsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeEndpointsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeEndpointsResponse(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeEndpointsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, parsedBody;
    var _b;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_c) {
        switch (_c.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _b = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_b.body = _c.sent(), _b)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeExportCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeExportCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeExportOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeExportCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ExportNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#ExportNotFoundException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0ExportNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeGlobalTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeGlobalTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeGlobalTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeGlobalTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "GlobalTableNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#GlobalTableNotFoundException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeGlobalTableSettingsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeGlobalTableSettingsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeGlobalTableSettingsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeGlobalTableSettingsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "GlobalTableNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#GlobalTableNotFoundException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeImportCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeImportCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeImportOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeImportCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ImportNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#ImportNotFoundException": return [3, 2];
                }
                return [3, 4];
            case 2: return [4, deserializeAws_json1_0ImportNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 5;
            case 5: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeKinesisStreamingDestinationCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeKinesisStreamingDestinationCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeKinesisStreamingDestinationOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeKinesisStreamingDestinationCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ResourceNotFoundException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeLimitsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeLimitsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeLimitsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeLimitsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ResourceNotFoundException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeTableReplicaAutoScalingCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeTableReplicaAutoScalingCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeTableReplicaAutoScalingOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeTableReplicaAutoScalingCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "ResourceNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0DescribeTimeToLiveCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DescribeTimeToLiveCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0DescribeTimeToLiveOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DescribeTimeToLiveCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ResourceNotFoundException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0DisableKinesisStreamingDestinationCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0DisableKinesisStreamingDestinationCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0KinesisStreamingDestinationOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0DisableKinesisStreamingDestinationCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0EnableKinesisStreamingDestinationCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0EnableKinesisStreamingDestinationCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0KinesisStreamingDestinationOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0EnableKinesisStreamingDestinationCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0ExecuteStatementCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ExecuteStatementCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ExecuteStatementOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ExecuteStatementCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ConditionalCheckFailedException": return [3, 2];
                    case "com.amazonaws.dynamodb#ConditionalCheckFailedException": return [3, 2];
                    case "DuplicateItemException": return [3, 4];
                    case "com.amazonaws.dynamodb#DuplicateItemException": return [3, 4];
                    case "InternalServerError": return [3, 6];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 6];
                    case "ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "ProvisionedThroughputExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 10];
                    case "RequestLimitExceeded": return [3, 12];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 12];
                    case "ResourceNotFoundException": return [3, 14];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 14];
                    case "TransactionConflictException": return [3, 16];
                    case "com.amazonaws.dynamodb#TransactionConflictException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0DuplicateItemExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0ExecuteTransactionCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ExecuteTransactionCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ExecuteTransactionOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ExecuteTransactionCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "IdempotentParameterMismatchException": return [3, 2];
                    case "com.amazonaws.dynamodb#IdempotentParameterMismatchException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                    case "TransactionCanceledException": return [3, 12];
                    case "com.amazonaws.dynamodb#TransactionCanceledException": return [3, 12];
                    case "TransactionInProgressException": return [3, 14];
                    case "com.amazonaws.dynamodb#TransactionInProgressException": return [3, 14];
                }
                return [3, 16];
            case 2: return [4, deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0TransactionInProgressExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 17;
            case 17: return [2];
        }
    });
}); };
var deserializeAws_json1_0ExportTableToPointInTimeCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ExportTableToPointInTimeCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ExportTableToPointInTimeOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ExportTableToPointInTimeCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ExportConflictException": return [3, 2];
                    case "com.amazonaws.dynamodb#ExportConflictException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidExportTimeException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidExportTimeException": return [3, 6];
                    case "LimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 8];
                    case "PointInTimeRecoveryUnavailableException": return [3, 10];
                    case "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException": return [3, 10];
                    case "TableNotFoundException": return [3, 12];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 12];
                }
                return [3, 14];
            case 2: return [4, deserializeAws_json1_0ExportConflictExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidExportTimeExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 15;
            case 15: return [2];
        }
    });
}); };
var deserializeAws_json1_0GetItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0GetItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0GetItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0GetItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0ImportTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ImportTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ImportTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ImportTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ImportConflictException": return [3, 2];
                    case "com.amazonaws.dynamodb#ImportConflictException": return [3, 2];
                    case "LimitExceededException": return [3, 4];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 4];
                    case "ResourceInUseException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0ImportConflictExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListBackupsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListBackupsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListBackupsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListBackupsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListContributorInsightsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListContributorInsightsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListContributorInsightsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListContributorInsightsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "ResourceNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListExportsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListExportsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListExportsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListExportsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "LimitExceededException": return [3, 4];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListGlobalTablesCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListGlobalTablesCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListGlobalTablesOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListGlobalTablesCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListImportsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListImportsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListImportsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListImportsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "LimitExceededException": return [3, 2];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 2];
                }
                return [3, 4];
            case 2: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 5;
            case 5: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListTablesCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListTablesCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListTablesOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListTablesCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0ListTagsOfResourceCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ListTagsOfResourceCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ListTagsOfResourceOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ListTagsOfResourceCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ResourceNotFoundException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 6];
                }
                return [3, 8];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 9;
            case 9: return [2];
        }
    });
}); };
var deserializeAws_json1_0PutItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0PutItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0PutItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0PutItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ConditionalCheckFailedException": return [3, 2];
                    case "com.amazonaws.dynamodb#ConditionalCheckFailedException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "ProvisionedThroughputExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 10];
                    case "RequestLimitExceeded": return [3, 12];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 12];
                    case "ResourceNotFoundException": return [3, 14];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 14];
                    case "TransactionConflictException": return [3, 16];
                    case "com.amazonaws.dynamodb#TransactionConflictException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0QueryCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0QueryCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0QueryOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0QueryCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0RestoreTableFromBackupCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0RestoreTableFromBackupCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0RestoreTableFromBackupOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0RestoreTableFromBackupCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "BackupInUseException": return [3, 2];
                    case "com.amazonaws.dynamodb#BackupInUseException": return [3, 2];
                    case "BackupNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#BackupNotFoundException": return [3, 4];
                    case "InternalServerError": return [3, 6];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 6];
                    case "InvalidEndpointException": return [3, 8];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 8];
                    case "LimitExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 10];
                    case "TableAlreadyExistsException": return [3, 12];
                    case "com.amazonaws.dynamodb#TableAlreadyExistsException": return [3, 12];
                    case "TableInUseException": return [3, 14];
                    case "com.amazonaws.dynamodb#TableInUseException": return [3, 14];
                }
                return [3, 16];
            case 2: return [4, deserializeAws_json1_0BackupInUseExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0BackupNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TableAlreadyExistsExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 17;
            case 17: return [2];
        }
    });
}); };
var deserializeAws_json1_0RestoreTableToPointInTimeCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0RestoreTableToPointInTimeCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0RestoreTableToPointInTimeOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0RestoreTableToPointInTimeCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "InvalidRestoreTimeException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidRestoreTimeException": return [3, 6];
                    case "LimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 8];
                    case "PointInTimeRecoveryUnavailableException": return [3, 10];
                    case "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException": return [3, 10];
                    case "TableAlreadyExistsException": return [3, 12];
                    case "com.amazonaws.dynamodb#TableAlreadyExistsException": return [3, 12];
                    case "TableInUseException": return [3, 14];
                    case "com.amazonaws.dynamodb#TableInUseException": return [3, 14];
                    case "TableNotFoundException": return [3, 16];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidRestoreTimeExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TableAlreadyExistsExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0TableInUseExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0ScanCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0ScanCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0ScanOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0ScanCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0TagResourceCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0TagResourceCommandError(output, context)];
                }
                return [4, collectBody(output.body, context)];
            case 1:
                _a.sent();
                response = {
                    $metadata: deserializeMetadata(output),
                };
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0TagResourceCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0TransactGetItemsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0TransactGetItemsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0TransactGetItemsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0TransactGetItemsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "ProvisionedThroughputExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 6];
                    case "RequestLimitExceeded": return [3, 8];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                    case "TransactionCanceledException": return [3, 12];
                    case "com.amazonaws.dynamodb#TransactionCanceledException": return [3, 12];
                }
                return [3, 14];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 15;
            case 15: return [2];
        }
    });
}); };
var deserializeAws_json1_0TransactWriteItemsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0TransactWriteItemsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0TransactWriteItemsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0TransactWriteItemsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "IdempotentParameterMismatchException": return [3, 2];
                    case "com.amazonaws.dynamodb#IdempotentParameterMismatchException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "ProvisionedThroughputExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 8];
                    case "RequestLimitExceeded": return [3, 10];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 10];
                    case "ResourceNotFoundException": return [3, 12];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 12];
                    case "TransactionCanceledException": return [3, 14];
                    case "com.amazonaws.dynamodb#TransactionCanceledException": return [3, 14];
                    case "TransactionInProgressException": return [3, 16];
                    case "com.amazonaws.dynamodb#TransactionInProgressException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0TransactionCanceledExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TransactionInProgressExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0UntagResourceCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UntagResourceCommandError(output, context)];
                }
                return [4, collectBody(output.body, context)];
            case 1:
                _a.sent();
                response = {
                    $metadata: deserializeMetadata(output),
                };
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UntagResourceCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateContinuousBackupsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateContinuousBackupsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateContinuousBackupsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateContinuousBackupsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ContinuousBackupsUnavailableException": return [3, 2];
                    case "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "TableNotFoundException": return [3, 8];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 8];
                }
                return [3, 10];
            case 2: return [4, deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 11;
            case 11: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateContributorInsightsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateContributorInsightsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateContributorInsightsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateContributorInsightsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "ResourceNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 4];
                }
                return [3, 6];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 7;
            case 7: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateGlobalTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateGlobalTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateGlobalTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateGlobalTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "GlobalTableNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#GlobalTableNotFoundException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "ReplicaAlreadyExistsException": return [3, 8];
                    case "com.amazonaws.dynamodb#ReplicaAlreadyExistsException": return [3, 8];
                    case "ReplicaNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ReplicaNotFoundException": return [3, 10];
                    case "TableNotFoundException": return [3, 12];
                    case "com.amazonaws.dynamodb#TableNotFoundException": return [3, 12];
                }
                return [3, 14];
            case 2: return [4, deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ReplicaAlreadyExistsExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ReplicaNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0TableNotFoundExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 15;
            case 15: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateGlobalTableSettingsCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateGlobalTableSettingsCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateGlobalTableSettingsOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateGlobalTableSettingsCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "GlobalTableNotFoundException": return [3, 2];
                    case "com.amazonaws.dynamodb#GlobalTableNotFoundException": return [3, 2];
                    case "IndexNotFoundException": return [3, 4];
                    case "com.amazonaws.dynamodb#IndexNotFoundException": return [3, 4];
                    case "InternalServerError": return [3, 6];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 6];
                    case "InvalidEndpointException": return [3, 8];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 8];
                    case "LimitExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 10];
                    case "ReplicaNotFoundException": return [3, 12];
                    case "com.amazonaws.dynamodb#ReplicaNotFoundException": return [3, 12];
                    case "ResourceInUseException": return [3, 14];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 14];
                }
                return [3, 16];
            case 2: return [4, deserializeAws_json1_0GlobalTableNotFoundExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0IndexNotFoundExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0ReplicaNotFoundExceptionResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 17;
            case 17: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateItemCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateItemCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateItemOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateItemCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "ConditionalCheckFailedException": return [3, 2];
                    case "com.amazonaws.dynamodb#ConditionalCheckFailedException": return [3, 2];
                    case "InternalServerError": return [3, 4];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 4];
                    case "InvalidEndpointException": return [3, 6];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 6];
                    case "ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException": return [3, 8];
                    case "ProvisionedThroughputExceededException": return [3, 10];
                    case "com.amazonaws.dynamodb#ProvisionedThroughputExceededException": return [3, 10];
                    case "RequestLimitExceeded": return [3, 12];
                    case "com.amazonaws.dynamodb#RequestLimitExceeded": return [3, 12];
                    case "ResourceNotFoundException": return [3, 14];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 14];
                    case "TransactionConflictException": return [3, 16];
                    case "com.amazonaws.dynamodb#TransactionConflictException": return [3, 16];
                }
                return [3, 18];
            case 2: return [4, deserializeAws_json1_0ConditionalCheckFailedExceptionResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12: return [4, deserializeAws_json1_0RequestLimitExceededResponse(parsedOutput, context)];
            case 13: throw _d.sent();
            case 14: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 15: throw _d.sent();
            case 16: return [4, deserializeAws_json1_0TransactionConflictExceptionResponse(parsedOutput, context)];
            case 17: throw _d.sent();
            case 18:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 19;
            case 19: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateTableCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateTableCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateTableOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateTableCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateTableReplicaAutoScalingCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateTableReplicaAutoScalingCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateTableReplicaAutoScalingOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateTableReplicaAutoScalingCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "LimitExceededException": return [3, 4];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 4];
                    case "ResourceInUseException": return [3, 6];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 6];
                    case "ResourceNotFoundException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 8];
                }
                return [3, 10];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 11;
            case 11: return [2];
        }
    });
}); };
var deserializeAws_json1_0UpdateTimeToLiveCommand = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var data, contents, response;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (output.statusCode >= 300) {
                    return [2, deserializeAws_json1_0UpdateTimeToLiveCommandError(output, context)];
                }
                return [4, parseBody(output.body, context)];
            case 1:
                data = _a.sent();
                contents = {};
                contents = deserializeAws_json1_0UpdateTimeToLiveOutput(data, context);
                response = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(output) }, contents);
                return [2, Promise.resolve(response)];
        }
    });
}); };
var deserializeAws_json1_0UpdateTimeToLiveCommandError = function (output, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var parsedOutput, _a, errorCode, _b, parsedBody;
    var _c;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_d) {
        switch (_d.label) {
            case 0:
                _a = [(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, output)];
                _c = {};
                return [4, parseErrorBody(output.body, context)];
            case 1:
                parsedOutput = tslib__WEBPACK_IMPORTED_MODULE_2__.__assign.apply(void 0, _a.concat([(_c.body = _d.sent(), _c)]));
                errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
                _b = errorCode;
                switch (_b) {
                    case "InternalServerError": return [3, 2];
                    case "com.amazonaws.dynamodb#InternalServerError": return [3, 2];
                    case "InvalidEndpointException": return [3, 4];
                    case "com.amazonaws.dynamodb#InvalidEndpointException": return [3, 4];
                    case "LimitExceededException": return [3, 6];
                    case "com.amazonaws.dynamodb#LimitExceededException": return [3, 6];
                    case "ResourceInUseException": return [3, 8];
                    case "com.amazonaws.dynamodb#ResourceInUseException": return [3, 8];
                    case "ResourceNotFoundException": return [3, 10];
                    case "com.amazonaws.dynamodb#ResourceNotFoundException": return [3, 10];
                }
                return [3, 12];
            case 2: return [4, deserializeAws_json1_0InternalServerErrorResponse(parsedOutput, context)];
            case 3: throw _d.sent();
            case 4: return [4, deserializeAws_json1_0InvalidEndpointExceptionResponse(parsedOutput, context)];
            case 5: throw _d.sent();
            case 6: return [4, deserializeAws_json1_0LimitExceededExceptionResponse(parsedOutput, context)];
            case 7: throw _d.sent();
            case 8: return [4, deserializeAws_json1_0ResourceInUseExceptionResponse(parsedOutput, context)];
            case 9: throw _d.sent();
            case 10: return [4, deserializeAws_json1_0ResourceNotFoundExceptionResponse(parsedOutput, context)];
            case 11: throw _d.sent();
            case 12:
                parsedBody = parsedOutput.body;
                (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.throwDefaultError)({
                    output: output,
                    parsedBody: parsedBody,
                    exceptionCtor: _models_DynamoDBServiceException__WEBPACK_IMPORTED_MODULE_3__.DynamoDBServiceException,
                    errorCode: errorCode,
                });
                _d.label = 13;
            case 13: return [2];
        }
    });
}); };
var deserializeAws_json1_0BackupInUseExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0BackupInUseException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.BackupInUseException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0BackupNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0BackupNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.BackupNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ConditionalCheckFailedExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ConditionalCheckFailedException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ConditionalCheckFailedException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ContinuousBackupsUnavailableExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ContinuousBackupsUnavailableException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ContinuousBackupsUnavailableException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0DuplicateItemExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0DuplicateItemException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.DuplicateItemException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ExportConflictExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ExportConflictException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ExportConflictException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ExportNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ExportNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ExportNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0GlobalTableAlreadyExistsExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0GlobalTableAlreadyExistsException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.GlobalTableAlreadyExistsException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0GlobalTableNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0GlobalTableNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.GlobalTableNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0IdempotentParameterMismatchExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0IdempotentParameterMismatchException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.IdempotentParameterMismatchException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ImportConflictExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ImportConflictException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ImportConflictException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ImportNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ImportNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ImportNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0IndexNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0IndexNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.IndexNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0InternalServerErrorResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0InternalServerError(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.InternalServerError((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0InvalidEndpointExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0InvalidEndpointException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.InvalidEndpointException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0InvalidExportTimeExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0InvalidExportTimeException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.InvalidExportTimeException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0InvalidRestoreTimeExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0InvalidRestoreTimeException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.InvalidRestoreTimeException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ItemCollectionSizeLimitExceededExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ItemCollectionSizeLimitExceededException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ItemCollectionSizeLimitExceededException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0LimitExceededExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0LimitExceededException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.LimitExceededException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0PointInTimeRecoveryUnavailableExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0PointInTimeRecoveryUnavailableException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.PointInTimeRecoveryUnavailableException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ProvisionedThroughputExceededExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ProvisionedThroughputExceededException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ProvisionedThroughputExceededException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ReplicaAlreadyExistsExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ReplicaAlreadyExistsException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ReplicaAlreadyExistsException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ReplicaNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ReplicaNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ReplicaNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0RequestLimitExceededResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0RequestLimitExceeded(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.RequestLimitExceeded((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ResourceInUseExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ResourceInUseException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ResourceInUseException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0ResourceNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0ResourceNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.ResourceNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TableAlreadyExistsExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TableAlreadyExistsException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TableAlreadyExistsException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TableInUseExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TableInUseException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TableInUseException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TableNotFoundExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TableNotFoundException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TableNotFoundException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TransactionCanceledExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TransactionCanceledException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TransactionCanceledException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TransactionConflictExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TransactionConflictException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TransactionConflictException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var deserializeAws_json1_0TransactionInProgressExceptionResponse = function (parsedOutput, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var body, deserialized, exception;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
        body = parsedOutput.body;
        deserialized = deserializeAws_json1_0TransactionInProgressException(body, context);
        exception = new _models_models_0__WEBPACK_IMPORTED_MODULE_4__.TransactionInProgressException((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ $metadata: deserializeMetadata(parsedOutput) }, deserialized));
        return [2, (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.decorateServiceException)(exception, body)];
    });
}); };
var serializeAws_json1_0AttributeDefinition = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeName != null && { AttributeName: input.AttributeName })), (input.AttributeType != null && { AttributeType: input.AttributeType }));
};
var serializeAws_json1_0AttributeDefinitions = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0AttributeDefinition(entry, context);
    });
};
var serializeAws_json1_0AttributeNameList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0AttributeUpdates = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0AttributeValueUpdate(value, context), _b));
    }, {});
};
var serializeAws_json1_0AttributeValue = function (input, context) {
    return _models_models_0__WEBPACK_IMPORTED_MODULE_4__.AttributeValue.visit(input, {
        B: function (value) { return ({ B: context.base64Encoder(value) }); },
        BOOL: function (value) { return ({ BOOL: value }); },
        BS: function (value) { return ({ BS: serializeAws_json1_0BinarySetAttributeValue(value, context) }); },
        L: function (value) { return ({ L: serializeAws_json1_0ListAttributeValue(value, context) }); },
        M: function (value) { return ({ M: serializeAws_json1_0MapAttributeValue(value, context) }); },
        N: function (value) { return ({ N: value }); },
        NS: function (value) { return ({ NS: serializeAws_json1_0NumberSetAttributeValue(value, context) }); },
        NULL: function (value) { return ({ NULL: value }); },
        S: function (value) { return ({ S: value }); },
        SS: function (value) { return ({ SS: serializeAws_json1_0StringSetAttributeValue(value, context) }); },
        _: function (name, value) { return ({ name: value }); },
    });
};
var serializeAws_json1_0AttributeValueList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
var serializeAws_json1_0AttributeValueUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Action != null && { Action: input.Action })), (input.Value != null && { Value: serializeAws_json1_0AttributeValue(input.Value, context) }));
};
var serializeAws_json1_0AutoScalingPolicyUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.PolicyName != null && { PolicyName: input.PolicyName })), (input.TargetTrackingScalingPolicyConfiguration != null && {
        TargetTrackingScalingPolicyConfiguration: serializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationUpdate(input.TargetTrackingScalingPolicyConfiguration, context),
    }));
};
var serializeAws_json1_0AutoScalingSettingsUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AutoScalingDisabled != null && { AutoScalingDisabled: input.AutoScalingDisabled })), (input.AutoScalingRoleArn != null && { AutoScalingRoleArn: input.AutoScalingRoleArn })), (input.MaximumUnits != null && { MaximumUnits: input.MaximumUnits })), (input.MinimumUnits != null && { MinimumUnits: input.MinimumUnits })), (input.ScalingPolicyUpdate != null && {
        ScalingPolicyUpdate: serializeAws_json1_0AutoScalingPolicyUpdate(input.ScalingPolicyUpdate, context),
    }));
};
var serializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.DisableScaleIn != null && { DisableScaleIn: input.DisableScaleIn })), (input.ScaleInCooldown != null && { ScaleInCooldown: input.ScaleInCooldown })), (input.ScaleOutCooldown != null && { ScaleOutCooldown: input.ScaleOutCooldown })), (input.TargetValue != null && { TargetValue: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.serializeFloat)(input.TargetValue) }));
};
var serializeAws_json1_0BatchExecuteStatementInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.Statements != null && { Statements: serializeAws_json1_0PartiQLBatchRequest(input.Statements, context) }));
};
var serializeAws_json1_0BatchGetItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RequestItems != null && {
        RequestItems: serializeAws_json1_0BatchGetRequestMap(input.RequestItems, context),
    })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity }));
};
var serializeAws_json1_0BatchGetRequestMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0KeysAndAttributes(value, context), _b));
    }, {});
};
var serializeAws_json1_0BatchStatementRequest = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.Parameters != null && {
        Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
    })), (input.Statement != null && { Statement: input.Statement }));
};
var serializeAws_json1_0BatchWriteItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RequestItems != null && {
        RequestItems: serializeAws_json1_0BatchWriteItemRequestMap(input.RequestItems, context),
    })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ReturnItemCollectionMetrics != null && {
        ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
    }));
};
var serializeAws_json1_0BatchWriteItemRequestMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0WriteRequests(value, context), _b));
    }, {});
};
var serializeAws_json1_0BinarySetAttributeValue = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return context.base64Encoder(entry);
    });
};
var serializeAws_json1_0Condition = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeValueList != null && {
        AttributeValueList: serializeAws_json1_0AttributeValueList(input.AttributeValueList, context),
    })), (input.ComparisonOperator != null && { ComparisonOperator: input.ComparisonOperator }));
};
var serializeAws_json1_0ConditionCheck = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ReturnValuesOnConditionCheckFailure != null && {
        ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0CreateBackupInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BackupName != null && { BackupName: input.BackupName })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0CreateGlobalSecondaryIndexAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) })), (input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    }));
};
var serializeAws_json1_0CreateGlobalTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName })), (input.ReplicationGroup != null && {
        ReplicationGroup: serializeAws_json1_0ReplicaList(input.ReplicationGroup, context),
    }));
};
var serializeAws_json1_0CreateReplicaAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName }));
};
var serializeAws_json1_0CreateReplicationGroupMemberAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalSecondaryIndexes != null && {
        GlobalSecondaryIndexes: serializeAws_json1_0ReplicaGlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
    })), (input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId })), (input.ProvisionedThroughputOverride != null && {
        ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
    })), (input.RegionName != null && { RegionName: input.RegionName })), (input.TableClassOverride != null && { TableClassOverride: input.TableClassOverride }));
};
var serializeAws_json1_0CreateTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeDefinitions != null && {
        AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
    })), (input.BillingMode != null && { BillingMode: input.BillingMode })), (input.GlobalSecondaryIndexes != null && {
        GlobalSecondaryIndexes: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
    })), (input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) })), (input.LocalSecondaryIndexes != null && {
        LocalSecondaryIndexes: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexes, context),
    })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    })), (input.SSESpecification != null && {
        SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
    })), (input.StreamSpecification != null && {
        StreamSpecification: serializeAws_json1_0StreamSpecification(input.StreamSpecification, context),
    })), (input.TableClass != null && { TableClass: input.TableClass })), (input.TableName != null && { TableName: input.TableName })), (input.Tags != null && { Tags: serializeAws_json1_0TagList(input.Tags, context) }));
};
var serializeAws_json1_0CsvHeaderList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0CsvOptions = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Delimiter != null && { Delimiter: input.Delimiter })), (input.HeaderList != null && { HeaderList: serializeAws_json1_0CsvHeaderList(input.HeaderList, context) }));
};
var serializeAws_json1_0Delete = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ReturnValuesOnConditionCheckFailure != null && {
        ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DeleteBackupInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BackupArn != null && { BackupArn: input.BackupArn }));
};
var serializeAws_json1_0DeleteGlobalSecondaryIndexAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName }));
};
var serializeAws_json1_0DeleteItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator })), (input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ReturnItemCollectionMetrics != null && {
        ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
    })), (input.ReturnValues != null && { ReturnValues: input.ReturnValues })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DeleteReplicaAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName }));
};
var serializeAws_json1_0DeleteReplicationGroupMemberAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName }));
};
var serializeAws_json1_0DeleteRequest = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) }));
};
var serializeAws_json1_0DeleteTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeBackupInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BackupArn != null && { BackupArn: input.BackupArn }));
};
var serializeAws_json1_0DescribeContinuousBackupsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeContributorInsightsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeEndpointsRequest = function (input, context) {
    return {};
};
var serializeAws_json1_0DescribeExportInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ExportArn != null && { ExportArn: input.ExportArn }));
};
var serializeAws_json1_0DescribeGlobalTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }));
};
var serializeAws_json1_0DescribeGlobalTableSettingsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName }));
};
var serializeAws_json1_0DescribeImportInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ImportArn != null && { ImportArn: input.ImportArn }));
};
var serializeAws_json1_0DescribeKinesisStreamingDestinationInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeLimitsInput = function (input, context) {
    return {};
};
var serializeAws_json1_0DescribeTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeTableReplicaAutoScalingInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0DescribeTimeToLiveInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0ExecuteStatementInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.Limit != null && { Limit: input.Limit })), (input.NextToken != null && { NextToken: input.NextToken })), (input.Parameters != null && {
        Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
    })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.Statement != null && { Statement: input.Statement }));
};
var serializeAws_json1_0ExecuteTransactionInput = function (input, context) {
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ ClientRequestToken: (_a = input.ClientRequestToken) !== null && _a !== void 0 ? _a : (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])() }, (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.TransactStatements != null && {
        TransactStatements: serializeAws_json1_0ParameterizedStatements(input.TransactStatements, context),
    }));
};
var serializeAws_json1_0ExpectedAttributeMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0ExpectedAttributeValue(value, context), _b));
    }, {});
};
var serializeAws_json1_0ExpectedAttributeValue = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeValueList != null && {
        AttributeValueList: serializeAws_json1_0AttributeValueList(input.AttributeValueList, context),
    })), (input.ComparisonOperator != null && { ComparisonOperator: input.ComparisonOperator })), (input.Exists != null && { Exists: input.Exists })), (input.Value != null && { Value: serializeAws_json1_0AttributeValue(input.Value, context) }));
};
var serializeAws_json1_0ExportTableToPointInTimeInput = function (input, context) {
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ ClientToken: (_a = input.ClientToken) !== null && _a !== void 0 ? _a : (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])() }, (input.ExportFormat != null && { ExportFormat: input.ExportFormat })), (input.ExportTime != null && { ExportTime: Math.round(input.ExportTime.getTime() / 1000) })), (input.S3Bucket != null && { S3Bucket: input.S3Bucket })), (input.S3BucketOwner != null && { S3BucketOwner: input.S3BucketOwner })), (input.S3Prefix != null && { S3Prefix: input.S3Prefix })), (input.S3SseAlgorithm != null && { S3SseAlgorithm: input.S3SseAlgorithm })), (input.S3SseKmsKeyId != null && { S3SseKmsKeyId: input.S3SseKmsKeyId })), (input.TableArn != null && { TableArn: input.TableArn }));
};
var serializeAws_json1_0ExpressionAttributeNameMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = value, _b));
    }, {});
};
var serializeAws_json1_0ExpressionAttributeValueMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0AttributeValue(value, context), _b));
    }, {});
};
var serializeAws_json1_0FilterConditionMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0Condition(value, context), _b));
    }, {});
};
var serializeAws_json1_0Get = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0GetItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributesToGet != null && {
        AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
    })), (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0GlobalSecondaryIndex = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) })), (input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    }));
};
var serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedWriteCapacityAutoScalingUpdate != null && {
        ProvisionedWriteCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingUpdate, context),
    }));
};
var serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdate(entry, context);
    });
};
var serializeAws_json1_0GlobalSecondaryIndexList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0GlobalSecondaryIndex(entry, context);
    });
};
var serializeAws_json1_0GlobalSecondaryIndexUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Create != null && {
        Create: serializeAws_json1_0CreateGlobalSecondaryIndexAction(input.Create, context),
    })), (input.Delete != null && {
        Delete: serializeAws_json1_0DeleteGlobalSecondaryIndexAction(input.Delete, context),
    })), (input.Update != null && {
        Update: serializeAws_json1_0UpdateGlobalSecondaryIndexAction(input.Update, context),
    }));
};
var serializeAws_json1_0GlobalSecondaryIndexUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0GlobalSecondaryIndexUpdate(entry, context);
    });
};
var serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedWriteCapacityAutoScalingSettingsUpdate != null && {
        ProvisionedWriteCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingSettingsUpdate, context),
    })), (input.ProvisionedWriteCapacityUnits != null && {
        ProvisionedWriteCapacityUnits: input.ProvisionedWriteCapacityUnits,
    }));
};
var serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdate(entry, context);
    });
};
var serializeAws_json1_0ImportTableInput = function (input, context) {
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ ClientToken: (_a = input.ClientToken) !== null && _a !== void 0 ? _a : (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])() }, (input.InputCompressionType != null && { InputCompressionType: input.InputCompressionType })), (input.InputFormat != null && { InputFormat: input.InputFormat })), (input.InputFormatOptions != null && {
        InputFormatOptions: serializeAws_json1_0InputFormatOptions(input.InputFormatOptions, context),
    })), (input.S3BucketSource != null && {
        S3BucketSource: serializeAws_json1_0S3BucketSource(input.S3BucketSource, context),
    })), (input.TableCreationParameters != null && {
        TableCreationParameters: serializeAws_json1_0TableCreationParameters(input.TableCreationParameters, context),
    }));
};
var serializeAws_json1_0InputFormatOptions = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Csv != null && { Csv: serializeAws_json1_0CsvOptions(input.Csv, context) }));
};
var serializeAws_json1_0Key = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0AttributeValue(value, context), _b));
    }, {});
};
var serializeAws_json1_0KeyConditions = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0Condition(value, context), _b));
    }, {});
};
var serializeAws_json1_0KeyList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0Key(entry, context);
    });
};
var serializeAws_json1_0KeysAndAttributes = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributesToGet != null && {
        AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
    })), (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.Keys != null && { Keys: serializeAws_json1_0KeyList(input.Keys, context) })), (input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression }));
};
var serializeAws_json1_0KeySchema = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0KeySchemaElement(entry, context);
    });
};
var serializeAws_json1_0KeySchemaElement = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeName != null && { AttributeName: input.AttributeName })), (input.KeyType != null && { KeyType: input.KeyType }));
};
var serializeAws_json1_0KinesisStreamingDestinationInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.StreamArn != null && { StreamArn: input.StreamArn })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0ListAttributeValue = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
var serializeAws_json1_0ListBackupsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BackupType != null && { BackupType: input.BackupType })), (input.ExclusiveStartBackupArn != null && { ExclusiveStartBackupArn: input.ExclusiveStartBackupArn })), (input.Limit != null && { Limit: input.Limit })), (input.TableName != null && { TableName: input.TableName })), (input.TimeRangeLowerBound != null && {
        TimeRangeLowerBound: Math.round(input.TimeRangeLowerBound.getTime() / 1000),
    })), (input.TimeRangeUpperBound != null && {
        TimeRangeUpperBound: Math.round(input.TimeRangeUpperBound.getTime() / 1000),
    }));
};
var serializeAws_json1_0ListContributorInsightsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.MaxResults != null && { MaxResults: input.MaxResults })), (input.NextToken != null && { NextToken: input.NextToken })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0ListExportsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.MaxResults != null && { MaxResults: input.MaxResults })), (input.NextToken != null && { NextToken: input.NextToken })), (input.TableArn != null && { TableArn: input.TableArn }));
};
var serializeAws_json1_0ListGlobalTablesInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ExclusiveStartGlobalTableName != null && {
        ExclusiveStartGlobalTableName: input.ExclusiveStartGlobalTableName,
    })), (input.Limit != null && { Limit: input.Limit })), (input.RegionName != null && { RegionName: input.RegionName }));
};
var serializeAws_json1_0ListImportsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.NextToken != null && { NextToken: input.NextToken })), (input.PageSize != null && { PageSize: input.PageSize })), (input.TableArn != null && { TableArn: input.TableArn }));
};
var serializeAws_json1_0ListTablesInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ExclusiveStartTableName != null && { ExclusiveStartTableName: input.ExclusiveStartTableName })), (input.Limit != null && { Limit: input.Limit }));
};
var serializeAws_json1_0ListTagsOfResourceInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.NextToken != null && { NextToken: input.NextToken })), (input.ResourceArn != null && { ResourceArn: input.ResourceArn }));
};
var serializeAws_json1_0LocalSecondaryIndex = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) })), (input.Projection != null && { Projection: serializeAws_json1_0Projection(input.Projection, context) }));
};
var serializeAws_json1_0LocalSecondaryIndexList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0LocalSecondaryIndex(entry, context);
    });
};
var serializeAws_json1_0MapAttributeValue = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0AttributeValue(value, context), _b));
    }, {});
};
var serializeAws_json1_0NonKeyAttributeNameList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0NumberSetAttributeValue = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0ParameterizedStatement = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Parameters != null && {
        Parameters: serializeAws_json1_0PreparedStatementParameters(input.Parameters, context),
    })), (input.Statement != null && { Statement: input.Statement }));
};
var serializeAws_json1_0ParameterizedStatements = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ParameterizedStatement(entry, context);
    });
};
var serializeAws_json1_0PartiQLBatchRequest = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0BatchStatementRequest(entry, context);
    });
};
var serializeAws_json1_0PointInTimeRecoverySpecification = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.PointInTimeRecoveryEnabled != null && { PointInTimeRecoveryEnabled: input.PointInTimeRecoveryEnabled }));
};
var serializeAws_json1_0PreparedStatementParameters = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0AttributeValue(entry, context);
    });
};
var serializeAws_json1_0Projection = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.NonKeyAttributes != null && {
        NonKeyAttributes: serializeAws_json1_0NonKeyAttributeNameList(input.NonKeyAttributes, context),
    })), (input.ProjectionType != null && { ProjectionType: input.ProjectionType }));
};
var serializeAws_json1_0ProvisionedThroughput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ReadCapacityUnits != null && { ReadCapacityUnits: input.ReadCapacityUnits })), (input.WriteCapacityUnits != null && { WriteCapacityUnits: input.WriteCapacityUnits }));
};
var serializeAws_json1_0ProvisionedThroughputOverride = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ReadCapacityUnits != null && { ReadCapacityUnits: input.ReadCapacityUnits }));
};
var serializeAws_json1_0Put = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) })), (input.ReturnValuesOnConditionCheckFailure != null && {
        ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0PutItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator })), (input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ReturnItemCollectionMetrics != null && {
        ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
    })), (input.ReturnValues != null && { ReturnValues: input.ReturnValues })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0PutItemInputAttributeMap = function (input, context) {
    return Object.entries(input).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = serializeAws_json1_0AttributeValue(value, context), _b));
    }, {});
};
var serializeAws_json1_0PutRequest = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Item != null && { Item: serializeAws_json1_0PutItemInputAttributeMap(input.Item, context) }));
};
var serializeAws_json1_0QueryInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributesToGet != null && {
        AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
    })), (input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator })), (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.ExclusiveStartKey != null && {
        ExclusiveStartKey: serializeAws_json1_0Key(input.ExclusiveStartKey, context),
    })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.FilterExpression != null && { FilterExpression: input.FilterExpression })), (input.IndexName != null && { IndexName: input.IndexName })), (input.KeyConditionExpression != null && { KeyConditionExpression: input.KeyConditionExpression })), (input.KeyConditions != null && {
        KeyConditions: serializeAws_json1_0KeyConditions(input.KeyConditions, context),
    })), (input.Limit != null && { Limit: input.Limit })), (input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression })), (input.QueryFilter != null && {
        QueryFilter: serializeAws_json1_0FilterConditionMap(input.QueryFilter, context),
    })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ScanIndexForward != null && { ScanIndexForward: input.ScanIndexForward })), (input.Select != null && { Select: input.Select })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0Replica = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName }));
};
var serializeAws_json1_0ReplicaAutoScalingUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName })), (input.ReplicaGlobalSecondaryIndexUpdates != null && {
        ReplicaGlobalSecondaryIndexUpdates: serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdateList(input.ReplicaGlobalSecondaryIndexUpdates, context),
    })), (input.ReplicaProvisionedReadCapacityAutoScalingUpdate != null && {
        ReplicaProvisionedReadCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ReplicaProvisionedReadCapacityAutoScalingUpdate, context),
    }));
};
var serializeAws_json1_0ReplicaAutoScalingUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaAutoScalingUpdate(entry, context);
    });
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndex = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedThroughputOverride != null && {
        ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
    }));
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedReadCapacityAutoScalingUpdate != null && {
        ProvisionedReadCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedReadCapacityAutoScalingUpdate, context),
    }));
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingUpdate(entry, context);
    });
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndexList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndex(entry, context);
    });
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedReadCapacityAutoScalingSettingsUpdate != null && {
        ProvisionedReadCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedReadCapacityAutoScalingSettingsUpdate, context),
    })), (input.ProvisionedReadCapacityUnits != null && {
        ProvisionedReadCapacityUnits: input.ProvisionedReadCapacityUnits,
    }));
};
var serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdate(entry, context);
    });
};
var serializeAws_json1_0ReplicaList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0Replica(entry, context);
    });
};
var serializeAws_json1_0ReplicaSettingsUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.RegionName != null && { RegionName: input.RegionName })), (input.ReplicaGlobalSecondaryIndexSettingsUpdate != null && {
        ReplicaGlobalSecondaryIndexSettingsUpdate: serializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsUpdateList(input.ReplicaGlobalSecondaryIndexSettingsUpdate, context),
    })), (input.ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate != null && {
        ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate, context),
    })), (input.ReplicaProvisionedReadCapacityUnits != null && {
        ReplicaProvisionedReadCapacityUnits: input.ReplicaProvisionedReadCapacityUnits,
    })), (input.ReplicaTableClass != null && { ReplicaTableClass: input.ReplicaTableClass }));
};
var serializeAws_json1_0ReplicaSettingsUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaSettingsUpdate(entry, context);
    });
};
var serializeAws_json1_0ReplicationGroupUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Create != null && {
        Create: serializeAws_json1_0CreateReplicationGroupMemberAction(input.Create, context),
    })), (input.Delete != null && {
        Delete: serializeAws_json1_0DeleteReplicationGroupMemberAction(input.Delete, context),
    })), (input.Update != null && {
        Update: serializeAws_json1_0UpdateReplicationGroupMemberAction(input.Update, context),
    }));
};
var serializeAws_json1_0ReplicationGroupUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicationGroupUpdate(entry, context);
    });
};
var serializeAws_json1_0ReplicaUpdate = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Create != null && { Create: serializeAws_json1_0CreateReplicaAction(input.Create, context) })), (input.Delete != null && { Delete: serializeAws_json1_0DeleteReplicaAction(input.Delete, context) }));
};
var serializeAws_json1_0ReplicaUpdateList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0ReplicaUpdate(entry, context);
    });
};
var serializeAws_json1_0RestoreTableFromBackupInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BackupArn != null && { BackupArn: input.BackupArn })), (input.BillingModeOverride != null && { BillingModeOverride: input.BillingModeOverride })), (input.GlobalSecondaryIndexOverride != null && {
        GlobalSecondaryIndexOverride: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexOverride, context),
    })), (input.LocalSecondaryIndexOverride != null && {
        LocalSecondaryIndexOverride: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexOverride, context),
    })), (input.ProvisionedThroughputOverride != null && {
        ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughputOverride, context),
    })), (input.SSESpecificationOverride != null && {
        SSESpecificationOverride: serializeAws_json1_0SSESpecification(input.SSESpecificationOverride, context),
    })), (input.TargetTableName != null && { TargetTableName: input.TargetTableName }));
};
var serializeAws_json1_0RestoreTableToPointInTimeInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.BillingModeOverride != null && { BillingModeOverride: input.BillingModeOverride })), (input.GlobalSecondaryIndexOverride != null && {
        GlobalSecondaryIndexOverride: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexOverride, context),
    })), (input.LocalSecondaryIndexOverride != null && {
        LocalSecondaryIndexOverride: serializeAws_json1_0LocalSecondaryIndexList(input.LocalSecondaryIndexOverride, context),
    })), (input.ProvisionedThroughputOverride != null && {
        ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughputOverride, context),
    })), (input.RestoreDateTime != null && { RestoreDateTime: Math.round(input.RestoreDateTime.getTime() / 1000) })), (input.SSESpecificationOverride != null && {
        SSESpecificationOverride: serializeAws_json1_0SSESpecification(input.SSESpecificationOverride, context),
    })), (input.SourceTableArn != null && { SourceTableArn: input.SourceTableArn })), (input.SourceTableName != null && { SourceTableName: input.SourceTableName })), (input.TargetTableName != null && { TargetTableName: input.TargetTableName })), (input.UseLatestRestorableTime != null && { UseLatestRestorableTime: input.UseLatestRestorableTime }));
};
var serializeAws_json1_0S3BucketSource = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.S3Bucket != null && { S3Bucket: input.S3Bucket })), (input.S3BucketOwner != null && { S3BucketOwner: input.S3BucketOwner })), (input.S3KeyPrefix != null && { S3KeyPrefix: input.S3KeyPrefix }));
};
var serializeAws_json1_0ScanInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributesToGet != null && {
        AttributesToGet: serializeAws_json1_0AttributeNameList(input.AttributesToGet, context),
    })), (input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator })), (input.ConsistentRead != null && { ConsistentRead: input.ConsistentRead })), (input.ExclusiveStartKey != null && {
        ExclusiveStartKey: serializeAws_json1_0Key(input.ExclusiveStartKey, context),
    })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.FilterExpression != null && { FilterExpression: input.FilterExpression })), (input.IndexName != null && { IndexName: input.IndexName })), (input.Limit != null && { Limit: input.Limit })), (input.ProjectionExpression != null && { ProjectionExpression: input.ProjectionExpression })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ScanFilter != null && { ScanFilter: serializeAws_json1_0FilterConditionMap(input.ScanFilter, context) })), (input.Segment != null && { Segment: input.Segment })), (input.Select != null && { Select: input.Select })), (input.TableName != null && { TableName: input.TableName })), (input.TotalSegments != null && { TotalSegments: input.TotalSegments }));
};
var serializeAws_json1_0SSESpecification = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Enabled != null && { Enabled: input.Enabled })), (input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId })), (input.SSEType != null && { SSEType: input.SSEType }));
};
var serializeAws_json1_0StreamSpecification = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.StreamEnabled != null && { StreamEnabled: input.StreamEnabled })), (input.StreamViewType != null && { StreamViewType: input.StreamViewType }));
};
var serializeAws_json1_0StringSetAttributeValue = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0TableCreationParameters = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeDefinitions != null && {
        AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
    })), (input.BillingMode != null && { BillingMode: input.BillingMode })), (input.GlobalSecondaryIndexes != null && {
        GlobalSecondaryIndexes: serializeAws_json1_0GlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
    })), (input.KeySchema != null && { KeySchema: serializeAws_json1_0KeySchema(input.KeySchema, context) })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    })), (input.SSESpecification != null && {
        SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0Tag = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Key != null && { Key: input.Key })), (input.Value != null && { Value: input.Value }));
};
var serializeAws_json1_0TagKeyList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return entry;
    });
};
var serializeAws_json1_0TagList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0Tag(entry, context);
    });
};
var serializeAws_json1_0TagResourceInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ResourceArn != null && { ResourceArn: input.ResourceArn })), (input.Tags != null && { Tags: serializeAws_json1_0TagList(input.Tags, context) }));
};
var serializeAws_json1_0TimeToLiveSpecification = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeName != null && { AttributeName: input.AttributeName })), (input.Enabled != null && { Enabled: input.Enabled }));
};
var serializeAws_json1_0TransactGetItem = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.Get != null && { Get: serializeAws_json1_0Get(input.Get, context) }));
};
var serializeAws_json1_0TransactGetItemList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0TransactGetItem(entry, context);
    });
};
var serializeAws_json1_0TransactGetItemsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.TransactItems != null && {
        TransactItems: serializeAws_json1_0TransactGetItemList(input.TransactItems, context),
    }));
};
var serializeAws_json1_0TransactWriteItem = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionCheck != null && {
        ConditionCheck: serializeAws_json1_0ConditionCheck(input.ConditionCheck, context),
    })), (input.Delete != null && { Delete: serializeAws_json1_0Delete(input.Delete, context) })), (input.Put != null && { Put: serializeAws_json1_0Put(input.Put, context) })), (input.Update != null && { Update: serializeAws_json1_0Update(input.Update, context) }));
};
var serializeAws_json1_0TransactWriteItemList = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0TransactWriteItem(entry, context);
    });
};
var serializeAws_json1_0TransactWriteItemsInput = function (input, context) {
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({ ClientRequestToken: (_a = input.ClientRequestToken) !== null && _a !== void 0 ? _a : (0,uuid__WEBPACK_IMPORTED_MODULE_5__["default"])() }, (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ReturnItemCollectionMetrics != null && {
        ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
    })), (input.TransactItems != null && {
        TransactItems: serializeAws_json1_0TransactWriteItemList(input.TransactItems, context),
    }));
};
var serializeAws_json1_0UntagResourceInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ResourceArn != null && { ResourceArn: input.ResourceArn })), (input.TagKeys != null && { TagKeys: serializeAws_json1_0TagKeyList(input.TagKeys, context) }));
};
var serializeAws_json1_0Update = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ReturnValuesOnConditionCheckFailure != null && {
        ReturnValuesOnConditionCheckFailure: input.ReturnValuesOnConditionCheckFailure,
    })), (input.TableName != null && { TableName: input.TableName })), (input.UpdateExpression != null && { UpdateExpression: input.UpdateExpression }));
};
var serializeAws_json1_0UpdateContinuousBackupsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.PointInTimeRecoverySpecification != null && {
        PointInTimeRecoverySpecification: serializeAws_json1_0PointInTimeRecoverySpecification(input.PointInTimeRecoverySpecification, context),
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0UpdateContributorInsightsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.ContributorInsightsAction != null && { ContributorInsightsAction: input.ContributorInsightsAction })), (input.IndexName != null && { IndexName: input.IndexName })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0UpdateGlobalSecondaryIndexAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.IndexName != null && { IndexName: input.IndexName })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    }));
};
var serializeAws_json1_0UpdateGlobalTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName })), (input.ReplicaUpdates != null && {
        ReplicaUpdates: serializeAws_json1_0ReplicaUpdateList(input.ReplicaUpdates, context),
    }));
};
var serializeAws_json1_0UpdateGlobalTableSettingsInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalTableBillingMode != null && { GlobalTableBillingMode: input.GlobalTableBillingMode })), (input.GlobalTableGlobalSecondaryIndexSettingsUpdate != null && {
        GlobalTableGlobalSecondaryIndexSettingsUpdate: serializeAws_json1_0GlobalTableGlobalSecondaryIndexSettingsUpdateList(input.GlobalTableGlobalSecondaryIndexSettingsUpdate, context),
    })), (input.GlobalTableName != null && { GlobalTableName: input.GlobalTableName })), (input.GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate != null && {
        GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate, context),
    })), (input.GlobalTableProvisionedWriteCapacityUnits != null && {
        GlobalTableProvisionedWriteCapacityUnits: input.GlobalTableProvisionedWriteCapacityUnits,
    })), (input.ReplicaSettingsUpdate != null && {
        ReplicaSettingsUpdate: serializeAws_json1_0ReplicaSettingsUpdateList(input.ReplicaSettingsUpdate, context),
    }));
};
var serializeAws_json1_0UpdateItemInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeUpdates != null && {
        AttributeUpdates: serializeAws_json1_0AttributeUpdates(input.AttributeUpdates, context),
    })), (input.ConditionExpression != null && { ConditionExpression: input.ConditionExpression })), (input.ConditionalOperator != null && { ConditionalOperator: input.ConditionalOperator })), (input.Expected != null && { Expected: serializeAws_json1_0ExpectedAttributeMap(input.Expected, context) })), (input.ExpressionAttributeNames != null && {
        ExpressionAttributeNames: serializeAws_json1_0ExpressionAttributeNameMap(input.ExpressionAttributeNames, context),
    })), (input.ExpressionAttributeValues != null && {
        ExpressionAttributeValues: serializeAws_json1_0ExpressionAttributeValueMap(input.ExpressionAttributeValues, context),
    })), (input.Key != null && { Key: serializeAws_json1_0Key(input.Key, context) })), (input.ReturnConsumedCapacity != null && { ReturnConsumedCapacity: input.ReturnConsumedCapacity })), (input.ReturnItemCollectionMetrics != null && {
        ReturnItemCollectionMetrics: input.ReturnItemCollectionMetrics,
    })), (input.ReturnValues != null && { ReturnValues: input.ReturnValues })), (input.TableName != null && { TableName: input.TableName })), (input.UpdateExpression != null && { UpdateExpression: input.UpdateExpression }));
};
var serializeAws_json1_0UpdateReplicationGroupMemberAction = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalSecondaryIndexes != null && {
        GlobalSecondaryIndexes: serializeAws_json1_0ReplicaGlobalSecondaryIndexList(input.GlobalSecondaryIndexes, context),
    })), (input.KMSMasterKeyId != null && { KMSMasterKeyId: input.KMSMasterKeyId })), (input.ProvisionedThroughputOverride != null && {
        ProvisionedThroughputOverride: serializeAws_json1_0ProvisionedThroughputOverride(input.ProvisionedThroughputOverride, context),
    })), (input.RegionName != null && { RegionName: input.RegionName })), (input.TableClassOverride != null && { TableClassOverride: input.TableClassOverride }));
};
var serializeAws_json1_0UpdateTableInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.AttributeDefinitions != null && {
        AttributeDefinitions: serializeAws_json1_0AttributeDefinitions(input.AttributeDefinitions, context),
    })), (input.BillingMode != null && { BillingMode: input.BillingMode })), (input.GlobalSecondaryIndexUpdates != null && {
        GlobalSecondaryIndexUpdates: serializeAws_json1_0GlobalSecondaryIndexUpdateList(input.GlobalSecondaryIndexUpdates, context),
    })), (input.ProvisionedThroughput != null && {
        ProvisionedThroughput: serializeAws_json1_0ProvisionedThroughput(input.ProvisionedThroughput, context),
    })), (input.ReplicaUpdates != null && {
        ReplicaUpdates: serializeAws_json1_0ReplicationGroupUpdateList(input.ReplicaUpdates, context),
    })), (input.SSESpecification != null && {
        SSESpecification: serializeAws_json1_0SSESpecification(input.SSESpecification, context),
    })), (input.StreamSpecification != null && {
        StreamSpecification: serializeAws_json1_0StreamSpecification(input.StreamSpecification, context),
    })), (input.TableClass != null && { TableClass: input.TableClass })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0UpdateTableReplicaAutoScalingInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.GlobalSecondaryIndexUpdates != null && {
        GlobalSecondaryIndexUpdates: serializeAws_json1_0GlobalSecondaryIndexAutoScalingUpdateList(input.GlobalSecondaryIndexUpdates, context),
    })), (input.ProvisionedWriteCapacityAutoScalingUpdate != null && {
        ProvisionedWriteCapacityAutoScalingUpdate: serializeAws_json1_0AutoScalingSettingsUpdate(input.ProvisionedWriteCapacityAutoScalingUpdate, context),
    })), (input.ReplicaUpdates != null && {
        ReplicaUpdates: serializeAws_json1_0ReplicaAutoScalingUpdateList(input.ReplicaUpdates, context),
    })), (input.TableName != null && { TableName: input.TableName }));
};
var serializeAws_json1_0UpdateTimeToLiveInput = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.TableName != null && { TableName: input.TableName })), (input.TimeToLiveSpecification != null && {
        TimeToLiveSpecification: serializeAws_json1_0TimeToLiveSpecification(input.TimeToLiveSpecification, context),
    }));
};
var serializeAws_json1_0WriteRequest = function (input, context) {
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, (input.DeleteRequest != null && {
        DeleteRequest: serializeAws_json1_0DeleteRequest(input.DeleteRequest, context),
    })), (input.PutRequest != null && { PutRequest: serializeAws_json1_0PutRequest(input.PutRequest, context) }));
};
var serializeAws_json1_0WriteRequests = function (input, context) {
    return input
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        return serializeAws_json1_0WriteRequest(entry, context);
    });
};
var deserializeAws_json1_0ArchivalSummary = function (output, context) {
    return {
        ArchivalBackupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ArchivalBackupArn),
        ArchivalDateTime: output.ArchivalDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.ArchivalDateTime)))
            : undefined,
        ArchivalReason: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ArchivalReason),
    };
};
var deserializeAws_json1_0AttributeDefinition = function (output, context) {
    return {
        AttributeName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AttributeName),
        AttributeType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AttributeType),
    };
};
var deserializeAws_json1_0AttributeDefinitions = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeDefinition(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0AttributeMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(value), context), _b));
    }, {});
};
var deserializeAws_json1_0AttributeNameList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0AttributeValue = function (output, context) {
    if (output.B != null) {
        return {
            B: context.base64Decoder(output.B),
        };
    }
    if ((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.BOOL) !== undefined) {
        return { BOOL: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.BOOL) };
    }
    if (output.BS != null) {
        return {
            BS: deserializeAws_json1_0BinarySetAttributeValue(output.BS, context),
        };
    }
    if (output.L != null) {
        return {
            L: deserializeAws_json1_0ListAttributeValue(output.L, context),
        };
    }
    if (output.M != null) {
        return {
            M: deserializeAws_json1_0MapAttributeValue(output.M, context),
        };
    }
    if ((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.N) !== undefined) {
        return { N: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.N) };
    }
    if (output.NS != null) {
        return {
            NS: deserializeAws_json1_0NumberSetAttributeValue(output.NS, context),
        };
    }
    if ((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.NULL) !== undefined) {
        return { NULL: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.NULL) };
    }
    if ((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S) !== undefined) {
        return { S: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S) };
    }
    if (output.SS != null) {
        return {
            SS: deserializeAws_json1_0StringSetAttributeValue(output.SS, context),
        };
    }
    return { $unknown: Object.entries(output)[0] };
};
var deserializeAws_json1_0AutoScalingPolicyDescription = function (output, context) {
    return {
        PolicyName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.PolicyName),
        TargetTrackingScalingPolicyConfiguration: output.TargetTrackingScalingPolicyConfiguration != null
            ? deserializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationDescription(output.TargetTrackingScalingPolicyConfiguration, context)
            : undefined,
    };
};
var deserializeAws_json1_0AutoScalingPolicyDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AutoScalingPolicyDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0AutoScalingSettingsDescription = function (output, context) {
    return {
        AutoScalingDisabled: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.AutoScalingDisabled),
        AutoScalingRoleArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AutoScalingRoleArn),
        MaximumUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.MaximumUnits),
        MinimumUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.MinimumUnits),
        ScalingPolicies: output.ScalingPolicies != null
            ? deserializeAws_json1_0AutoScalingPolicyDescriptionList(output.ScalingPolicies, context)
            : undefined,
    };
};
var deserializeAws_json1_0AutoScalingTargetTrackingScalingPolicyConfigurationDescription = function (output, context) {
    return {
        DisableScaleIn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.DisableScaleIn),
        ScaleInCooldown: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.ScaleInCooldown),
        ScaleOutCooldown: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.ScaleOutCooldown),
        TargetValue: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.TargetValue),
    };
};
var deserializeAws_json1_0BackupDescription = function (output, context) {
    return {
        BackupDetails: output.BackupDetails != null ? deserializeAws_json1_0BackupDetails(output.BackupDetails, context) : undefined,
        SourceTableDetails: output.SourceTableDetails != null
            ? deserializeAws_json1_0SourceTableDetails(output.SourceTableDetails, context)
            : undefined,
        SourceTableFeatureDetails: output.SourceTableFeatureDetails != null
            ? deserializeAws_json1_0SourceTableFeatureDetails(output.SourceTableFeatureDetails, context)
            : undefined,
    };
};
var deserializeAws_json1_0BackupDetails = function (output, context) {
    return {
        BackupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupArn),
        BackupCreationDateTime: output.BackupCreationDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.BackupCreationDateTime)))
            : undefined,
        BackupExpiryDateTime: output.BackupExpiryDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.BackupExpiryDateTime)))
            : undefined,
        BackupName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupName),
        BackupSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.BackupSizeBytes),
        BackupStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupStatus),
        BackupType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupType),
    };
};
var deserializeAws_json1_0BackupInUseException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0BackupNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0BackupSummaries = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0BackupSummary(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0BackupSummary = function (output, context) {
    return {
        BackupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupArn),
        BackupCreationDateTime: output.BackupCreationDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.BackupCreationDateTime)))
            : undefined,
        BackupExpiryDateTime: output.BackupExpiryDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.BackupExpiryDateTime)))
            : undefined,
        BackupName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupName),
        BackupSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.BackupSizeBytes),
        BackupStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupStatus),
        BackupType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BackupType),
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
        TableId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableId),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0BatchExecuteStatementOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0PartiQLBatchResponse(output.Responses, context) : undefined,
    };
};
var deserializeAws_json1_0BatchGetItemOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0BatchGetResponseMap(output.Responses, context) : undefined,
        UnprocessedKeys: output.UnprocessedKeys != null
            ? deserializeAws_json1_0BatchGetRequestMap(output.UnprocessedKeys, context)
            : undefined,
    };
};
var deserializeAws_json1_0BatchGetRequestMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0KeysAndAttributes(value, context), _b));
    }, {});
};
var deserializeAws_json1_0BatchGetResponseMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0ItemList(value, context), _b));
    }, {});
};
var deserializeAws_json1_0BatchStatementError = function (output, context) {
    return {
        Code: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Code),
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0BatchStatementResponse = function (output, context) {
    return {
        Error: output.Error != null ? deserializeAws_json1_0BatchStatementError(output.Error, context) : undefined,
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0BatchWriteItemOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetricsPerTable(output.ItemCollectionMetrics, context)
            : undefined,
        UnprocessedItems: output.UnprocessedItems != null
            ? deserializeAws_json1_0BatchWriteItemRequestMap(output.UnprocessedItems, context)
            : undefined,
    };
};
var deserializeAws_json1_0BatchWriteItemRequestMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0WriteRequests(value, context), _b));
    }, {});
};
var deserializeAws_json1_0BillingModeSummary = function (output, context) {
    return {
        BillingMode: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BillingMode),
        LastUpdateToPayPerRequestDateTime: output.LastUpdateToPayPerRequestDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LastUpdateToPayPerRequestDateTime)))
            : undefined,
    };
};
var deserializeAws_json1_0BinarySetAttributeValue = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return context.base64Decoder(entry);
    });
    return retVal;
};
var deserializeAws_json1_0CancellationReason = function (output, context) {
    return {
        Code: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Code),
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0CancellationReasonList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0CancellationReason(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0Capacity = function (output, context) {
    return {
        CapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.CapacityUnits),
        ReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.ReadCapacityUnits),
        WriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.WriteCapacityUnits),
    };
};
var deserializeAws_json1_0ConditionalCheckFailedException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ConsumedCapacity = function (output, context) {
    return {
        CapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.CapacityUnits),
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0SecondaryIndexesCapacityMap(output.GlobalSecondaryIndexes, context)
            : undefined,
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0SecondaryIndexesCapacityMap(output.LocalSecondaryIndexes, context)
            : undefined,
        ReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.ReadCapacityUnits),
        Table: output.Table != null ? deserializeAws_json1_0Capacity(output.Table, context) : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
        WriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(output.WriteCapacityUnits),
    };
};
var deserializeAws_json1_0ConsumedCapacityMultiple = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ConsumedCapacity(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ContinuousBackupsDescription = function (output, context) {
    return {
        ContinuousBackupsStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ContinuousBackupsStatus),
        PointInTimeRecoveryDescription: output.PointInTimeRecoveryDescription != null
            ? deserializeAws_json1_0PointInTimeRecoveryDescription(output.PointInTimeRecoveryDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0ContinuousBackupsUnavailableException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ContributorInsightsRuleList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0ContributorInsightsSummaries = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ContributorInsightsSummary(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ContributorInsightsSummary = function (output, context) {
    return {
        ContributorInsightsStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ContributorInsightsStatus),
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0CreateBackupOutput = function (output, context) {
    return {
        BackupDetails: output.BackupDetails != null ? deserializeAws_json1_0BackupDetails(output.BackupDetails, context) : undefined,
    };
};
var deserializeAws_json1_0CreateGlobalTableOutput = function (output, context) {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0CreateTableOutput = function (output, context) {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0CsvHeaderList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0CsvOptions = function (output, context) {
    return {
        Delimiter: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Delimiter),
        HeaderList: output.HeaderList != null ? deserializeAws_json1_0CsvHeaderList(output.HeaderList, context) : undefined,
    };
};
var deserializeAws_json1_0DeleteBackupOutput = function (output, context) {
    return {
        BackupDescription: output.BackupDescription != null
            ? deserializeAws_json1_0BackupDescription(output.BackupDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DeleteItemOutput = function (output, context) {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
var deserializeAws_json1_0DeleteRequest = function (output, context) {
    return {
        Key: output.Key != null ? deserializeAws_json1_0Key(output.Key, context) : undefined,
    };
};
var deserializeAws_json1_0DeleteTableOutput = function (output, context) {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeBackupOutput = function (output, context) {
    return {
        BackupDescription: output.BackupDescription != null
            ? deserializeAws_json1_0BackupDescription(output.BackupDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeContinuousBackupsOutput = function (output, context) {
    return {
        ContinuousBackupsDescription: output.ContinuousBackupsDescription != null
            ? deserializeAws_json1_0ContinuousBackupsDescription(output.ContinuousBackupsDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeContributorInsightsOutput = function (output, context) {
    return {
        ContributorInsightsRuleList: output.ContributorInsightsRuleList != null
            ? deserializeAws_json1_0ContributorInsightsRuleList(output.ContributorInsightsRuleList, context)
            : undefined,
        ContributorInsightsStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ContributorInsightsStatus),
        FailureException: output.FailureException != null
            ? deserializeAws_json1_0FailureException(output.FailureException, context)
            : undefined,
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        LastUpdateDateTime: output.LastUpdateDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LastUpdateDateTime)))
            : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0DescribeEndpointsResponse = function (output, context) {
    return {
        Endpoints: output.Endpoints != null ? deserializeAws_json1_0Endpoints(output.Endpoints, context) : undefined,
    };
};
var deserializeAws_json1_0DescribeExportOutput = function (output, context) {
    return {
        ExportDescription: output.ExportDescription != null
            ? deserializeAws_json1_0ExportDescription(output.ExportDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeGlobalTableOutput = function (output, context) {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeGlobalTableSettingsOutput = function (output, context) {
    return {
        GlobalTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableName),
        ReplicaSettings: output.ReplicaSettings != null
            ? deserializeAws_json1_0ReplicaSettingsDescriptionList(output.ReplicaSettings, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeImportOutput = function (output, context) {
    return {
        ImportTableDescription: output.ImportTableDescription != null
            ? deserializeAws_json1_0ImportTableDescription(output.ImportTableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeKinesisStreamingDestinationOutput = function (output, context) {
    return {
        KinesisDataStreamDestinations: output.KinesisDataStreamDestinations != null
            ? deserializeAws_json1_0KinesisDataStreamDestinations(output.KinesisDataStreamDestinations, context)
            : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0DescribeLimitsOutput = function (output, context) {
    return {
        AccountMaxReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.AccountMaxReadCapacityUnits),
        AccountMaxWriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.AccountMaxWriteCapacityUnits),
        TableMaxReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.TableMaxReadCapacityUnits),
        TableMaxWriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.TableMaxWriteCapacityUnits),
    };
};
var deserializeAws_json1_0DescribeTableOutput = function (output, context) {
    return {
        Table: output.Table != null ? deserializeAws_json1_0TableDescription(output.Table, context) : undefined,
    };
};
var deserializeAws_json1_0DescribeTableReplicaAutoScalingOutput = function (output, context) {
    return {
        TableAutoScalingDescription: output.TableAutoScalingDescription != null
            ? deserializeAws_json1_0TableAutoScalingDescription(output.TableAutoScalingDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DescribeTimeToLiveOutput = function (output, context) {
    return {
        TimeToLiveDescription: output.TimeToLiveDescription != null
            ? deserializeAws_json1_0TimeToLiveDescription(output.TimeToLiveDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0DuplicateItemException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0Endpoint = function (output, context) {
    return {
        Address: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Address),
        CachePeriodInMinutes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.CachePeriodInMinutes),
    };
};
var deserializeAws_json1_0Endpoints = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Endpoint(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ExecuteStatementOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        NextToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.NextToken),
    };
};
var deserializeAws_json1_0ExecuteTransactionOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0ItemResponseList(output.Responses, context) : undefined,
    };
};
var deserializeAws_json1_0ExportConflictException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ExportDescription = function (output, context) {
    return {
        BilledSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.BilledSizeBytes),
        ClientToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ClientToken),
        EndTime: output.EndTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.EndTime))) : undefined,
        ExportArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportArn),
        ExportFormat: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportFormat),
        ExportManifest: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportManifest),
        ExportStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportStatus),
        ExportTime: output.ExportTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.ExportTime))) : undefined,
        FailureCode: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.FailureCode),
        FailureMessage: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.FailureMessage),
        ItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ItemCount),
        S3Bucket: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3Bucket),
        S3BucketOwner: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3BucketOwner),
        S3Prefix: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3Prefix),
        S3SseAlgorithm: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3SseAlgorithm),
        S3SseKmsKeyId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3SseKmsKeyId),
        StartTime: output.StartTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.StartTime))) : undefined,
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
        TableId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableId),
    };
};
var deserializeAws_json1_0ExportNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ExportSummaries = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ExportSummary(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ExportSummary = function (output, context) {
    return {
        ExportArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportArn),
        ExportStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExportStatus),
    };
};
var deserializeAws_json1_0ExportTableToPointInTimeOutput = function (output, context) {
    return {
        ExportDescription: output.ExportDescription != null
            ? deserializeAws_json1_0ExportDescription(output.ExportDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0ExpressionAttributeNameMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(value), _b));
    }, {});
};
var deserializeAws_json1_0FailureException = function (output, context) {
    return {
        ExceptionDescription: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExceptionDescription),
        ExceptionName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ExceptionName),
    };
};
var deserializeAws_json1_0GetItemOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
    };
};
var deserializeAws_json1_0GlobalSecondaryIndex = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
    };
};
var deserializeAws_json1_0GlobalSecondaryIndexDescription = function (output, context) {
    return {
        Backfilling: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.Backfilling),
        IndexArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexArn),
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        IndexSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.IndexSizeBytes),
        IndexStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexStatus),
        ItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughputDescription(output.ProvisionedThroughput, context)
            : undefined,
    };
};
var deserializeAws_json1_0GlobalSecondaryIndexDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0GlobalSecondaryIndexes = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndexInfo(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0GlobalSecondaryIndexInfo = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
    };
};
var deserializeAws_json1_0GlobalSecondaryIndexList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalSecondaryIndex(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0GlobalTable = function (output, context) {
    return {
        GlobalTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableName),
        ReplicationGroup: output.ReplicationGroup != null ? deserializeAws_json1_0ReplicaList(output.ReplicationGroup, context) : undefined,
    };
};
var deserializeAws_json1_0GlobalTableAlreadyExistsException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0GlobalTableDescription = function (output, context) {
    return {
        CreationDateTime: output.CreationDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.CreationDateTime)))
            : undefined,
        GlobalTableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableArn),
        GlobalTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableName),
        GlobalTableStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableStatus),
        ReplicationGroup: output.ReplicationGroup != null
            ? deserializeAws_json1_0ReplicaDescriptionList(output.ReplicationGroup, context)
            : undefined,
    };
};
var deserializeAws_json1_0GlobalTableList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0GlobalTable(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0GlobalTableNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0IdempotentParameterMismatchException = function (output, context) {
    return {
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0ImportConflictException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ImportNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ImportSummary = function (output, context) {
    return {
        CloudWatchLogGroupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.CloudWatchLogGroupArn),
        EndTime: output.EndTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.EndTime))) : undefined,
        ImportArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ImportArn),
        ImportStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ImportStatus),
        InputFormat: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.InputFormat),
        S3BucketSource: output.S3BucketSource != null ? deserializeAws_json1_0S3BucketSource(output.S3BucketSource, context) : undefined,
        StartTime: output.StartTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.StartTime))) : undefined,
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
    };
};
var deserializeAws_json1_0ImportSummaryList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ImportSummary(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ImportTableDescription = function (output, context) {
    return {
        ClientToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ClientToken),
        CloudWatchLogGroupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.CloudWatchLogGroupArn),
        EndTime: output.EndTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.EndTime))) : undefined,
        ErrorCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ErrorCount),
        FailureCode: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.FailureCode),
        FailureMessage: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.FailureMessage),
        ImportArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ImportArn),
        ImportStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ImportStatus),
        ImportedItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ImportedItemCount),
        InputCompressionType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.InputCompressionType),
        InputFormat: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.InputFormat),
        InputFormatOptions: output.InputFormatOptions != null
            ? deserializeAws_json1_0InputFormatOptions(output.InputFormatOptions, context)
            : undefined,
        ProcessedItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ProcessedItemCount),
        ProcessedSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ProcessedSizeBytes),
        S3BucketSource: output.S3BucketSource != null ? deserializeAws_json1_0S3BucketSource(output.S3BucketSource, context) : undefined,
        StartTime: output.StartTime != null ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.StartTime))) : undefined,
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
        TableCreationParameters: output.TableCreationParameters != null
            ? deserializeAws_json1_0TableCreationParameters(output.TableCreationParameters, context)
            : undefined,
        TableId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableId),
    };
};
var deserializeAws_json1_0ImportTableOutput = function (output, context) {
    return {
        ImportTableDescription: output.ImportTableDescription != null
            ? deserializeAws_json1_0ImportTableDescription(output.ImportTableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0IndexNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0InputFormatOptions = function (output, context) {
    return {
        Csv: output.Csv != null ? deserializeAws_json1_0CsvOptions(output.Csv, context) : undefined,
    };
};
var deserializeAws_json1_0InternalServerError = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0InvalidEndpointException = function (output, context) {
    return {
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0InvalidExportTimeException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0InvalidRestoreTimeException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ItemCollectionKeyAttributeMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(value), context), _b));
    }, {});
};
var deserializeAws_json1_0ItemCollectionMetrics = function (output, context) {
    return {
        ItemCollectionKey: output.ItemCollectionKey != null
            ? deserializeAws_json1_0ItemCollectionKeyAttributeMap(output.ItemCollectionKey, context)
            : undefined,
        SizeEstimateRangeGB: output.SizeEstimateRangeGB != null
            ? deserializeAws_json1_0ItemCollectionSizeEstimateRange(output.SizeEstimateRangeGB, context)
            : undefined,
    };
};
var deserializeAws_json1_0ItemCollectionMetricsMultiple = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ItemCollectionMetrics(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ItemCollectionMetricsPerTable = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0ItemCollectionMetricsMultiple(value, context), _b));
    }, {});
};
var deserializeAws_json1_0ItemCollectionSizeEstimateRange = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.limitedParseDouble)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0ItemCollectionSizeLimitExceededException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ItemList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeMap(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ItemResponse = function (output, context) {
    return {
        Item: output.Item != null ? deserializeAws_json1_0AttributeMap(output.Item, context) : undefined,
    };
};
var deserializeAws_json1_0ItemResponseList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ItemResponse(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0Key = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(value), context), _b));
    }, {});
};
var deserializeAws_json1_0KeyList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Key(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0KeysAndAttributes = function (output, context) {
    return {
        AttributesToGet: output.AttributesToGet != null
            ? deserializeAws_json1_0AttributeNameList(output.AttributesToGet, context)
            : undefined,
        ConsistentRead: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.ConsistentRead),
        ExpressionAttributeNames: output.ExpressionAttributeNames != null
            ? deserializeAws_json1_0ExpressionAttributeNameMap(output.ExpressionAttributeNames, context)
            : undefined,
        Keys: output.Keys != null ? deserializeAws_json1_0KeyList(output.Keys, context) : undefined,
        ProjectionExpression: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ProjectionExpression),
    };
};
var deserializeAws_json1_0KeySchema = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0KeySchemaElement(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0KeySchemaElement = function (output, context) {
    return {
        AttributeName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AttributeName),
        KeyType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.KeyType),
    };
};
var deserializeAws_json1_0KinesisDataStreamDestination = function (output, context) {
    return {
        DestinationStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.DestinationStatus),
        DestinationStatusDescription: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.DestinationStatusDescription),
        StreamArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.StreamArn),
    };
};
var deserializeAws_json1_0KinesisDataStreamDestinations = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0KinesisDataStreamDestination(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0KinesisStreamingDestinationOutput = function (output, context) {
    return {
        DestinationStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.DestinationStatus),
        StreamArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.StreamArn),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0LimitExceededException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ListAttributeValue = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(entry), context);
    });
    return retVal;
};
var deserializeAws_json1_0ListBackupsOutput = function (output, context) {
    return {
        BackupSummaries: output.BackupSummaries != null
            ? deserializeAws_json1_0BackupSummaries(output.BackupSummaries, context)
            : undefined,
        LastEvaluatedBackupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.LastEvaluatedBackupArn),
    };
};
var deserializeAws_json1_0ListContributorInsightsOutput = function (output, context) {
    return {
        ContributorInsightsSummaries: output.ContributorInsightsSummaries != null
            ? deserializeAws_json1_0ContributorInsightsSummaries(output.ContributorInsightsSummaries, context)
            : undefined,
        NextToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.NextToken),
    };
};
var deserializeAws_json1_0ListExportsOutput = function (output, context) {
    return {
        ExportSummaries: output.ExportSummaries != null
            ? deserializeAws_json1_0ExportSummaries(output.ExportSummaries, context)
            : undefined,
        NextToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.NextToken),
    };
};
var deserializeAws_json1_0ListGlobalTablesOutput = function (output, context) {
    return {
        GlobalTables: output.GlobalTables != null ? deserializeAws_json1_0GlobalTableList(output.GlobalTables, context) : undefined,
        LastEvaluatedGlobalTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.LastEvaluatedGlobalTableName),
    };
};
var deserializeAws_json1_0ListImportsOutput = function (output, context) {
    return {
        ImportSummaryList: output.ImportSummaryList != null
            ? deserializeAws_json1_0ImportSummaryList(output.ImportSummaryList, context)
            : undefined,
        NextToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.NextToken),
    };
};
var deserializeAws_json1_0ListTablesOutput = function (output, context) {
    return {
        LastEvaluatedTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.LastEvaluatedTableName),
        TableNames: output.TableNames != null ? deserializeAws_json1_0TableNameList(output.TableNames, context) : undefined,
    };
};
var deserializeAws_json1_0ListTagsOfResourceOutput = function (output, context) {
    return {
        NextToken: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.NextToken),
        Tags: output.Tags != null ? deserializeAws_json1_0TagList(output.Tags, context) : undefined,
    };
};
var deserializeAws_json1_0LocalSecondaryIndexDescription = function (output, context) {
    return {
        IndexArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexArn),
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        IndexSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.IndexSizeBytes),
        ItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
    };
};
var deserializeAws_json1_0LocalSecondaryIndexDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0LocalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0LocalSecondaryIndexes = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0LocalSecondaryIndexInfo(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0LocalSecondaryIndexInfo = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        Projection: output.Projection != null ? deserializeAws_json1_0Projection(output.Projection, context) : undefined,
    };
};
var deserializeAws_json1_0MapAttributeValue = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(value), context), _b));
    }, {});
};
var deserializeAws_json1_0NonKeyAttributeNameList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0NumberSetAttributeValue = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0PartiQLBatchResponse = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0BatchStatementResponse(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0PointInTimeRecoveryDescription = function (output, context) {
    return {
        EarliestRestorableDateTime: output.EarliestRestorableDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.EarliestRestorableDateTime)))
            : undefined,
        LatestRestorableDateTime: output.LatestRestorableDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LatestRestorableDateTime)))
            : undefined,
        PointInTimeRecoveryStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.PointInTimeRecoveryStatus),
    };
};
var deserializeAws_json1_0PointInTimeRecoveryUnavailableException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0Projection = function (output, context) {
    return {
        NonKeyAttributes: output.NonKeyAttributes != null
            ? deserializeAws_json1_0NonKeyAttributeNameList(output.NonKeyAttributes, context)
            : undefined,
        ProjectionType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ProjectionType),
    };
};
var deserializeAws_json1_0ProvisionedThroughput = function (output, context) {
    return {
        ReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ReadCapacityUnits),
        WriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.WriteCapacityUnits),
    };
};
var deserializeAws_json1_0ProvisionedThroughputDescription = function (output, context) {
    return {
        LastDecreaseDateTime: output.LastDecreaseDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LastDecreaseDateTime)))
            : undefined,
        LastIncreaseDateTime: output.LastIncreaseDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LastIncreaseDateTime)))
            : undefined,
        NumberOfDecreasesToday: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.NumberOfDecreasesToday),
        ReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ReadCapacityUnits),
        WriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.WriteCapacityUnits),
    };
};
var deserializeAws_json1_0ProvisionedThroughputExceededException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ProvisionedThroughputOverride = function (output, context) {
    return {
        ReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ReadCapacityUnits),
    };
};
var deserializeAws_json1_0PutItemInputAttributeMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0AttributeValue((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectUnion)(value), context), _b));
    }, {});
};
var deserializeAws_json1_0PutItemOutput = function (output, context) {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
var deserializeAws_json1_0PutRequest = function (output, context) {
    return {
        Item: output.Item != null ? deserializeAws_json1_0PutItemInputAttributeMap(output.Item, context) : undefined,
    };
};
var deserializeAws_json1_0QueryOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Count: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.Count),
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        ScannedCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.ScannedCount),
    };
};
var deserializeAws_json1_0Replica = function (output, context) {
    return {
        RegionName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.RegionName),
    };
};
var deserializeAws_json1_0ReplicaAlreadyExistsException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ReplicaAutoScalingDescription = function (output, context) {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        RegionName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.RegionName),
        ReplicaProvisionedReadCapacityAutoScalingSettings: output.ReplicaProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedWriteCapacityAutoScalingSettings: output.ReplicaProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ReplicaStatus),
    };
};
var deserializeAws_json1_0ReplicaAutoScalingDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaAutoScalingDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaDescription = function (output, context) {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        KMSMasterKeyId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.KMSMasterKeyId),
        ProvisionedThroughputOverride: output.ProvisionedThroughputOverride != null
            ? deserializeAws_json1_0ProvisionedThroughputOverride(output.ProvisionedThroughputOverride, context)
            : undefined,
        RegionName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.RegionName),
        ReplicaInaccessibleDateTime: output.ReplicaInaccessibleDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.ReplicaInaccessibleDateTime)))
            : undefined,
        ReplicaStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ReplicaStatus),
        ReplicaStatusDescription: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ReplicaStatusDescription),
        ReplicaStatusPercentProgress: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ReplicaStatusPercentProgress),
        ReplicaTableClassSummary: output.ReplicaTableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.ReplicaTableClassSummary, context)
            : undefined,
    };
};
var deserializeAws_json1_0ReplicaDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescription = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        IndexStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexStatus),
        ProvisionedReadCapacityAutoScalingSettings: output.ProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedWriteCapacityAutoScalingSettings: output.ProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
    };
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexAutoScalingDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescription = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        ProvisionedThroughputOverride: output.ProvisionedThroughputOverride != null
            ? deserializeAws_json1_0ProvisionedThroughputOverride(output.ProvisionedThroughputOverride, context)
            : undefined,
    };
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescription = function (output, context) {
    return {
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        IndexStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexStatus),
        ProvisionedReadCapacityAutoScalingSettings: output.ProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ProvisionedReadCapacityUnits),
        ProvisionedWriteCapacityAutoScalingSettings: output.ProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ProvisionedWriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ProvisionedWriteCapacityUnits),
    };
};
var deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Replica(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0ReplicaNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ReplicaSettingsDescription = function (output, context) {
    return {
        RegionName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.RegionName),
        ReplicaBillingModeSummary: output.ReplicaBillingModeSummary != null
            ? deserializeAws_json1_0BillingModeSummary(output.ReplicaBillingModeSummary, context)
            : undefined,
        ReplicaGlobalSecondaryIndexSettings: output.ReplicaGlobalSecondaryIndexSettings != null
            ? deserializeAws_json1_0ReplicaGlobalSecondaryIndexSettingsDescriptionList(output.ReplicaGlobalSecondaryIndexSettings, context)
            : undefined,
        ReplicaProvisionedReadCapacityAutoScalingSettings: output.ReplicaProvisionedReadCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedReadCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedReadCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ReplicaProvisionedReadCapacityUnits),
        ReplicaProvisionedWriteCapacityAutoScalingSettings: output.ReplicaProvisionedWriteCapacityAutoScalingSettings != null
            ? deserializeAws_json1_0AutoScalingSettingsDescription(output.ReplicaProvisionedWriteCapacityAutoScalingSettings, context)
            : undefined,
        ReplicaProvisionedWriteCapacityUnits: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ReplicaProvisionedWriteCapacityUnits),
        ReplicaStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ReplicaStatus),
        ReplicaTableClassSummary: output.ReplicaTableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.ReplicaTableClassSummary, context)
            : undefined,
    };
};
var deserializeAws_json1_0ReplicaSettingsDescriptionList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0ReplicaSettingsDescription(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0RequestLimitExceeded = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ResourceInUseException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0ResourceNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0RestoreSummary = function (output, context) {
    return {
        RestoreDateTime: output.RestoreDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.RestoreDateTime)))
            : undefined,
        RestoreInProgress: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.RestoreInProgress),
        SourceBackupArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.SourceBackupArn),
        SourceTableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.SourceTableArn),
    };
};
var deserializeAws_json1_0RestoreTableFromBackupOutput = function (output, context) {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0RestoreTableToPointInTimeOutput = function (output, context) {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0S3BucketSource = function (output, context) {
    return {
        S3Bucket: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3Bucket),
        S3BucketOwner: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3BucketOwner),
        S3KeyPrefix: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.S3KeyPrefix),
    };
};
var deserializeAws_json1_0ScanOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        Count: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.Count),
        Items: output.Items != null ? deserializeAws_json1_0ItemList(output.Items, context) : undefined,
        LastEvaluatedKey: output.LastEvaluatedKey != null ? deserializeAws_json1_0Key(output.LastEvaluatedKey, context) : undefined,
        ScannedCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectInt32)(output.ScannedCount),
    };
};
var deserializeAws_json1_0SecondaryIndexesCapacityMap = function (output, context) {
    return Object.entries(output).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__read)(_a, 2), key = _c[0], value = _c[1];
        if (value === null) {
            return acc;
        }
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_2__.__assign)({}, acc), (_b = {}, _b[key] = deserializeAws_json1_0Capacity(value, context), _b));
    }, {});
};
var deserializeAws_json1_0SourceTableDetails = function (output, context) {
    return {
        BillingMode: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BillingMode),
        ItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
        TableCreationDateTime: output.TableCreationDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.TableCreationDateTime)))
            : undefined,
        TableId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableId),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
        TableSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.TableSizeBytes),
    };
};
var deserializeAws_json1_0SourceTableFeatureDetails = function (output, context) {
    return {
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexes(output.GlobalSecondaryIndexes, context)
            : undefined,
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0LocalSecondaryIndexes(output.LocalSecondaryIndexes, context)
            : undefined,
        SSEDescription: output.SSEDescription != null ? deserializeAws_json1_0SSEDescription(output.SSEDescription, context) : undefined,
        StreamDescription: output.StreamDescription != null
            ? deserializeAws_json1_0StreamSpecification(output.StreamDescription, context)
            : undefined,
        TimeToLiveDescription: output.TimeToLiveDescription != null
            ? deserializeAws_json1_0TimeToLiveDescription(output.TimeToLiveDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0SSEDescription = function (output, context) {
    return {
        InaccessibleEncryptionDateTime: output.InaccessibleEncryptionDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.InaccessibleEncryptionDateTime)))
            : undefined,
        KMSMasterKeyArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.KMSMasterKeyArn),
        SSEType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.SSEType),
        Status: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Status),
    };
};
var deserializeAws_json1_0SSESpecification = function (output, context) {
    return {
        Enabled: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.Enabled),
        KMSMasterKeyId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.KMSMasterKeyId),
        SSEType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.SSEType),
    };
};
var deserializeAws_json1_0StreamSpecification = function (output, context) {
    return {
        StreamEnabled: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.StreamEnabled),
        StreamViewType: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.StreamViewType),
    };
};
var deserializeAws_json1_0StringSetAttributeValue = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0TableAlreadyExistsException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0TableAutoScalingDescription = function (output, context) {
    return {
        Replicas: output.Replicas != null
            ? deserializeAws_json1_0ReplicaAutoScalingDescriptionList(output.Replicas, context)
            : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
        TableStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableStatus),
    };
};
var deserializeAws_json1_0TableClassSummary = function (output, context) {
    return {
        LastUpdateDateTime: output.LastUpdateDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.LastUpdateDateTime)))
            : undefined,
        TableClass: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableClass),
    };
};
var deserializeAws_json1_0TableCreationParameters = function (output, context) {
    return {
        AttributeDefinitions: output.AttributeDefinitions != null
            ? deserializeAws_json1_0AttributeDefinitions(output.AttributeDefinitions, context)
            : undefined,
        BillingMode: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.BillingMode),
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexList(output.GlobalSecondaryIndexes, context)
            : undefined,
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughput(output.ProvisionedThroughput, context)
            : undefined,
        SSESpecification: output.SSESpecification != null
            ? deserializeAws_json1_0SSESpecification(output.SSESpecification, context)
            : undefined,
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0TableDescription = function (output, context) {
    return {
        ArchivalSummary: output.ArchivalSummary != null
            ? deserializeAws_json1_0ArchivalSummary(output.ArchivalSummary, context)
            : undefined,
        AttributeDefinitions: output.AttributeDefinitions != null
            ? deserializeAws_json1_0AttributeDefinitions(output.AttributeDefinitions, context)
            : undefined,
        BillingModeSummary: output.BillingModeSummary != null
            ? deserializeAws_json1_0BillingModeSummary(output.BillingModeSummary, context)
            : undefined,
        CreationDateTime: output.CreationDateTime != null
            ? (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNonNull)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.parseEpochTimestamp)((0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectNumber)(output.CreationDateTime)))
            : undefined,
        GlobalSecondaryIndexes: output.GlobalSecondaryIndexes != null
            ? deserializeAws_json1_0GlobalSecondaryIndexDescriptionList(output.GlobalSecondaryIndexes, context)
            : undefined,
        GlobalTableVersion: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableVersion),
        ItemCount: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.ItemCount),
        KeySchema: output.KeySchema != null ? deserializeAws_json1_0KeySchema(output.KeySchema, context) : undefined,
        LatestStreamArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.LatestStreamArn),
        LatestStreamLabel: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.LatestStreamLabel),
        LocalSecondaryIndexes: output.LocalSecondaryIndexes != null
            ? deserializeAws_json1_0LocalSecondaryIndexDescriptionList(output.LocalSecondaryIndexes, context)
            : undefined,
        ProvisionedThroughput: output.ProvisionedThroughput != null
            ? deserializeAws_json1_0ProvisionedThroughputDescription(output.ProvisionedThroughput, context)
            : undefined,
        Replicas: output.Replicas != null ? deserializeAws_json1_0ReplicaDescriptionList(output.Replicas, context) : undefined,
        RestoreSummary: output.RestoreSummary != null ? deserializeAws_json1_0RestoreSummary(output.RestoreSummary, context) : undefined,
        SSEDescription: output.SSEDescription != null ? deserializeAws_json1_0SSEDescription(output.SSEDescription, context) : undefined,
        StreamSpecification: output.StreamSpecification != null
            ? deserializeAws_json1_0StreamSpecification(output.StreamSpecification, context)
            : undefined,
        TableArn: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableArn),
        TableClassSummary: output.TableClassSummary != null
            ? deserializeAws_json1_0TableClassSummary(output.TableClassSummary, context)
            : undefined,
        TableId: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableId),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
        TableSizeBytes: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectLong)(output.TableSizeBytes),
        TableStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableStatus),
    };
};
var deserializeAws_json1_0TableInUseException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0TableNameList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(entry);
    });
    return retVal;
};
var deserializeAws_json1_0TableNotFoundException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0Tag = function (output, context) {
    return {
        Key: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Key),
        Value: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Value),
    };
};
var deserializeAws_json1_0TagList = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0Tag(entry, context);
    });
    return retVal;
};
var deserializeAws_json1_0TimeToLiveDescription = function (output, context) {
    return {
        AttributeName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AttributeName),
        TimeToLiveStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TimeToLiveStatus),
    };
};
var deserializeAws_json1_0TimeToLiveSpecification = function (output, context) {
    return {
        AttributeName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.AttributeName),
        Enabled: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectBoolean)(output.Enabled),
    };
};
var deserializeAws_json1_0TransactGetItemsOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        Responses: output.Responses != null ? deserializeAws_json1_0ItemResponseList(output.Responses, context) : undefined,
    };
};
var deserializeAws_json1_0TransactionCanceledException = function (output, context) {
    return {
        CancellationReasons: output.CancellationReasons != null
            ? deserializeAws_json1_0CancellationReasonList(output.CancellationReasons, context)
            : undefined,
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0TransactionConflictException = function (output, context) {
    return {
        message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.message),
    };
};
var deserializeAws_json1_0TransactionInProgressException = function (output, context) {
    return {
        Message: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.Message),
    };
};
var deserializeAws_json1_0TransactWriteItemsOutput = function (output, context) {
    return {
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacityMultiple(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetricsPerTable(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateContinuousBackupsOutput = function (output, context) {
    return {
        ContinuousBackupsDescription: output.ContinuousBackupsDescription != null
            ? deserializeAws_json1_0ContinuousBackupsDescription(output.ContinuousBackupsDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateContributorInsightsOutput = function (output, context) {
    return {
        ContributorInsightsStatus: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.ContributorInsightsStatus),
        IndexName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.IndexName),
        TableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.TableName),
    };
};
var deserializeAws_json1_0UpdateGlobalTableOutput = function (output, context) {
    return {
        GlobalTableDescription: output.GlobalTableDescription != null
            ? deserializeAws_json1_0GlobalTableDescription(output.GlobalTableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateGlobalTableSettingsOutput = function (output, context) {
    return {
        GlobalTableName: (0,_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_1__.expectString)(output.GlobalTableName),
        ReplicaSettings: output.ReplicaSettings != null
            ? deserializeAws_json1_0ReplicaSettingsDescriptionList(output.ReplicaSettings, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateItemOutput = function (output, context) {
    return {
        Attributes: output.Attributes != null ? deserializeAws_json1_0AttributeMap(output.Attributes, context) : undefined,
        ConsumedCapacity: output.ConsumedCapacity != null
            ? deserializeAws_json1_0ConsumedCapacity(output.ConsumedCapacity, context)
            : undefined,
        ItemCollectionMetrics: output.ItemCollectionMetrics != null
            ? deserializeAws_json1_0ItemCollectionMetrics(output.ItemCollectionMetrics, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateTableOutput = function (output, context) {
    return {
        TableDescription: output.TableDescription != null
            ? deserializeAws_json1_0TableDescription(output.TableDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateTableReplicaAutoScalingOutput = function (output, context) {
    return {
        TableAutoScalingDescription: output.TableAutoScalingDescription != null
            ? deserializeAws_json1_0TableAutoScalingDescription(output.TableAutoScalingDescription, context)
            : undefined,
    };
};
var deserializeAws_json1_0UpdateTimeToLiveOutput = function (output, context) {
    return {
        TimeToLiveSpecification: output.TimeToLiveSpecification != null
            ? deserializeAws_json1_0TimeToLiveSpecification(output.TimeToLiveSpecification, context)
            : undefined,
    };
};
var deserializeAws_json1_0WriteRequest = function (output, context) {
    return {
        DeleteRequest: output.DeleteRequest != null ? deserializeAws_json1_0DeleteRequest(output.DeleteRequest, context) : undefined,
        PutRequest: output.PutRequest != null ? deserializeAws_json1_0PutRequest(output.PutRequest, context) : undefined,
    };
};
var deserializeAws_json1_0WriteRequests = function (output, context) {
    var retVal = (output || [])
        .filter(function (e) { return e != null; })
        .map(function (entry) {
        if (entry === null) {
            return null;
        }
        return deserializeAws_json1_0WriteRequest(entry, context);
    });
    return retVal;
};
var deserializeMetadata = function (output) {
    var _a, _b;
    return ({
        httpStatusCode: output.statusCode,
        requestId: (_b = (_a = output.headers["x-amzn-requestid"]) !== null && _a !== void 0 ? _a : output.headers["x-amzn-request-id"]) !== null && _b !== void 0 ? _b : output.headers["x-amz-request-id"],
        extendedRequestId: output.headers["x-amz-id-2"],
        cfId: output.headers["x-amz-cf-id"],
    });
};
var collectBody = function (streamBody, context) {
    if (streamBody === void 0) { streamBody = new Uint8Array(); }
    if (streamBody instanceof Uint8Array) {
        return Promise.resolve(streamBody);
    }
    return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};
var collectBodyString = function (streamBody, context) {
    return collectBody(streamBody, context).then(function (body) { return context.utf8Encoder(body); });
};
var buildHttpRpcRequest = function (context, headers, path, resolvedHostname, body) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var _a, hostname, _b, protocol, port, basePath, contents;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_c) {
        switch (_c.label) {
            case 0: return [4, context.endpoint()];
            case 1:
                _a = _c.sent(), hostname = _a.hostname, _b = _a.protocol, protocol = _b === void 0 ? "https" : _b, port = _a.port, basePath = _a.path;
                contents = {
                    protocol: protocol,
                    hostname: hostname,
                    port: port,
                    method: "POST",
                    path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
                    headers: headers,
                };
                if (resolvedHostname !== undefined) {
                    contents.hostname = resolvedHostname;
                }
                if (body !== undefined) {
                    contents.body = body;
                }
                return [2, new _aws_sdk_protocol_http__WEBPACK_IMPORTED_MODULE_0__.HttpRequest(contents)];
        }
    });
}); };
var parseBody = function (streamBody, context) {
    return collectBodyString(streamBody, context).then(function (encoded) {
        if (encoded.length) {
            return JSON.parse(encoded);
        }
        return {};
    });
};
var parseErrorBody = function (errorBody, context) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(void 0, void 0, void 0, function () {
    var value;
    var _a;
    return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_b) {
        switch (_b.label) {
            case 0: return [4, parseBody(errorBody, context)];
            case 1:
                value = _b.sent();
                value.message = (_a = value.message) !== null && _a !== void 0 ? _a : value.Message;
                return [2, value];
        }
    });
}); };
var loadRestJsonErrorCode = function (output, data) {
    var findKey = function (object, key) { return Object.keys(object).find(function (k) { return k.toLowerCase() === key.toLowerCase(); }); };
    var sanitizeErrorCode = function (rawValue) {
        var cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        if (cleanValue.indexOf("#") >= 0) {
            cleanValue = cleanValue.split("#")[1];
        }
        return cleanValue;
    };
    var headerKey = findKey(output.headers, "x-amzn-errortype");
    if (headerKey !== undefined) {
        return sanitizeErrorCode(output.headers[headerKey]);
    }
    if (data.code !== undefined) {
        return sanitizeErrorCode(data.code);
    }
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};


/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/regex.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/regex.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);

/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/rng.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/rng.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ rng)
/* harmony export */ });
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! crypto */ "crypto");
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);

const rnds8Pool = new Uint8Array(256); // # of random values to pre-allocate

let poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    crypto__WEBPACK_IMPORTED_MODULE_0___default().randomFillSync(rnds8Pool);
    poolPtr = 0;
  }

  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/stringify.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/stringify.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/validate.js");

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).substr(1));
}

function stringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  const uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__["default"])(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stringify);

/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/v4.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/v4.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rng.js */ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/rng.js");
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/stringify.js");



function v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_0__["default"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_1__["default"])(rnds);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v4);

/***/ }),

/***/ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/validate.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/validate.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _regex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regex.js */ "./node_modules/@aws-sdk/client-dynamodb/node_modules/uuid/dist/esm-node/regex.js");


function validate(uuid) {
  return typeof uuid === 'string' && _regex_js__WEBPACK_IMPORTED_MODULE_0__["default"].test(uuid);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validate);

/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocument.js":
/*!************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocument.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamoDBDocument": () => (/* binding */ DynamoDBDocument)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _commands_BatchExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commands/BatchExecuteStatementCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js");
/* harmony import */ var _commands_BatchGetCommand__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commands/BatchGetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchGetCommand.js");
/* harmony import */ var _commands_BatchWriteCommand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./commands/BatchWriteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchWriteCommand.js");
/* harmony import */ var _commands_DeleteCommand__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./commands/DeleteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/DeleteCommand.js");
/* harmony import */ var _commands_ExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./commands/ExecuteStatementCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteStatementCommand.js");
/* harmony import */ var _commands_ExecuteTransactionCommand__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./commands/ExecuteTransactionCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteTransactionCommand.js");
/* harmony import */ var _commands_GetCommand__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./commands/GetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/GetCommand.js");
/* harmony import */ var _commands_PutCommand__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./commands/PutCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/PutCommand.js");
/* harmony import */ var _commands_QueryCommand__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./commands/QueryCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/QueryCommand.js");
/* harmony import */ var _commands_ScanCommand__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./commands/ScanCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ScanCommand.js");
/* harmony import */ var _commands_TransactGetCommand__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./commands/TransactGetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactGetCommand.js");
/* harmony import */ var _commands_TransactWriteCommand__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./commands/TransactWriteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactWriteCommand.js");
/* harmony import */ var _commands_UpdateCommand__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./commands/UpdateCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/UpdateCommand.js");
/* harmony import */ var _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./DynamoDBDocumentClient */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js");















var DynamoDBDocument = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__extends)(DynamoDBDocument, _super);
    function DynamoDBDocument() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DynamoDBDocument.from = function (client, translateConfig) {
        return new DynamoDBDocument(client, translateConfig);
    };
    DynamoDBDocument.prototype.batchExecuteStatement = function (args, optionsOrCb, cb) {
        var command = new _commands_BatchExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_0__.BatchExecuteStatementCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.batchGet = function (args, optionsOrCb, cb) {
        var command = new _commands_BatchGetCommand__WEBPACK_IMPORTED_MODULE_1__.BatchGetCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.batchWrite = function (args, optionsOrCb, cb) {
        var command = new _commands_BatchWriteCommand__WEBPACK_IMPORTED_MODULE_2__.BatchWriteCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.delete = function (args, optionsOrCb, cb) {
        var command = new _commands_DeleteCommand__WEBPACK_IMPORTED_MODULE_3__.DeleteCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.executeStatement = function (args, optionsOrCb, cb) {
        var command = new _commands_ExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_4__.ExecuteStatementCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.executeTransaction = function (args, optionsOrCb, cb) {
        var command = new _commands_ExecuteTransactionCommand__WEBPACK_IMPORTED_MODULE_5__.ExecuteTransactionCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.get = function (args, optionsOrCb, cb) {
        var command = new _commands_GetCommand__WEBPACK_IMPORTED_MODULE_6__.GetCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.put = function (args, optionsOrCb, cb) {
        var command = new _commands_PutCommand__WEBPACK_IMPORTED_MODULE_7__.PutCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.query = function (args, optionsOrCb, cb) {
        var command = new _commands_QueryCommand__WEBPACK_IMPORTED_MODULE_8__.QueryCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.scan = function (args, optionsOrCb, cb) {
        var command = new _commands_ScanCommand__WEBPACK_IMPORTED_MODULE_9__.ScanCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.transactGet = function (args, optionsOrCb, cb) {
        var command = new _commands_TransactGetCommand__WEBPACK_IMPORTED_MODULE_10__.TransactGetCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.transactWrite = function (args, optionsOrCb, cb) {
        var command = new _commands_TransactWriteCommand__WEBPACK_IMPORTED_MODULE_11__.TransactWriteCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    DynamoDBDocument.prototype.update = function (args, optionsOrCb, cb) {
        var command = new _commands_UpdateCommand__WEBPACK_IMPORTED_MODULE_12__.UpdateCommand(args);
        if (typeof optionsOrCb === "function") {
            this.send(command, optionsOrCb);
        }
        else if (typeof cb === "function") {
            if (typeof optionsOrCb !== "object")
                throw new Error("Expect http options but get ".concat(typeof optionsOrCb));
            this.send(command, optionsOrCb || {}, cb);
        }
        else {
            return this.send(command, optionsOrCb);
        }
    };
    return DynamoDBDocument;
}(_DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_13__.DynamoDBDocumentClient));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamoDBDocumentClient": () => (/* binding */ DynamoDBDocumentClient)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");


var DynamoDBDocumentClient = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(DynamoDBDocumentClient, _super);
    function DynamoDBDocumentClient(client, translateConfig) {
        var _this = _super.call(this, client.config) || this;
        _this.config = client.config;
        _this.config.translateConfig = translateConfig;
        _this.middlewareStack = client.middlewareStack;
        return _this;
    }
    DynamoDBDocumentClient.from = function (client, translateConfig) {
        return new DynamoDBDocumentClient(client, translateConfig);
    };
    DynamoDBDocumentClient.prototype.destroy = function () {
    };
    return DynamoDBDocumentClient;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__.Client));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamoDBDocumentClientCommand": () => (/* binding */ DynamoDBDocumentClientCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/smithy-client */ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js");
/* harmony import */ var _commands_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../commands/utils */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/utils.js");



var DynamoDBDocumentClientCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__extends)(DynamoDBDocumentClientCommand, _super);
    function DynamoDBDocumentClientCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DynamoDBDocumentClientCommand.prototype.addMarshallingMiddleware = function (configuration) {
        var _this = this;
        var _a = configuration.translateConfig || {}, marshallOptions = _a.marshallOptions, unmarshallOptions = _a.unmarshallOptions;
        this.clientCommand.middlewareStack.add(function (next) {
            return function (args) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(_this, void 0, void 0, function () {
                return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
                    args.input = (0,_commands_utils__WEBPACK_IMPORTED_MODULE_1__.marshallInput)(this.input, this.inputKeyNodes, marshallOptions);
                    return [2, next(args)];
                });
            }); };
        }, {
            name: "DocumentMarshall",
            step: "initialize",
            override: true,
        });
        this.clientCommand.middlewareStack.add(function (next) {
            return function (args) { return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(_this, void 0, void 0, function () {
                var deserialized;
                return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__generator)(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4, next(args)];
                        case 1:
                            deserialized = _a.sent();
                            deserialized.output = (0,_commands_utils__WEBPACK_IMPORTED_MODULE_1__.unmarshallOutput)(deserialized.output, this.outputKeyNodes, unmarshallOptions);
                            return [2, deserialized];
                    }
                });
            }); };
        }, {
            name: "DocumentUnmarshall",
            step: "deserialize",
            override: true,
        });
    };
    return DynamoDBDocumentClientCommand;
}(_aws_sdk_smithy_client__WEBPACK_IMPORTED_MODULE_0__.Command));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchExecuteStatementCommand": () => (/* binding */ BatchExecuteStatementCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var BatchExecuteStatementCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(BatchExecuteStatementCommand, _super);
    function BatchExecuteStatementCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [{ key: "Statements", children: [{ key: "Parameters" }] }];
        _this.outputKeyNodes = [{ key: "Responses", children: [{ key: "Item" }] }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.BatchExecuteStatementCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    BatchExecuteStatementCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return BatchExecuteStatementCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchGetCommand.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchGetCommand.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchGetCommand": () => (/* binding */ BatchGetCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchGetItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var BatchGetCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(BatchGetCommand, _super);
    function BatchGetCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            {
                key: "RequestItems",
                children: {
                    children: [{ key: "Keys" }],
                },
            },
        ];
        _this.outputKeyNodes = [
            { key: "Responses", children: {} },
            {
                key: "UnprocessedKeys",
                children: {
                    children: [{ key: "Keys" }],
                },
            },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.BatchGetItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    BatchGetCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return BatchGetCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchWriteCommand.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchWriteCommand.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchWriteCommand": () => (/* binding */ BatchWriteCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/BatchWriteItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var BatchWriteCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(BatchWriteCommand, _super);
    function BatchWriteCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            {
                key: "RequestItems",
                children: {
                    children: [
                        { key: "PutRequest", children: [{ key: "Item" }] },
                        { key: "DeleteRequest", children: [{ key: "Key" }] },
                    ],
                },
            },
        ];
        _this.outputKeyNodes = [
            {
                key: "UnprocessedItems",
                children: {
                    children: [
                        { key: "PutRequest", children: [{ key: "Item" }] },
                        { key: "DeleteRequest", children: [{ key: "Key" }] },
                    ],
                },
            },
            {
                key: "ItemCollectionMetrics",
                children: {
                    children: [{ key: "ItemCollectionKey" }],
                },
            },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.BatchWriteItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    BatchWriteCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return BatchWriteCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/DeleteCommand.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/DeleteCommand.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteCommand": () => (/* binding */ DeleteCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/DeleteItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var DeleteCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(DeleteCommand, _super);
    function DeleteCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            { key: "Key" },
            {
                key: "Expected",
                children: {
                    children: [{ key: "Value" }, { key: "AttributeValueList" }],
                },
            },
            { key: "ExpressionAttributeValues" },
        ];
        _this.outputKeyNodes = [
            { key: "Attributes" },
            { key: "ItemCollectionMetrics", children: [{ key: "ItemCollectionKey" }] },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.DeleteItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    DeleteCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return DeleteCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteStatementCommand.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteStatementCommand.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExecuteStatementCommand": () => (/* binding */ ExecuteStatementCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteStatementCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var ExecuteStatementCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(ExecuteStatementCommand, _super);
    function ExecuteStatementCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [{ key: "Parameters" }];
        _this.outputKeyNodes = [{ key: "Items" }, { key: "LastEvaluatedKey" }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.ExecuteStatementCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    ExecuteStatementCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return ExecuteStatementCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteTransactionCommand.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteTransactionCommand.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExecuteTransactionCommand": () => (/* binding */ ExecuteTransactionCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ExecuteTransactionCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var ExecuteTransactionCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(ExecuteTransactionCommand, _super);
    function ExecuteTransactionCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [{ key: "TransactStatements", children: [{ key: "Parameters" }] }];
        _this.outputKeyNodes = [{ key: "Responses", children: [{ key: "Item" }] }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.ExecuteTransactionCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    ExecuteTransactionCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return ExecuteTransactionCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/GetCommand.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/GetCommand.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetCommand": () => (/* binding */ GetCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/GetItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var GetCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(GetCommand, _super);
    function GetCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [{ key: "Key" }];
        _this.outputKeyNodes = [{ key: "Item" }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.GetItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    GetCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return GetCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/PutCommand.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/PutCommand.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PutCommand": () => (/* binding */ PutCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/PutItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var PutCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(PutCommand, _super);
    function PutCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            { key: "Item" },
            {
                key: "Expected",
                children: {
                    children: [{ key: "Value" }, { key: "AttributeValueList" }],
                },
            },
            { key: "ExpressionAttributeValues" },
        ];
        _this.outputKeyNodes = [
            { key: "Attributes" },
            { key: "ItemCollectionMetrics", children: [{ key: "ItemCollectionKey" }] },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.PutItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    PutCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return PutCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/QueryCommand.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/QueryCommand.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QueryCommand": () => (/* binding */ QueryCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/QueryCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var QueryCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(QueryCommand, _super);
    function QueryCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            {
                key: "KeyConditions",
                children: {
                    children: [{ key: "AttributeValueList" }],
                },
            },
            {
                key: "QueryFilter",
                children: {
                    children: [{ key: "AttributeValueList" }],
                },
            },
            { key: "ExclusiveStartKey" },
            { key: "ExpressionAttributeValues" },
        ];
        _this.outputKeyNodes = [{ key: "Items" }, { key: "LastEvaluatedKey" }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.QueryCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    QueryCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return QueryCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ScanCommand.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ScanCommand.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanCommand": () => (/* binding */ ScanCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/ScanCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var ScanCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(ScanCommand, _super);
    function ScanCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            {
                key: "ScanFilter",
                children: {
                    children: [{ key: "AttributeValueList" }],
                },
            },
            { key: "ExclusiveStartKey" },
            { key: "ExpressionAttributeValues" },
        ];
        _this.outputKeyNodes = [{ key: "Items" }, { key: "LastEvaluatedKey" }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.ScanCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    ScanCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return ScanCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactGetCommand.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactGetCommand.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactGetCommand": () => (/* binding */ TransactGetCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactGetItemsCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var TransactGetCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(TransactGetCommand, _super);
    function TransactGetCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [{ key: "TransactItems", children: [{ key: "Get", children: [{ key: "Key" }] }] }];
        _this.outputKeyNodes = [{ key: "Responses", children: [{ key: "Item" }] }];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.TransactGetItemsCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    TransactGetCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return TransactGetCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactWriteCommand.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactWriteCommand.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactWriteCommand": () => (/* binding */ TransactWriteCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/TransactWriteItemsCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var TransactWriteCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(TransactWriteCommand, _super);
    function TransactWriteCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            {
                key: "TransactItems",
                children: [
                    { key: "ConditionCheck", children: [{ key: "Key" }, { key: "ExpressionAttributeValues" }] },
                    { key: "Put", children: [{ key: "Item" }, { key: "ExpressionAttributeValues" }] },
                    { key: "Delete", children: [{ key: "Key" }, { key: "ExpressionAttributeValues" }] },
                    { key: "Update", children: [{ key: "Key" }, { key: "ExpressionAttributeValues" }] },
                ],
            },
        ];
        _this.outputKeyNodes = [
            {
                key: "ItemCollectionMetrics",
                children: {
                    children: [{ key: "ItemCollectionKey" }],
                },
            },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.TransactWriteItemsCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    TransactWriteCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return TransactWriteCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/UpdateCommand.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/UpdateCommand.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateCommand": () => (/* binding */ UpdateCommand)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-sdk/client-dynamodb */ "./node_modules/@aws-sdk/client-dynamodb/dist-es/commands/UpdateItemCommand.js");
/* harmony import */ var _baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../baseCommand/DynamoDBDocumentClientCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/baseCommand/DynamoDBDocumentClientCommand.js");



var UpdateCommand = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(UpdateCommand, _super);
    function UpdateCommand(input) {
        var _this = _super.call(this) || this;
        _this.input = input;
        _this.inputKeyNodes = [
            { key: "Key" },
            {
                key: "AttributeUpdates",
                children: {
                    children: [{ key: "Value" }],
                },
            },
            {
                key: "Expected",
                children: {
                    children: [{ key: "Value" }, { key: "AttributeValueList" }],
                },
            },
            { key: "ExpressionAttributeValues" },
        ];
        _this.outputKeyNodes = [
            { key: "Attributes" },
            { key: "ItemCollectionMetrics", children: [{ key: "ItemCollectionKey" }] },
        ];
        _this.clientCommand = new _aws_sdk_client_dynamodb__WEBPACK_IMPORTED_MODULE_2__.UpdateItemCommand(_this.input);
        _this.middlewareStack = _this.clientCommand.middlewareStack;
        return _this;
    }
    UpdateCommand.prototype.resolveMiddleware = function (clientStack, configuration, options) {
        var _this = this;
        this.addMarshallingMiddleware(configuration);
        var stack = clientStack.concat(this.middlewareStack);
        var handler = this.clientCommand.resolveMiddleware(stack, configuration, options);
        return function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(_this, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__generator)(this, function (_a) {
            return [2, handler(this.clientCommand)];
        }); }); };
    };
    return UpdateCommand;
}(_baseCommand_DynamoDBDocumentClientCommand__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocumentClientCommand));



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/index.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/index.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchExecuteStatementCommand": () => (/* reexport safe */ _BatchExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_0__.BatchExecuteStatementCommand),
/* harmony export */   "BatchGetCommand": () => (/* reexport safe */ _BatchGetCommand__WEBPACK_IMPORTED_MODULE_1__.BatchGetCommand),
/* harmony export */   "BatchWriteCommand": () => (/* reexport safe */ _BatchWriteCommand__WEBPACK_IMPORTED_MODULE_2__.BatchWriteCommand),
/* harmony export */   "DeleteCommand": () => (/* reexport safe */ _DeleteCommand__WEBPACK_IMPORTED_MODULE_3__.DeleteCommand),
/* harmony export */   "ExecuteStatementCommand": () => (/* reexport safe */ _ExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_4__.ExecuteStatementCommand),
/* harmony export */   "ExecuteTransactionCommand": () => (/* reexport safe */ _ExecuteTransactionCommand__WEBPACK_IMPORTED_MODULE_5__.ExecuteTransactionCommand),
/* harmony export */   "GetCommand": () => (/* reexport safe */ _GetCommand__WEBPACK_IMPORTED_MODULE_6__.GetCommand),
/* harmony export */   "PutCommand": () => (/* reexport safe */ _PutCommand__WEBPACK_IMPORTED_MODULE_7__.PutCommand),
/* harmony export */   "QueryCommand": () => (/* reexport safe */ _QueryCommand__WEBPACK_IMPORTED_MODULE_8__.QueryCommand),
/* harmony export */   "ScanCommand": () => (/* reexport safe */ _ScanCommand__WEBPACK_IMPORTED_MODULE_9__.ScanCommand),
/* harmony export */   "TransactGetCommand": () => (/* reexport safe */ _TransactGetCommand__WEBPACK_IMPORTED_MODULE_10__.TransactGetCommand),
/* harmony export */   "TransactWriteCommand": () => (/* reexport safe */ _TransactWriteCommand__WEBPACK_IMPORTED_MODULE_11__.TransactWriteCommand),
/* harmony export */   "UpdateCommand": () => (/* reexport safe */ _UpdateCommand__WEBPACK_IMPORTED_MODULE_12__.UpdateCommand)
/* harmony export */ });
/* harmony import */ var _BatchExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BatchExecuteStatementCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchExecuteStatementCommand.js");
/* harmony import */ var _BatchGetCommand__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BatchGetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchGetCommand.js");
/* harmony import */ var _BatchWriteCommand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BatchWriteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/BatchWriteCommand.js");
/* harmony import */ var _DeleteCommand__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DeleteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/DeleteCommand.js");
/* harmony import */ var _ExecuteStatementCommand__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ExecuteStatementCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteStatementCommand.js");
/* harmony import */ var _ExecuteTransactionCommand__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ExecuteTransactionCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ExecuteTransactionCommand.js");
/* harmony import */ var _GetCommand__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./GetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/GetCommand.js");
/* harmony import */ var _PutCommand__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PutCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/PutCommand.js");
/* harmony import */ var _QueryCommand__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./QueryCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/QueryCommand.js");
/* harmony import */ var _ScanCommand__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ScanCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ScanCommand.js");
/* harmony import */ var _TransactGetCommand__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./TransactGetCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactGetCommand.js");
/* harmony import */ var _TransactWriteCommand__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./TransactWriteCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/TransactWriteCommand.js");
/* harmony import */ var _UpdateCommand__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./UpdateCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/UpdateCommand.js");















/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/utils.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/utils.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "marshallInput": () => (/* binding */ marshallInput),
/* harmony export */   "unmarshallOutput": () => (/* binding */ unmarshallOutput)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _aws_sdk_util_dynamodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/util-dynamodb */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/index.js");


var processObj = function (obj, processFunc, children) {
    if (obj !== undefined) {
        if (!children || (Array.isArray(children) && children.length === 0)) {
            return processFunc(obj);
        }
        else {
            if (Array.isArray(children)) {
                return processKeysInObj(obj, processFunc, children);
            }
            else {
                return processAllKeysInObj(obj, processFunc, children.children);
            }
        }
    }
    return undefined;
};
var processKeyInObj = function (obj, processFunc, children) {
    if (Array.isArray(obj)) {
        return obj.map(function (item) { return processObj(item, processFunc, children); });
    }
    return processObj(obj, processFunc, children);
};
var processKeysInObj = function (obj, processFunc, keyNodes) {
    return keyNodes.reduce(function (acc, _a) {
        var _b;
        var key = _a.key, children = _a.children;
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({}, acc), (_b = {}, _b[key] = processKeyInObj(acc[key], processFunc, children), _b)));
    }, obj);
};
var processAllKeysInObj = function (obj, processFunc, children) {
    return Object.entries(obj).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({}, acc), (_b = {}, _b[key] = processKeyInObj(value, processFunc, children), _b)));
    }, {});
};
var marshallInput = function (obj, keyNodes, options) {
    var marshallFunc = function (toMarshall) { return (0,_aws_sdk_util_dynamodb__WEBPACK_IMPORTED_MODULE_0__.marshall)(toMarshall, options); };
    return processKeysInObj(obj, marshallFunc, keyNodes);
};
var unmarshallOutput = function (obj, keyNodes, options) {
    var unmarshallFunc = function (toMarshall) { return (0,_aws_sdk_util_dynamodb__WEBPACK_IMPORTED_MODULE_0__.unmarshall)(toMarshall, options); };
    return processKeysInObj(obj, unmarshallFunc, keyNodes);
};


/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/index.js":
/*!*************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/index.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BatchExecuteStatementCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.BatchExecuteStatementCommand),
/* harmony export */   "BatchGetCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.BatchGetCommand),
/* harmony export */   "BatchWriteCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.BatchWriteCommand),
/* harmony export */   "DeleteCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.DeleteCommand),
/* harmony export */   "DynamoDBDocument": () => (/* reexport safe */ _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_0__.DynamoDBDocument),
/* harmony export */   "DynamoDBDocumentClient": () => (/* reexport safe */ _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_1__.DynamoDBDocumentClient),
/* harmony export */   "ExecuteStatementCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.ExecuteStatementCommand),
/* harmony export */   "ExecuteTransactionCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.ExecuteTransactionCommand),
/* harmony export */   "GetCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.GetCommand),
/* harmony export */   "PutCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.PutCommand),
/* harmony export */   "QueryCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.QueryCommand),
/* harmony export */   "ScanCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.ScanCommand),
/* harmony export */   "TransactGetCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.TransactGetCommand),
/* harmony export */   "TransactWriteCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.TransactWriteCommand),
/* harmony export */   "UpdateCommand": () => (/* reexport safe */ _commands__WEBPACK_IMPORTED_MODULE_2__.UpdateCommand),
/* harmony export */   "paginateQuery": () => (/* reexport safe */ _pagination__WEBPACK_IMPORTED_MODULE_3__.paginateQuery),
/* harmony export */   "paginateScan": () => (/* reexport safe */ _pagination__WEBPACK_IMPORTED_MODULE_3__.paginateScan)
/* harmony export */ });
/* harmony import */ var _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DynamoDBDocument */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocument.js");
/* harmony import */ var _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DynamoDBDocumentClient */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js");
/* harmony import */ var _commands__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./commands */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/index.js");
/* harmony import */ var _pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pagination */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/index.js");






/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/Interfaces.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/Interfaces.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/QueryPaginator.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/QueryPaginator.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "paginateQuery": () => (/* binding */ paginateQuery)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _commands_QueryCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../commands/QueryCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/QueryCommand.js");
/* harmony import */ var _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../DynamoDBDocument */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocument.js");
/* harmony import */ var _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DynamoDBDocumentClient */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js");




var makePagedClientRequest = function (client, input) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        args[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, client.send.apply(client, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([new _commands_QueryCommand__WEBPACK_IMPORTED_MODULE_0__.QueryCommand(input)], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(args), false))];
                case 1: return [2, _a.sent()];
            }
        });
    });
};
var makePagedRequest = function (client, input) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        args[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, client.query.apply(client, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(args), false))];
                case 1: return [2, _a.sent()];
            }
        });
    });
};
function paginateQuery(config, input) {
    var additionalArguments = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        additionalArguments[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__asyncGenerator)(this, arguments, function paginateQuery_1() {
        var token, hasNext, page;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    token = config.startingToken || undefined;
                    hasNext = true;
                    _a.label = 1;
                case 1:
                    if (!hasNext) return [3, 9];
                    input.ExclusiveStartKey = token;
                    input["Limit"] = config.pageSize;
                    if (!(config.client instanceof _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_1__.DynamoDBDocument)) return [3, 3];
                    return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(makePagedRequest.apply(void 0, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([config.client, input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(additionalArguments), false)))];
                case 2:
                    page = _a.sent();
                    return [3, 6];
                case 3:
                    if (!(config.client instanceof _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_2__.DynamoDBDocumentClient)) return [3, 5];
                    return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(makePagedClientRequest.apply(void 0, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([config.client, input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(additionalArguments), false)))];
                case 4:
                    page = _a.sent();
                    return [3, 6];
                case 5: throw new Error("Invalid client, expected DynamoDBDocument | DynamoDBDocumentClient");
                case 6: return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(page)];
                case 7: return [4, _a.sent()];
                case 8:
                    _a.sent();
                    token = page.LastEvaluatedKey;
                    hasNext = !!token;
                    return [3, 1];
                case 9: return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(undefined)];
                case 10: return [2, _a.sent()];
            }
        });
    });
}


/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/ScanPaginator.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/ScanPaginator.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "paginateScan": () => (/* binding */ paginateScan)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _commands_ScanCommand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../commands/ScanCommand */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/commands/ScanCommand.js");
/* harmony import */ var _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../DynamoDBDocument */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocument.js");
/* harmony import */ var _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DynamoDBDocumentClient */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/DynamoDBDocumentClient.js");




var makePagedClientRequest = function (client, input) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        args[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, client.send.apply(client, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([new _commands_ScanCommand__WEBPACK_IMPORTED_MODULE_0__.ScanCommand(input)], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(args), false))];
                case 1: return [2, _a.sent()];
            }
        });
    });
};
var makePagedRequest = function (client, input) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        args[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, client.scan.apply(client, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(args), false))];
                case 1: return [2, _a.sent()];
            }
        });
    });
};
function paginateScan(config, input) {
    var additionalArguments = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        additionalArguments[_i - 2] = arguments[_i];
    }
    return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__asyncGenerator)(this, arguments, function paginateScan_1() {
        var token, hasNext, page;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    token = config.startingToken || undefined;
                    hasNext = true;
                    _a.label = 1;
                case 1:
                    if (!hasNext) return [3, 9];
                    input.ExclusiveStartKey = token;
                    input["Limit"] = config.pageSize;
                    if (!(config.client instanceof _DynamoDBDocument__WEBPACK_IMPORTED_MODULE_1__.DynamoDBDocument)) return [3, 3];
                    return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(makePagedRequest.apply(void 0, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([config.client, input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(additionalArguments), false)))];
                case 2:
                    page = _a.sent();
                    return [3, 6];
                case 3:
                    if (!(config.client instanceof _DynamoDBDocumentClient__WEBPACK_IMPORTED_MODULE_2__.DynamoDBDocumentClient)) return [3, 5];
                    return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(makePagedClientRequest.apply(void 0, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([config.client, input], (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__read)(additionalArguments), false)))];
                case 4:
                    page = _a.sent();
                    return [3, 6];
                case 5: throw new Error("Invalid client, expected DynamoDBDocument | DynamoDBDocumentClient");
                case 6: return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(page)];
                case 7: return [4, _a.sent()];
                case 8:
                    _a.sent();
                    token = page.LastEvaluatedKey;
                    hasNext = !!token;
                    return [3, 1];
                case 9: return [4, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__await)(undefined)];
                case 10: return [2, _a.sent()];
            }
        });
    });
}


/***/ }),

/***/ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/index.js":
/*!************************************************************************!*\
  !*** ./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/index.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "paginateQuery": () => (/* reexport safe */ _QueryPaginator__WEBPACK_IMPORTED_MODULE_1__.paginateQuery),
/* harmony export */   "paginateScan": () => (/* reexport safe */ _ScanPaginator__WEBPACK_IMPORTED_MODULE_2__.paginateScan)
/* harmony export */ });
/* harmony import */ var _Interfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Interfaces */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/Interfaces.js");
/* harmony import */ var _QueryPaginator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QueryPaginator */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/QueryPaginator.js");
/* harmony import */ var _ScanPaginator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ScanPaginator */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/pagination/ScanPaginator.js");





/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-serde/dist-es/deserializerMiddleware.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-serde/dist-es/deserializerMiddleware.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deserializerMiddleware": () => (/* binding */ deserializerMiddleware)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var deserializerMiddleware = function (options, deserializer) {
    return function (next, context) {
        return function (args) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(void 0, void 0, void 0, function () {
            var response, parsed, error_1;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, next(args)];
                    case 1:
                        response = (_a.sent()).response;
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4, deserializer(response, options)];
                    case 3:
                        parsed = _a.sent();
                        return [2, {
                                response: response,
                                output: parsed,
                            }];
                    case 4:
                        error_1 = _a.sent();
                        Object.defineProperty(error_1, "$response", {
                            value: response,
                        });
                        throw error_1;
                    case 5: return [2];
                }
            });
        }); };
    };
};


/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-serde/dist-es/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-serde/dist-es/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deserializerMiddleware": () => (/* reexport safe */ _deserializerMiddleware__WEBPACK_IMPORTED_MODULE_0__.deserializerMiddleware),
/* harmony export */   "deserializerMiddlewareOption": () => (/* reexport safe */ _serdePlugin__WEBPACK_IMPORTED_MODULE_1__.deserializerMiddlewareOption),
/* harmony export */   "getSerdePlugin": () => (/* reexport safe */ _serdePlugin__WEBPACK_IMPORTED_MODULE_1__.getSerdePlugin),
/* harmony export */   "serializerMiddleware": () => (/* reexport safe */ _serializerMiddleware__WEBPACK_IMPORTED_MODULE_2__.serializerMiddleware),
/* harmony export */   "serializerMiddlewareOption": () => (/* reexport safe */ _serdePlugin__WEBPACK_IMPORTED_MODULE_1__.serializerMiddlewareOption)
/* harmony export */ });
/* harmony import */ var _deserializerMiddleware__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deserializerMiddleware */ "./node_modules/@aws-sdk/middleware-serde/dist-es/deserializerMiddleware.js");
/* harmony import */ var _serdePlugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./serdePlugin */ "./node_modules/@aws-sdk/middleware-serde/dist-es/serdePlugin.js");
/* harmony import */ var _serializerMiddleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./serializerMiddleware */ "./node_modules/@aws-sdk/middleware-serde/dist-es/serializerMiddleware.js");





/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-serde/dist-es/serdePlugin.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-serde/dist-es/serdePlugin.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deserializerMiddlewareOption": () => (/* binding */ deserializerMiddlewareOption),
/* harmony export */   "getSerdePlugin": () => (/* binding */ getSerdePlugin),
/* harmony export */   "serializerMiddlewareOption": () => (/* binding */ serializerMiddlewareOption)
/* harmony export */ });
/* harmony import */ var _deserializerMiddleware__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deserializerMiddleware */ "./node_modules/@aws-sdk/middleware-serde/dist-es/deserializerMiddleware.js");
/* harmony import */ var _serializerMiddleware__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./serializerMiddleware */ "./node_modules/@aws-sdk/middleware-serde/dist-es/serializerMiddleware.js");


var deserializerMiddlewareOption = {
    name: "deserializerMiddleware",
    step: "deserialize",
    tags: ["DESERIALIZER"],
    override: true,
};
var serializerMiddlewareOption = {
    name: "serializerMiddleware",
    step: "serialize",
    tags: ["SERIALIZER"],
    override: true,
};
function getSerdePlugin(config, serializer, deserializer) {
    return {
        applyToStack: function (commandStack) {
            commandStack.add((0,_deserializerMiddleware__WEBPACK_IMPORTED_MODULE_0__.deserializerMiddleware)(config, deserializer), deserializerMiddlewareOption);
            commandStack.add((0,_serializerMiddleware__WEBPACK_IMPORTED_MODULE_1__.serializerMiddleware)(config, serializer), serializerMiddlewareOption);
        },
    };
}


/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-serde/dist-es/serializerMiddleware.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-serde/dist-es/serializerMiddleware.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "serializerMiddleware": () => (/* binding */ serializerMiddleware)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var serializerMiddleware = function (options, serializer) {
    return function (next, context) {
        return function (args) { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(void 0, void 0, void 0, function () {
            var endpoint, request;
            var _a;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        endpoint = ((_a = context.endpointV2) === null || _a === void 0 ? void 0 : _a.url) && options.urlParser
                            ? function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(void 0, void 0, void 0, function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__generator)(this, function (_a) {
                                return [2, options.urlParser(context.endpointV2.url)];
                            }); }); }
                            : options.endpoint;
                        if (!endpoint) {
                            throw new Error("No valid endpoint provider available.");
                        }
                        return [4, serializer(args.input, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, options), { endpoint: endpoint }))];
                    case 1:
                        request = _b.sent();
                        return [2, next((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, args), { request: request }))];
                }
            });
        }); };
    };
};


/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-stack/dist-es/MiddlewareStack.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-stack/dist-es/MiddlewareStack.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "constructStack": () => (/* binding */ constructStack)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var constructStack = function () {
    var absoluteEntries = [];
    var relativeEntries = [];
    var entriesNameSet = new Set();
    var sort = function (entries) {
        return entries.sort(function (a, b) {
            return stepWeights[b.step] - stepWeights[a.step] ||
                priorityWeights[b.priority || "normal"] - priorityWeights[a.priority || "normal"];
        });
    };
    var removeByName = function (toRemove) {
        var isRemoved = false;
        var filterCb = function (entry) {
            if (entry.name && entry.name === toRemove) {
                isRemoved = true;
                entriesNameSet.delete(toRemove);
                return false;
            }
            return true;
        };
        absoluteEntries = absoluteEntries.filter(filterCb);
        relativeEntries = relativeEntries.filter(filterCb);
        return isRemoved;
    };
    var removeByReference = function (toRemove) {
        var isRemoved = false;
        var filterCb = function (entry) {
            if (entry.middleware === toRemove) {
                isRemoved = true;
                if (entry.name)
                    entriesNameSet.delete(entry.name);
                return false;
            }
            return true;
        };
        absoluteEntries = absoluteEntries.filter(filterCb);
        relativeEntries = relativeEntries.filter(filterCb);
        return isRemoved;
    };
    var cloneTo = function (toStack) {
        absoluteEntries.forEach(function (entry) {
            toStack.add(entry.middleware, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, entry));
        });
        relativeEntries.forEach(function (entry) {
            toStack.addRelativeTo(entry.middleware, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, entry));
        });
        return toStack;
    };
    var expandRelativeMiddlewareList = function (from) {
        var expandedMiddlewareList = [];
        from.before.forEach(function (entry) {
            if (entry.before.length === 0 && entry.after.length === 0) {
                expandedMiddlewareList.push(entry);
            }
            else {
                expandedMiddlewareList.push.apply(expandedMiddlewareList, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(expandRelativeMiddlewareList(entry)), false));
            }
        });
        expandedMiddlewareList.push(from);
        from.after.reverse().forEach(function (entry) {
            if (entry.before.length === 0 && entry.after.length === 0) {
                expandedMiddlewareList.push(entry);
            }
            else {
                expandedMiddlewareList.push.apply(expandedMiddlewareList, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(expandRelativeMiddlewareList(entry)), false));
            }
        });
        return expandedMiddlewareList;
    };
    var getMiddlewareList = function (debug) {
        if (debug === void 0) { debug = false; }
        var normalizedAbsoluteEntries = [];
        var normalizedRelativeEntries = [];
        var normalizedEntriesNameMap = {};
        absoluteEntries.forEach(function (entry) {
            var normalizedEntry = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, entry), { before: [], after: [] });
            if (normalizedEntry.name)
                normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
            normalizedAbsoluteEntries.push(normalizedEntry);
        });
        relativeEntries.forEach(function (entry) {
            var normalizedEntry = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, entry), { before: [], after: [] });
            if (normalizedEntry.name)
                normalizedEntriesNameMap[normalizedEntry.name] = normalizedEntry;
            normalizedRelativeEntries.push(normalizedEntry);
        });
        normalizedRelativeEntries.forEach(function (entry) {
            if (entry.toMiddleware) {
                var toMiddleware = normalizedEntriesNameMap[entry.toMiddleware];
                if (toMiddleware === undefined) {
                    if (debug) {
                        return;
                    }
                    throw new Error("".concat(entry.toMiddleware, " is not found when adding ").concat(entry.name || "anonymous", " middleware ").concat(entry.relation, " ").concat(entry.toMiddleware));
                }
                if (entry.relation === "after") {
                    toMiddleware.after.push(entry);
                }
                if (entry.relation === "before") {
                    toMiddleware.before.push(entry);
                }
            }
        });
        var mainChain = sort(normalizedAbsoluteEntries)
            .map(expandRelativeMiddlewareList)
            .reduce(function (wholeList, expendedMiddlewareList) {
            wholeList.push.apply(wholeList, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(expendedMiddlewareList), false));
            return wholeList;
        }, []);
        return mainChain;
    };
    var stack = {
        add: function (middleware, options) {
            if (options === void 0) { options = {}; }
            var name = options.name, override = options.override;
            var entry = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ step: "initialize", priority: "normal", middleware: middleware }, options);
            if (name) {
                if (entriesNameSet.has(name)) {
                    if (!override)
                        throw new Error("Duplicate middleware name '".concat(name, "'"));
                    var toOverrideIndex = absoluteEntries.findIndex(function (entry) { return entry.name === name; });
                    var toOverride = absoluteEntries[toOverrideIndex];
                    if (toOverride.step !== entry.step || toOverride.priority !== entry.priority) {
                        throw new Error("\"".concat(name, "\" middleware with ").concat(toOverride.priority, " priority in ").concat(toOverride.step, " step cannot be ") +
                            "overridden by same-name middleware with ".concat(entry.priority, " priority in ").concat(entry.step, " step."));
                    }
                    absoluteEntries.splice(toOverrideIndex, 1);
                }
                entriesNameSet.add(name);
            }
            absoluteEntries.push(entry);
        },
        addRelativeTo: function (middleware, options) {
            var name = options.name, override = options.override;
            var entry = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({ middleware: middleware }, options);
            if (name) {
                if (entriesNameSet.has(name)) {
                    if (!override)
                        throw new Error("Duplicate middleware name '".concat(name, "'"));
                    var toOverrideIndex = relativeEntries.findIndex(function (entry) { return entry.name === name; });
                    var toOverride = relativeEntries[toOverrideIndex];
                    if (toOverride.toMiddleware !== entry.toMiddleware || toOverride.relation !== entry.relation) {
                        throw new Error("\"".concat(name, "\" middleware ").concat(toOverride.relation, " \"").concat(toOverride.toMiddleware, "\" middleware cannot be overridden ") +
                            "by same-name middleware ".concat(entry.relation, " \"").concat(entry.toMiddleware, "\" middleware."));
                    }
                    relativeEntries.splice(toOverrideIndex, 1);
                }
                entriesNameSet.add(name);
            }
            relativeEntries.push(entry);
        },
        clone: function () { return cloneTo(constructStack()); },
        use: function (plugin) {
            plugin.applyToStack(stack);
        },
        remove: function (toRemove) {
            if (typeof toRemove === "string")
                return removeByName(toRemove);
            else
                return removeByReference(toRemove);
        },
        removeByTag: function (toRemove) {
            var isRemoved = false;
            var filterCb = function (entry) {
                var tags = entry.tags, name = entry.name;
                if (tags && tags.includes(toRemove)) {
                    if (name)
                        entriesNameSet.delete(name);
                    isRemoved = true;
                    return false;
                }
                return true;
            };
            absoluteEntries = absoluteEntries.filter(filterCb);
            relativeEntries = relativeEntries.filter(filterCb);
            return isRemoved;
        },
        concat: function (from) {
            var cloned = cloneTo(constructStack());
            cloned.use(from);
            return cloned;
        },
        applyToStack: cloneTo,
        identify: function () {
            return getMiddlewareList(true).map(function (mw) {
                return mw.name + ": " + (mw.tags || []).join(",");
            });
        },
        resolve: function (handler, context) {
            var e_1, _a;
            try {
                for (var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(getMiddlewareList()
                    .map(function (entry) { return entry.middleware; })
                    .reverse()), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var middleware = _c.value;
                    handler = middleware(handler, context);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return handler;
        },
    };
    return stack;
};
var stepWeights = {
    initialize: 5,
    serialize: 4,
    build: 3,
    finalizeRequest: 2,
    deserialize: 1,
};
var priorityWeights = {
    high: 3,
    normal: 2,
    low: 1,
};


/***/ }),

/***/ "./node_modules/@aws-sdk/middleware-stack/dist-es/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@aws-sdk/middleware-stack/dist-es/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "constructStack": () => (/* reexport safe */ _MiddlewareStack__WEBPACK_IMPORTED_MODULE_0__.constructStack)
/* harmony export */ });
/* harmony import */ var _MiddlewareStack__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MiddlewareStack */ "./node_modules/@aws-sdk/middleware-stack/dist-es/MiddlewareStack.js");



/***/ }),

/***/ "./node_modules/@aws-sdk/protocol-http/dist-es/httpHandler.js":
/*!********************************************************************!*\
  !*** ./node_modules/@aws-sdk/protocol-http/dist-es/httpHandler.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./node_modules/@aws-sdk/protocol-http/dist-es/httpRequest.js":
/*!********************************************************************!*\
  !*** ./node_modules/@aws-sdk/protocol-http/dist-es/httpRequest.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpRequest": () => (/* binding */ HttpRequest)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var HttpRequest = (function () {
    function HttpRequest(options) {
        this.method = options.method || "GET";
        this.hostname = options.hostname || "localhost";
        this.port = options.port;
        this.query = options.query || {};
        this.headers = options.headers || {};
        this.body = options.body;
        this.protocol = options.protocol
            ? options.protocol.slice(-1) !== ":"
                ? "".concat(options.protocol, ":")
                : options.protocol
            : "https:";
        this.path = options.path ? (options.path.charAt(0) !== "/" ? "/".concat(options.path) : options.path) : "/";
    }
    HttpRequest.isInstance = function (request) {
        if (!request)
            return false;
        var req = request;
        return ("method" in req &&
            "protocol" in req &&
            "hostname" in req &&
            "path" in req &&
            typeof req["query"] === "object" &&
            typeof req["headers"] === "object");
    };
    HttpRequest.prototype.clone = function () {
        var cloned = new HttpRequest((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, this), { headers: (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, this.headers) }));
        if (cloned.query)
            cloned.query = cloneQuery(cloned.query);
        return cloned;
    };
    return HttpRequest;
}());

function cloneQuery(query) {
    return Object.keys(query).reduce(function (carry, paramName) {
        var _a;
        var param = query[paramName];
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, carry), (_a = {}, _a[paramName] = Array.isArray(param) ? (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(param), false) : param, _a));
    }, {});
}


/***/ }),

/***/ "./node_modules/@aws-sdk/protocol-http/dist-es/httpResponse.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@aws-sdk/protocol-http/dist-es/httpResponse.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpResponse": () => (/* binding */ HttpResponse)
/* harmony export */ });
var HttpResponse = (function () {
    function HttpResponse(options) {
        this.statusCode = options.statusCode;
        this.headers = options.headers || {};
        this.body = options.body;
    }
    HttpResponse.isInstance = function (response) {
        if (!response)
            return false;
        var resp = response;
        return typeof resp.statusCode === "number" && typeof resp.headers === "object";
    };
    return HttpResponse;
}());



/***/ }),

/***/ "./node_modules/@aws-sdk/protocol-http/dist-es/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@aws-sdk/protocol-http/dist-es/index.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpRequest": () => (/* reexport safe */ _httpRequest__WEBPACK_IMPORTED_MODULE_1__.HttpRequest),
/* harmony export */   "HttpResponse": () => (/* reexport safe */ _httpResponse__WEBPACK_IMPORTED_MODULE_2__.HttpResponse),
/* harmony export */   "isValidHostname": () => (/* reexport safe */ _isValidHostname__WEBPACK_IMPORTED_MODULE_3__.isValidHostname)
/* harmony export */ });
/* harmony import */ var _httpHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./httpHandler */ "./node_modules/@aws-sdk/protocol-http/dist-es/httpHandler.js");
/* harmony import */ var _httpRequest__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./httpRequest */ "./node_modules/@aws-sdk/protocol-http/dist-es/httpRequest.js");
/* harmony import */ var _httpResponse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./httpResponse */ "./node_modules/@aws-sdk/protocol-http/dist-es/httpResponse.js");
/* harmony import */ var _isValidHostname__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isValidHostname */ "./node_modules/@aws-sdk/protocol-http/dist-es/isValidHostname.js");






/***/ }),

/***/ "./node_modules/@aws-sdk/protocol-http/dist-es/isValidHostname.js":
/*!************************************************************************!*\
  !*** ./node_modules/@aws-sdk/protocol-http/dist-es/isValidHostname.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isValidHostname": () => (/* binding */ isValidHostname)
/* harmony export */ });
function isValidHostname(hostname) {
    var hostPattern = /^[a-z0-9][a-z0-9\.\-]*[a-z0-9]$/;
    return hostPattern.test(hostname);
}


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/client.js":
/*!***************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/client.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Client": () => (/* binding */ Client)
/* harmony export */ });
/* harmony import */ var _aws_sdk_middleware_stack__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-stack */ "./node_modules/@aws-sdk/middleware-stack/dist-es/index.js");

var Client = (function () {
    function Client(config) {
        this.middlewareStack = (0,_aws_sdk_middleware_stack__WEBPACK_IMPORTED_MODULE_0__.constructStack)();
        this.config = config;
    }
    Client.prototype.send = function (command, optionsOrCb, cb) {
        var options = typeof optionsOrCb !== "function" ? optionsOrCb : undefined;
        var callback = typeof optionsOrCb === "function" ? optionsOrCb : cb;
        var handler = command.resolveMiddleware(this.middlewareStack, this.config, options);
        if (callback) {
            handler(command)
                .then(function (result) { return callback(null, result.output); }, function (err) { return callback(err); })
                .catch(function () { });
        }
        else {
            return handler(command).then(function (result) { return result.output; });
        }
    };
    Client.prototype.destroy = function () {
        if (this.config.requestHandler.destroy)
            this.config.requestHandler.destroy();
    };
    return Client;
}());



/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/command.js":
/*!****************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/command.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Command": () => (/* binding */ Command)
/* harmony export */ });
/* harmony import */ var _aws_sdk_middleware_stack__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/middleware-stack */ "./node_modules/@aws-sdk/middleware-stack/dist-es/index.js");

var Command = (function () {
    function Command() {
        this.middlewareStack = (0,_aws_sdk_middleware_stack__WEBPACK_IMPORTED_MODULE_0__.constructStack)();
    }
    return Command;
}());



/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/constants.js":
/*!******************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/constants.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SENSITIVE_STRING": () => (/* binding */ SENSITIVE_STRING)
/* harmony export */ });
var SENSITIVE_STRING = "***SensitiveInformation***";


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/date-utils.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/date-utils.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateToUtcString": () => (/* binding */ dateToUtcString),
/* harmony export */   "parseEpochTimestamp": () => (/* binding */ parseEpochTimestamp),
/* harmony export */   "parseRfc3339DateTime": () => (/* binding */ parseRfc3339DateTime),
/* harmony export */   "parseRfc7231DateTime": () => (/* binding */ parseRfc7231DateTime)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _parse_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse-utils */ "./node_modules/@aws-sdk/smithy-client/dist-es/parse-utils.js");


var DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateToUtcString(date) {
    var year = date.getUTCFullYear();
    var month = date.getUTCMonth();
    var dayOfWeek = date.getUTCDay();
    var dayOfMonthInt = date.getUTCDate();
    var hoursInt = date.getUTCHours();
    var minutesInt = date.getUTCMinutes();
    var secondsInt = date.getUTCSeconds();
    var dayOfMonthString = dayOfMonthInt < 10 ? "0".concat(dayOfMonthInt) : "".concat(dayOfMonthInt);
    var hoursString = hoursInt < 10 ? "0".concat(hoursInt) : "".concat(hoursInt);
    var minutesString = minutesInt < 10 ? "0".concat(minutesInt) : "".concat(minutesInt);
    var secondsString = secondsInt < 10 ? "0".concat(secondsInt) : "".concat(secondsInt);
    return "".concat(DAYS[dayOfWeek], ", ").concat(dayOfMonthString, " ").concat(MONTHS[month], " ").concat(year, " ").concat(hoursString, ":").concat(minutesString, ":").concat(secondsString, " GMT");
}
var RFC3339 = new RegExp(/^(\d{4})-(\d{2})-(\d{2})[tT](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?[zZ]$/);
var parseRfc3339DateTime = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new TypeError("RFC-3339 date-times must be expressed as strings");
    }
    var match = RFC3339.exec(value);
    if (!match) {
        throw new TypeError("Invalid RFC-3339 date-time value");
    }
    var _a = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(match, 8), _ = _a[0], yearStr = _a[1], monthStr = _a[2], dayStr = _a[3], hours = _a[4], minutes = _a[5], seconds = _a[6], fractionalMilliseconds = _a[7];
    var year = (0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseShort)(stripLeadingZeroes(yearStr));
    var month = parseDateValue(monthStr, "month", 1, 12);
    var day = parseDateValue(dayStr, "day", 1, 31);
    return buildDate(year, month, day, { hours: hours, minutes: minutes, seconds: seconds, fractionalMilliseconds: fractionalMilliseconds });
};
var IMF_FIXDATE = new RegExp(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d{2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/);
var RFC_850_DATE = new RegExp(/^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d{2})-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? GMT$/);
var ASC_TIME = new RegExp(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( [1-9]|\d{2}) (\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))? (\d{4})$/);
var parseRfc7231DateTime = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new TypeError("RFC-7231 date-times must be expressed as strings");
    }
    var match = IMF_FIXDATE.exec(value);
    if (match) {
        var _a = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(match, 8), _1 = _a[0], dayStr = _a[1], monthStr = _a[2], yearStr = _a[3], hours = _a[4], minutes = _a[5], seconds = _a[6], fractionalMilliseconds = _a[7];
        return buildDate((0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseShort)(stripLeadingZeroes(yearStr)), parseMonthByShortName(monthStr), parseDateValue(dayStr, "day", 1, 31), { hours: hours, minutes: minutes, seconds: seconds, fractionalMilliseconds: fractionalMilliseconds });
    }
    match = RFC_850_DATE.exec(value);
    if (match) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(match, 8), _2 = _b[0], dayStr = _b[1], monthStr = _b[2], yearStr = _b[3], hours = _b[4], minutes = _b[5], seconds = _b[6], fractionalMilliseconds = _b[7];
        return adjustRfc850Year(buildDate(parseTwoDigitYear(yearStr), parseMonthByShortName(monthStr), parseDateValue(dayStr, "day", 1, 31), {
            hours: hours,
            minutes: minutes,
            seconds: seconds,
            fractionalMilliseconds: fractionalMilliseconds,
        }));
    }
    match = ASC_TIME.exec(value);
    if (match) {
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(match, 8), _3 = _c[0], monthStr = _c[1], dayStr = _c[2], hours = _c[3], minutes = _c[4], seconds = _c[5], fractionalMilliseconds = _c[6], yearStr = _c[7];
        return buildDate((0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseShort)(stripLeadingZeroes(yearStr)), parseMonthByShortName(monthStr), parseDateValue(dayStr.trimLeft(), "day", 1, 31), { hours: hours, minutes: minutes, seconds: seconds, fractionalMilliseconds: fractionalMilliseconds });
    }
    throw new TypeError("Invalid RFC-7231 date-time value");
};
var parseEpochTimestamp = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    var valueAsDouble;
    if (typeof value === "number") {
        valueAsDouble = value;
    }
    else if (typeof value === "string") {
        valueAsDouble = (0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseDouble)(value);
    }
    else {
        throw new TypeError("Epoch timestamps must be expressed as floating point numbers or their string representation");
    }
    if (Number.isNaN(valueAsDouble) || valueAsDouble === Infinity || valueAsDouble === -Infinity) {
        throw new TypeError("Epoch timestamps must be valid, non-Infinite, non-NaN numerics");
    }
    return new Date(Math.round(valueAsDouble * 1000));
};
var buildDate = function (year, month, day, time) {
    var adjustedMonth = month - 1;
    validateDayOfMonth(year, adjustedMonth, day);
    return new Date(Date.UTC(year, adjustedMonth, day, parseDateValue(time.hours, "hour", 0, 23), parseDateValue(time.minutes, "minute", 0, 59), parseDateValue(time.seconds, "seconds", 0, 60), parseMilliseconds(time.fractionalMilliseconds)));
};
var parseTwoDigitYear = function (value) {
    var thisYear = new Date().getUTCFullYear();
    var valueInThisCentury = Math.floor(thisYear / 100) * 100 + (0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseShort)(stripLeadingZeroes(value));
    if (valueInThisCentury < thisYear) {
        return valueInThisCentury + 100;
    }
    return valueInThisCentury;
};
var FIFTY_YEARS_IN_MILLIS = 50 * 365 * 24 * 60 * 60 * 1000;
var adjustRfc850Year = function (input) {
    if (input.getTime() - new Date().getTime() > FIFTY_YEARS_IN_MILLIS) {
        return new Date(Date.UTC(input.getUTCFullYear() - 100, input.getUTCMonth(), input.getUTCDate(), input.getUTCHours(), input.getUTCMinutes(), input.getUTCSeconds(), input.getUTCMilliseconds()));
    }
    return input;
};
var parseMonthByShortName = function (value) {
    var monthIdx = MONTHS.indexOf(value);
    if (monthIdx < 0) {
        throw new TypeError("Invalid month: ".concat(value));
    }
    return monthIdx + 1;
};
var DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
var validateDayOfMonth = function (year, month, day) {
    var maxDays = DAYS_IN_MONTH[month];
    if (month === 1 && isLeapYear(year)) {
        maxDays = 29;
    }
    if (day > maxDays) {
        throw new TypeError("Invalid day for ".concat(MONTHS[month], " in ").concat(year, ": ").concat(day));
    }
};
var isLeapYear = function (year) {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
};
var parseDateValue = function (value, type, lower, upper) {
    var dateVal = (0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseByte)(stripLeadingZeroes(value));
    if (dateVal < lower || dateVal > upper) {
        throw new TypeError("".concat(type, " must be between ").concat(lower, " and ").concat(upper, ", inclusive"));
    }
    return dateVal;
};
var parseMilliseconds = function (value) {
    if (value === null || value === undefined) {
        return 0;
    }
    return (0,_parse_utils__WEBPACK_IMPORTED_MODULE_0__.strictParseFloat32)("0." + value) * 1000;
};
var stripLeadingZeroes = function (value) {
    var idx = 0;
    while (idx < value.length - 1 && value.charAt(idx) === "0") {
        idx++;
    }
    if (idx === 0) {
        return value;
    }
    return value.slice(idx);
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/default-error-handler.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/default-error-handler.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "throwDefaultError": () => (/* binding */ throwDefaultError)
/* harmony export */ });
/* harmony import */ var _exceptions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./exceptions */ "./node_modules/@aws-sdk/smithy-client/dist-es/exceptions.js");

var throwDefaultError = function (_a) {
    var output = _a.output, parsedBody = _a.parsedBody, exceptionCtor = _a.exceptionCtor, errorCode = _a.errorCode;
    var $metadata = deserializeMetadata(output);
    var statusCode = $metadata.httpStatusCode ? $metadata.httpStatusCode + "" : undefined;
    var response = new exceptionCtor({
        name: parsedBody.code || parsedBody.Code || errorCode || statusCode || "UnknowError",
        $fault: "client",
        $metadata: $metadata,
    });
    throw (0,_exceptions__WEBPACK_IMPORTED_MODULE_0__.decorateServiceException)(response, parsedBody);
};
var deserializeMetadata = function (output) {
    var _a;
    return ({
        httpStatusCode: output.statusCode,
        requestId: (_a = output.headers["x-amzn-requestid"]) !== null && _a !== void 0 ? _a : output.headers["x-amzn-request-id"],
        extendedRequestId: output.headers["x-amz-id-2"],
        cfId: output.headers["x-amz-cf-id"],
    });
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/defaults-mode.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/defaults-mode.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadConfigsForDefaultMode": () => (/* binding */ loadConfigsForDefaultMode)
/* harmony export */ });
var loadConfigsForDefaultMode = function (mode) {
    switch (mode) {
        case "standard":
            return {
                retryMode: "standard",
                connectionTimeout: 3100,
            };
        case "in-region":
            return {
                retryMode: "standard",
                connectionTimeout: 1100,
            };
        case "cross-region":
            return {
                retryMode: "standard",
                connectionTimeout: 3100,
            };
        case "mobile":
            return {
                retryMode: "standard",
                connectionTimeout: 30000,
            };
        default:
            return {};
    }
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/emitWarningIfUnsupportedVersion.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/emitWarningIfUnsupportedVersion.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emitWarningIfUnsupportedVersion": () => (/* binding */ emitWarningIfUnsupportedVersion)
/* harmony export */ });
var warningEmitted = false;
var emitWarningIfUnsupportedVersion = function (version) {
    if (version && !warningEmitted && parseInt(version.substring(1, version.indexOf("."))) < 14) {
        warningEmitted = true;
        process.emitWarning("The AWS SDK for JavaScript (v3) will\n" +
            "no longer support Node.js ".concat(version, " on November 1, 2022.\n\n") +
            "To continue receiving updates to AWS services, bug fixes, and security\n" +
            "updates please upgrade to Node.js 14.x or later.\n\n" +
            "For details, please refer our blog post: https://a.co/48dbdYz", "NodeDeprecationWarning");
    }
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/exceptions.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/exceptions.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceException": () => (/* binding */ ServiceException),
/* harmony export */   "decorateServiceException": () => (/* binding */ decorateServiceException)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var ServiceException = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(ServiceException, _super);
    function ServiceException(options) {
        var _this = _super.call(this, options.message) || this;
        Object.setPrototypeOf(_this, ServiceException.prototype);
        _this.name = options.name;
        _this.$fault = options.$fault;
        _this.$metadata = options.$metadata;
        return _this;
    }
    return ServiceException;
}(Error));

var decorateServiceException = function (exception, additions) {
    if (additions === void 0) { additions = {}; }
    Object.entries(additions)
        .filter(function (_a) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), v = _b[1];
        return v !== undefined;
    })
        .forEach(function (_a) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), k = _b[0], v = _b[1];
        if (exception[k] == undefined || exception[k] === "") {
            exception[k] = v;
        }
    });
    var message = exception.message || exception.Message || "UnknownError";
    exception.message = message;
    delete exception.Message;
    return exception;
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/extended-encode-uri-component.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/extended-encode-uri-component.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "extendedEncodeURIComponent": () => (/* binding */ extendedEncodeURIComponent)
/* harmony export */ });
function extendedEncodeURIComponent(str) {
    return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
    });
}


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/get-array-if-single-item.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/get-array-if-single-item.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getArrayIfSingleItem": () => (/* binding */ getArrayIfSingleItem)
/* harmony export */ });
var getArrayIfSingleItem = function (mayBeArray) {
    return Array.isArray(mayBeArray) ? mayBeArray : [mayBeArray];
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/get-value-from-text-node.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/get-value-from-text-node.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getValueFromTextNode": () => (/* binding */ getValueFromTextNode)
/* harmony export */ });
var getValueFromTextNode = function (obj) {
    var textNodeName = "#text";
    for (var key in obj) {
        if (obj.hasOwnProperty(key) && obj[key][textNodeName] !== undefined) {
            obj[key] = obj[key][textNodeName];
        }
        else if (typeof obj[key] === "object" && obj[key] !== null) {
            obj[key] = getValueFromTextNode(obj[key]);
        }
    }
    return obj;
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/index.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Client": () => (/* reexport safe */ _client__WEBPACK_IMPORTED_MODULE_0__.Client),
/* harmony export */   "Command": () => (/* reexport safe */ _command__WEBPACK_IMPORTED_MODULE_1__.Command),
/* harmony export */   "LazyJsonString": () => (/* reexport safe */ _lazy_json__WEBPACK_IMPORTED_MODULE_11__.LazyJsonString),
/* harmony export */   "SENSITIVE_STRING": () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_2__.SENSITIVE_STRING),
/* harmony export */   "ServiceException": () => (/* reexport safe */ _exceptions__WEBPACK_IMPORTED_MODULE_7__.ServiceException),
/* harmony export */   "StringWrapper": () => (/* reexport safe */ _lazy_json__WEBPACK_IMPORTED_MODULE_11__.StringWrapper),
/* harmony export */   "convertMap": () => (/* reexport safe */ _object_mapping__WEBPACK_IMPORTED_MODULE_12__.convertMap),
/* harmony export */   "dateToUtcString": () => (/* reexport safe */ _date_utils__WEBPACK_IMPORTED_MODULE_3__.dateToUtcString),
/* harmony export */   "decorateServiceException": () => (/* reexport safe */ _exceptions__WEBPACK_IMPORTED_MODULE_7__.decorateServiceException),
/* harmony export */   "emitWarningIfUnsupportedVersion": () => (/* reexport safe */ _emitWarningIfUnsupportedVersion__WEBPACK_IMPORTED_MODULE_6__.emitWarningIfUnsupportedVersion),
/* harmony export */   "expectBoolean": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectBoolean),
/* harmony export */   "expectByte": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectByte),
/* harmony export */   "expectFloat32": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectFloat32),
/* harmony export */   "expectInt": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectInt),
/* harmony export */   "expectInt32": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectInt32),
/* harmony export */   "expectLong": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectLong),
/* harmony export */   "expectNonNull": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectNonNull),
/* harmony export */   "expectNumber": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectNumber),
/* harmony export */   "expectObject": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectObject),
/* harmony export */   "expectShort": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectShort),
/* harmony export */   "expectString": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectString),
/* harmony export */   "expectUnion": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.expectUnion),
/* harmony export */   "extendedEncodeURIComponent": () => (/* reexport safe */ _extended_encode_uri_component__WEBPACK_IMPORTED_MODULE_8__.extendedEncodeURIComponent),
/* harmony export */   "getArrayIfSingleItem": () => (/* reexport safe */ _get_array_if_single_item__WEBPACK_IMPORTED_MODULE_9__.getArrayIfSingleItem),
/* harmony export */   "getValueFromTextNode": () => (/* reexport safe */ _get_value_from_text_node__WEBPACK_IMPORTED_MODULE_10__.getValueFromTextNode),
/* harmony export */   "handleFloat": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.handleFloat),
/* harmony export */   "limitedParseDouble": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.limitedParseDouble),
/* harmony export */   "limitedParseFloat": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.limitedParseFloat),
/* harmony export */   "limitedParseFloat32": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.limitedParseFloat32),
/* harmony export */   "loadConfigsForDefaultMode": () => (/* reexport safe */ _defaults_mode__WEBPACK_IMPORTED_MODULE_5__.loadConfigsForDefaultMode),
/* harmony export */   "logger": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.logger),
/* harmony export */   "map": () => (/* reexport safe */ _object_mapping__WEBPACK_IMPORTED_MODULE_12__.map),
/* harmony export */   "parseBoolean": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.parseBoolean),
/* harmony export */   "parseEpochTimestamp": () => (/* reexport safe */ _date_utils__WEBPACK_IMPORTED_MODULE_3__.parseEpochTimestamp),
/* harmony export */   "parseRfc3339DateTime": () => (/* reexport safe */ _date_utils__WEBPACK_IMPORTED_MODULE_3__.parseRfc3339DateTime),
/* harmony export */   "parseRfc7231DateTime": () => (/* reexport safe */ _date_utils__WEBPACK_IMPORTED_MODULE_3__.parseRfc7231DateTime),
/* harmony export */   "resolvedPath": () => (/* reexport safe */ _resolve_path__WEBPACK_IMPORTED_MODULE_14__.resolvedPath),
/* harmony export */   "serializeFloat": () => (/* reexport safe */ _ser_utils__WEBPACK_IMPORTED_MODULE_15__.serializeFloat),
/* harmony export */   "splitEvery": () => (/* reexport safe */ _split_every__WEBPACK_IMPORTED_MODULE_16__.splitEvery),
/* harmony export */   "strictParseByte": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseByte),
/* harmony export */   "strictParseDouble": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseDouble),
/* harmony export */   "strictParseFloat": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseFloat),
/* harmony export */   "strictParseFloat32": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseFloat32),
/* harmony export */   "strictParseInt": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseInt),
/* harmony export */   "strictParseInt32": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseInt32),
/* harmony export */   "strictParseLong": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseLong),
/* harmony export */   "strictParseShort": () => (/* reexport safe */ _parse_utils__WEBPACK_IMPORTED_MODULE_13__.strictParseShort),
/* harmony export */   "throwDefaultError": () => (/* reexport safe */ _default_error_handler__WEBPACK_IMPORTED_MODULE_4__.throwDefaultError)
/* harmony export */ });
/* harmony import */ var _client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./client */ "./node_modules/@aws-sdk/smithy-client/dist-es/client.js");
/* harmony import */ var _command__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./command */ "./node_modules/@aws-sdk/smithy-client/dist-es/command.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./node_modules/@aws-sdk/smithy-client/dist-es/constants.js");
/* harmony import */ var _date_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./date-utils */ "./node_modules/@aws-sdk/smithy-client/dist-es/date-utils.js");
/* harmony import */ var _default_error_handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./default-error-handler */ "./node_modules/@aws-sdk/smithy-client/dist-es/default-error-handler.js");
/* harmony import */ var _defaults_mode__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./defaults-mode */ "./node_modules/@aws-sdk/smithy-client/dist-es/defaults-mode.js");
/* harmony import */ var _emitWarningIfUnsupportedVersion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./emitWarningIfUnsupportedVersion */ "./node_modules/@aws-sdk/smithy-client/dist-es/emitWarningIfUnsupportedVersion.js");
/* harmony import */ var _exceptions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./exceptions */ "./node_modules/@aws-sdk/smithy-client/dist-es/exceptions.js");
/* harmony import */ var _extended_encode_uri_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./extended-encode-uri-component */ "./node_modules/@aws-sdk/smithy-client/dist-es/extended-encode-uri-component.js");
/* harmony import */ var _get_array_if_single_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./get-array-if-single-item */ "./node_modules/@aws-sdk/smithy-client/dist-es/get-array-if-single-item.js");
/* harmony import */ var _get_value_from_text_node__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./get-value-from-text-node */ "./node_modules/@aws-sdk/smithy-client/dist-es/get-value-from-text-node.js");
/* harmony import */ var _lazy_json__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./lazy-json */ "./node_modules/@aws-sdk/smithy-client/dist-es/lazy-json.js");
/* harmony import */ var _object_mapping__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./object-mapping */ "./node_modules/@aws-sdk/smithy-client/dist-es/object-mapping.js");
/* harmony import */ var _parse_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./parse-utils */ "./node_modules/@aws-sdk/smithy-client/dist-es/parse-utils.js");
/* harmony import */ var _resolve_path__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./resolve-path */ "./node_modules/@aws-sdk/smithy-client/dist-es/resolve-path.js");
/* harmony import */ var _ser_utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ser-utils */ "./node_modules/@aws-sdk/smithy-client/dist-es/ser-utils.js");
/* harmony import */ var _split_every__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./split-every */ "./node_modules/@aws-sdk/smithy-client/dist-es/split-every.js");



















/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/lazy-json.js":
/*!******************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/lazy-json.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LazyJsonString": () => (/* binding */ LazyJsonString),
/* harmony export */   "StringWrapper": () => (/* binding */ StringWrapper)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var StringWrapper = function () {
    var Class = Object.getPrototypeOf(this).constructor;
    var Constructor = Function.bind.apply(String, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([null], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(arguments), false));
    var instance = new Constructor();
    Object.setPrototypeOf(instance, Class.prototype);
    return instance;
};
StringWrapper.prototype = Object.create(String.prototype, {
    constructor: {
        value: StringWrapper,
        enumerable: false,
        writable: true,
        configurable: true,
    },
});
Object.setPrototypeOf(StringWrapper, String);
var LazyJsonString = (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(LazyJsonString, _super);
    function LazyJsonString() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LazyJsonString.prototype.deserializeJSON = function () {
        return JSON.parse(_super.prototype.toString.call(this));
    };
    LazyJsonString.prototype.toJSON = function () {
        return _super.prototype.toString.call(this);
    };
    LazyJsonString.fromObject = function (object) {
        if (object instanceof LazyJsonString) {
            return object;
        }
        else if (object instanceof String || typeof object === "string") {
            return new LazyJsonString(object);
        }
        return new LazyJsonString(JSON.stringify(object));
    };
    return LazyJsonString;
}(StringWrapper));



/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/object-mapping.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/object-mapping.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertMap": () => (/* binding */ convertMap),
/* harmony export */   "map": () => (/* binding */ map)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

function map(arg0, arg1, arg2) {
    var e_1, _a;
    var target;
    var filter;
    var instructions;
    if (typeof arg1 === "undefined" && typeof arg2 === "undefined") {
        target = {};
        instructions = arg0;
    }
    else {
        target = arg0;
        if (typeof arg1 === "function") {
            filter = arg1;
            instructions = arg2;
            return mapWithFilter(target, filter, instructions);
        }
        else {
            instructions = arg1;
        }
    }
    try {
        for (var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(Object.keys(instructions)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var key = _c.value;
            if (!Array.isArray(instructions[key])) {
                target[key] = instructions[key];
                continue;
            }
            var _d = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(instructions[key], 2), filter_1 = _d[0], value = _d[1];
            if (typeof value === "function") {
                var _value = void 0;
                var defaultFilterPassed = filter_1 === undefined && (_value = value()) != null;
                var customFilterPassed = (typeof filter_1 === "function" && !!filter_1(void 0)) || (typeof filter_1 !== "function" && !!filter_1);
                if (defaultFilterPassed) {
                    target[key] = _value;
                }
                else if (customFilterPassed) {
                    target[key] = value();
                }
            }
            else {
                var defaultFilterPassed = filter_1 === undefined && value != null;
                var customFilterPassed = (typeof filter_1 === "function" && !!filter_1(value)) || (typeof filter_1 !== "function" && !!filter_1);
                if (defaultFilterPassed || customFilterPassed) {
                    target[key] = value;
                }
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return target;
}
var convertMap = function (target) {
    var e_2, _a;
    var output = {};
    try {
        for (var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(Object.entries(target || {})), _c = _b.next(); !_c.done; _c = _b.next()) {
            var _d = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_c.value, 2), k = _d[0], v = _d[1];
            output[k] = [, v];
        }
    }
    catch (e_2_1) { e_2 = { error: e_2_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_2) throw e_2.error; }
    }
    return output;
};
var mapWithFilter = function (target, filter, instructions) {
    return map(target, Object.entries(instructions).reduce(function (_instructions, _a) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _b[0], value = _b[1];
        if (Array.isArray(value)) {
            _instructions[key] = value;
        }
        else {
            if (typeof value === "function") {
                _instructions[key] = [filter, value()];
            }
            else {
                _instructions[key] = [filter, value];
            }
        }
        return _instructions;
    }, {}));
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/parse-utils.js":
/*!********************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/parse-utils.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "expectBoolean": () => (/* binding */ expectBoolean),
/* harmony export */   "expectByte": () => (/* binding */ expectByte),
/* harmony export */   "expectFloat32": () => (/* binding */ expectFloat32),
/* harmony export */   "expectInt": () => (/* binding */ expectInt),
/* harmony export */   "expectInt32": () => (/* binding */ expectInt32),
/* harmony export */   "expectLong": () => (/* binding */ expectLong),
/* harmony export */   "expectNonNull": () => (/* binding */ expectNonNull),
/* harmony export */   "expectNumber": () => (/* binding */ expectNumber),
/* harmony export */   "expectObject": () => (/* binding */ expectObject),
/* harmony export */   "expectShort": () => (/* binding */ expectShort),
/* harmony export */   "expectString": () => (/* binding */ expectString),
/* harmony export */   "expectUnion": () => (/* binding */ expectUnion),
/* harmony export */   "handleFloat": () => (/* binding */ handleFloat),
/* harmony export */   "limitedParseDouble": () => (/* binding */ limitedParseDouble),
/* harmony export */   "limitedParseFloat": () => (/* binding */ limitedParseFloat),
/* harmony export */   "limitedParseFloat32": () => (/* binding */ limitedParseFloat32),
/* harmony export */   "logger": () => (/* binding */ logger),
/* harmony export */   "parseBoolean": () => (/* binding */ parseBoolean),
/* harmony export */   "strictParseByte": () => (/* binding */ strictParseByte),
/* harmony export */   "strictParseDouble": () => (/* binding */ strictParseDouble),
/* harmony export */   "strictParseFloat": () => (/* binding */ strictParseFloat),
/* harmony export */   "strictParseFloat32": () => (/* binding */ strictParseFloat32),
/* harmony export */   "strictParseInt": () => (/* binding */ strictParseInt),
/* harmony export */   "strictParseInt32": () => (/* binding */ strictParseInt32),
/* harmony export */   "strictParseLong": () => (/* binding */ strictParseLong),
/* harmony export */   "strictParseShort": () => (/* binding */ strictParseShort)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var parseBoolean = function (value) {
    switch (value) {
        case "true":
            return true;
        case "false":
            return false;
        default:
            throw new Error("Unable to parse boolean value \"".concat(value, "\""));
    }
};
var expectBoolean = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "number") {
        if (value === 0 || value === 1) {
            logger.warn(stackTraceWarning("Expected boolean, got ".concat(typeof value, ": ").concat(value)));
        }
        if (value === 0) {
            return false;
        }
        if (value === 1) {
            return true;
        }
    }
    if (typeof value === "string") {
        var lower = value.toLowerCase();
        if (lower === "false" || lower === "true") {
            logger.warn(stackTraceWarning("Expected boolean, got ".concat(typeof value, ": ").concat(value)));
        }
        if (lower === "false") {
            return false;
        }
        if (lower === "true") {
            return true;
        }
    }
    if (typeof value === "boolean") {
        return value;
    }
    throw new TypeError("Expected boolean, got ".concat(typeof value, ": ").concat(value));
};
var expectNumber = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "string") {
        var parsed = parseFloat(value);
        if (!Number.isNaN(parsed)) {
            if (String(parsed) !== String(value)) {
                logger.warn(stackTraceWarning("Expected number but observed string: ".concat(value)));
            }
            return parsed;
        }
    }
    if (typeof value === "number") {
        return value;
    }
    throw new TypeError("Expected number, got ".concat(typeof value, ": ").concat(value));
};
var MAX_FLOAT = Math.ceil(Math.pow(2, 127) * (2 - Math.pow(2, -23)));
var expectFloat32 = function (value) {
    var expected = expectNumber(value);
    if (expected !== undefined && !Number.isNaN(expected) && expected !== Infinity && expected !== -Infinity) {
        if (Math.abs(expected) > MAX_FLOAT) {
            throw new TypeError("Expected 32-bit float, got ".concat(value));
        }
    }
    return expected;
};
var expectLong = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (Number.isInteger(value) && !Number.isNaN(value)) {
        return value;
    }
    throw new TypeError("Expected integer, got ".concat(typeof value, ": ").concat(value));
};
var expectInt = expectLong;
var expectInt32 = function (value) { return expectSizedInt(value, 32); };
var expectShort = function (value) { return expectSizedInt(value, 16); };
var expectByte = function (value) { return expectSizedInt(value, 8); };
var expectSizedInt = function (value, size) {
    var expected = expectLong(value);
    if (expected !== undefined && castInt(expected, size) !== expected) {
        throw new TypeError("Expected ".concat(size, "-bit integer, got ").concat(value));
    }
    return expected;
};
var castInt = function (value, size) {
    switch (size) {
        case 32:
            return Int32Array.of(value)[0];
        case 16:
            return Int16Array.of(value)[0];
        case 8:
            return Int8Array.of(value)[0];
    }
};
var expectNonNull = function (value, location) {
    if (value === null || value === undefined) {
        if (location) {
            throw new TypeError("Expected a non-null value for ".concat(location));
        }
        throw new TypeError("Expected a non-null value");
    }
    return value;
};
var expectObject = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "object" && !Array.isArray(value)) {
        return value;
    }
    var receivedType = Array.isArray(value) ? "array" : typeof value;
    throw new TypeError("Expected object, got ".concat(receivedType, ": ").concat(value));
};
var expectString = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    if (typeof value === "string") {
        return value;
    }
    if (["boolean", "number", "bigint"].includes(typeof value)) {
        logger.warn(stackTraceWarning("Expected string, got ".concat(typeof value, ": ").concat(value)));
        return String(value);
    }
    throw new TypeError("Expected string, got ".concat(typeof value, ": ").concat(value));
};
var expectUnion = function (value) {
    if (value === null || value === undefined) {
        return undefined;
    }
    var asObject = expectObject(value);
    var setKeys = Object.entries(asObject)
        .filter(function (_a) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), v = _b[1];
        return v != null;
    })
        .map(function (_a) {
        var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 1), k = _b[0];
        return k;
    });
    if (setKeys.length === 0) {
        throw new TypeError("Unions must have exactly one non-null member. None were found.");
    }
    if (setKeys.length > 1) {
        throw new TypeError("Unions must have exactly one non-null member. Keys ".concat(setKeys, " were not null."));
    }
    return asObject;
};
var strictParseDouble = function (value) {
    if (typeof value == "string") {
        return expectNumber(parseNumber(value));
    }
    return expectNumber(value);
};
var strictParseFloat = strictParseDouble;
var strictParseFloat32 = function (value) {
    if (typeof value == "string") {
        return expectFloat32(parseNumber(value));
    }
    return expectFloat32(value);
};
var NUMBER_REGEX = /(-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)|(-?Infinity)|(NaN)/g;
var parseNumber = function (value) {
    var matches = value.match(NUMBER_REGEX);
    if (matches === null || matches[0].length !== value.length) {
        throw new TypeError("Expected real number, got implicit NaN");
    }
    return parseFloat(value);
};
var limitedParseDouble = function (value) {
    if (typeof value == "string") {
        return parseFloatString(value);
    }
    return expectNumber(value);
};
var handleFloat = limitedParseDouble;
var limitedParseFloat = limitedParseDouble;
var limitedParseFloat32 = function (value) {
    if (typeof value == "string") {
        return parseFloatString(value);
    }
    return expectFloat32(value);
};
var parseFloatString = function (value) {
    switch (value) {
        case "NaN":
            return NaN;
        case "Infinity":
            return Infinity;
        case "-Infinity":
            return -Infinity;
        default:
            throw new Error("Unable to parse float value: ".concat(value));
    }
};
var strictParseLong = function (value) {
    if (typeof value === "string") {
        return expectLong(parseNumber(value));
    }
    return expectLong(value);
};
var strictParseInt = strictParseLong;
var strictParseInt32 = function (value) {
    if (typeof value === "string") {
        return expectInt32(parseNumber(value));
    }
    return expectInt32(value);
};
var strictParseShort = function (value) {
    if (typeof value === "string") {
        return expectShort(parseNumber(value));
    }
    return expectShort(value);
};
var strictParseByte = function (value) {
    if (typeof value === "string") {
        return expectByte(parseNumber(value));
    }
    return expectByte(value);
};
var stackTraceWarning = function (message) {
    return String(new TypeError(message).stack || message)
        .split("\n")
        .slice(0, 5)
        .filter(function (s) { return !s.includes("stackTraceWarning"); })
        .join("\n");
};
var logger = {
    warn: console.warn,
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/resolve-path.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/resolve-path.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "resolvedPath": () => (/* binding */ resolvedPath)
/* harmony export */ });
/* harmony import */ var _extended_encode_uri_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./extended-encode-uri-component */ "./node_modules/@aws-sdk/smithy-client/dist-es/extended-encode-uri-component.js");

var resolvedPath = function (resolvedPath, input, memberName, labelValueProvider, uriLabel, isGreedyLabel) {
    if (input != null && input[memberName] !== undefined) {
        var labelValue = labelValueProvider();
        if (labelValue.length <= 0) {
            throw new Error("Empty value provided for input HTTP label: " + memberName + ".");
        }
        resolvedPath = resolvedPath.replace(uriLabel, isGreedyLabel
            ? labelValue
                .split("/")
                .map(function (segment) { return (0,_extended_encode_uri_component__WEBPACK_IMPORTED_MODULE_0__.extendedEncodeURIComponent)(segment); })
                .join("/")
            : (0,_extended_encode_uri_component__WEBPACK_IMPORTED_MODULE_0__.extendedEncodeURIComponent)(labelValue));
    }
    else {
        throw new Error("No value provided for input HTTP label: " + memberName + ".");
    }
    return resolvedPath;
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/ser-utils.js":
/*!******************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/ser-utils.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "serializeFloat": () => (/* binding */ serializeFloat)
/* harmony export */ });
var serializeFloat = function (value) {
    if (value !== value) {
        return "NaN";
    }
    switch (value) {
        case Infinity:
            return "Infinity";
        case -Infinity:
            return "-Infinity";
        default:
            return value;
    }
};


/***/ }),

/***/ "./node_modules/@aws-sdk/smithy-client/dist-es/split-every.js":
/*!********************************************************************!*\
  !*** ./node_modules/@aws-sdk/smithy-client/dist-es/split-every.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "splitEvery": () => (/* binding */ splitEvery)
/* harmony export */ });
function splitEvery(value, delimiter, numDelimiters) {
    if (numDelimiters <= 0 || !Number.isInteger(numDelimiters)) {
        throw new Error("Invalid number of delimiters (" + numDelimiters + ") for splitEvery.");
    }
    var segments = value.split(delimiter);
    if (numDelimiters === 1) {
        return segments;
    }
    var compoundSegments = [];
    var currentSegment = "";
    for (var i = 0; i < segments.length; i++) {
        if (currentSegment === "") {
            currentSegment = segments[i];
        }
        else {
            currentSegment += delimiter + segments[i];
        }
        if ((i + 1) % numDelimiters === 0) {
            compoundSegments.push(currentSegment);
            currentSegment = "";
        }
    }
    if (currentSegment !== "") {
        compoundSegments.push(currentSegment);
    }
    return compoundSegments;
}


/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToAttr.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToAttr.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertToAttr": () => (/* binding */ convertToAttr)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var convertToAttr = function (data, options) {
    var _a, _b, _c, _d, _e, _f;
    if (data === undefined) {
        throw new Error("Pass options.removeUndefinedValues=true to remove undefined values from map/array/set.");
    }
    else if (data === null && typeof data === "object") {
        return convertToNullAttr();
    }
    else if (Array.isArray(data)) {
        return convertToListAttr(data, options);
    }
    else if (((_a = data === null || data === void 0 ? void 0 : data.constructor) === null || _a === void 0 ? void 0 : _a.name) === "Set") {
        return convertToSetAttr(data, options);
    }
    else if (((_b = data === null || data === void 0 ? void 0 : data.constructor) === null || _b === void 0 ? void 0 : _b.name) === "Map") {
        return convertToMapAttrFromIterable(data, options);
    }
    else if (((_c = data === null || data === void 0 ? void 0 : data.constructor) === null || _c === void 0 ? void 0 : _c.name) === "Object" ||
        (!data.constructor && typeof data === "object")) {
        return convertToMapAttrFromEnumerableProps(data, options);
    }
    else if (isBinary(data)) {
        if (data.length === 0 && (options === null || options === void 0 ? void 0 : options.convertEmptyValues)) {
            return convertToNullAttr();
        }
        return convertToBinaryAttr(data);
    }
    else if (typeof data === "boolean" || ((_d = data === null || data === void 0 ? void 0 : data.constructor) === null || _d === void 0 ? void 0 : _d.name) === "Boolean") {
        return { BOOL: data.valueOf() };
    }
    else if (typeof data === "number" || ((_e = data === null || data === void 0 ? void 0 : data.constructor) === null || _e === void 0 ? void 0 : _e.name) === "Number") {
        return convertToNumberAttr(data);
    }
    else if (typeof data === "bigint") {
        return convertToBigIntAttr(data);
    }
    else if (typeof data === "string" || ((_f = data === null || data === void 0 ? void 0 : data.constructor) === null || _f === void 0 ? void 0 : _f.name) === "String") {
        if (data.length === 0 && (options === null || options === void 0 ? void 0 : options.convertEmptyValues)) {
            return convertToNullAttr();
        }
        return convertToStringAttr(data);
    }
    else if ((options === null || options === void 0 ? void 0 : options.convertClassInstanceToMap) && typeof data === "object") {
        return convertToMapAttrFromEnumerableProps(data, options);
    }
    throw new Error("Unsupported type passed: ".concat(data, ". Pass options.convertClassInstanceToMap=true to marshall typeof object as map attribute."));
};
var convertToListAttr = function (data, options) { return ({
    L: data
        .filter(function (item) { return !(options === null || options === void 0 ? void 0 : options.removeUndefinedValues) || ((options === null || options === void 0 ? void 0 : options.removeUndefinedValues) && item !== undefined); })
        .map(function (item) { return convertToAttr(item, options); }),
}); };
var convertToSetAttr = function (set, options) {
    var setToOperate = (options === null || options === void 0 ? void 0 : options.removeUndefinedValues) ? new Set((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(set), false).filter(function (value) { return value !== undefined; })) : set;
    if (!(options === null || options === void 0 ? void 0 : options.removeUndefinedValues) && setToOperate.has(undefined)) {
        throw new Error("Pass options.removeUndefinedValues=true to remove undefined values from map/array/set.");
    }
    if (setToOperate.size === 0) {
        if (options === null || options === void 0 ? void 0 : options.convertEmptyValues) {
            return convertToNullAttr();
        }
        throw new Error("Pass a non-empty set, or options.convertEmptyValues=true.");
    }
    var item = setToOperate.values().next().value;
    if (typeof item === "number") {
        return {
            NS: Array.from(setToOperate)
                .map(convertToNumberAttr)
                .map(function (item) { return item.N; }),
        };
    }
    else if (typeof item === "bigint") {
        return {
            NS: Array.from(setToOperate)
                .map(convertToBigIntAttr)
                .map(function (item) { return item.N; }),
        };
    }
    else if (typeof item === "string") {
        return {
            SS: Array.from(setToOperate)
                .map(convertToStringAttr)
                .map(function (item) { return item.S; }),
        };
    }
    else if (isBinary(item)) {
        return {
            BS: Array.from(setToOperate)
                .map(convertToBinaryAttr)
                .map(function (item) { return item.B; }),
        };
    }
    else {
        throw new Error("Only Number Set (NS), Binary Set (BS) or String Set (SS) are allowed.");
    }
};
var convertToMapAttrFromIterable = function (data, options) { return ({
    M: (function (data) {
        var e_1, _a;
        var map = {};
        try {
            for (var data_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(data), data_1_1 = data_1.next(); !data_1_1.done; data_1_1 = data_1.next()) {
                var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(data_1_1.value, 2), key = _b[0], value = _b[1];
                if (typeof value !== "function" && (value !== undefined || !(options === null || options === void 0 ? void 0 : options.removeUndefinedValues))) {
                    map[key] = convertToAttr(value, options);
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (data_1_1 && !data_1_1.done && (_a = data_1.return)) _a.call(data_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return map;
    })(data),
}); };
var convertToMapAttrFromEnumerableProps = function (data, options) { return ({
    M: (function (data) {
        var map = {};
        for (var key in data) {
            var value = data[key];
            if (typeof value !== "function" && (value !== undefined || !(options === null || options === void 0 ? void 0 : options.removeUndefinedValues))) {
                map[key] = convertToAttr(value, options);
            }
        }
        return map;
    })(data),
}); };
var convertToNullAttr = function () { return ({ NULL: true }); };
var convertToBinaryAttr = function (data) { return ({ B: data }); };
var convertToStringAttr = function (data) { return ({ S: data.toString() }); };
var convertToBigIntAttr = function (data) { return ({ N: data.toString() }); };
var validateBigIntAndThrow = function (errorPrefix) {
    throw new Error("".concat(errorPrefix, " ").concat(typeof BigInt === "function" ? "Use BigInt." : "Pass string value instead.", " "));
};
var convertToNumberAttr = function (num) {
    if ([Number.NaN, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY]
        .map(function (val) { return val.toString(); })
        .includes(num.toString())) {
        throw new Error("Special numeric value ".concat(num.toString(), " is not allowed"));
    }
    else if (num > Number.MAX_SAFE_INTEGER) {
        validateBigIntAndThrow("Number ".concat(num.toString(), " is greater than Number.MAX_SAFE_INTEGER."));
    }
    else if (num < Number.MIN_SAFE_INTEGER) {
        validateBigIntAndThrow("Number ".concat(num.toString(), " is lesser than Number.MIN_SAFE_INTEGER."));
    }
    return { N: num.toString() };
};
var isBinary = function (data) {
    var binaryTypes = [
        "ArrayBuffer",
        "Blob",
        "Buffer",
        "DataView",
        "File",
        "Int8Array",
        "Uint8Array",
        "Uint8ClampedArray",
        "Int16Array",
        "Uint16Array",
        "Int32Array",
        "Uint32Array",
        "Float32Array",
        "Float64Array",
        "BigInt64Array",
        "BigUint64Array",
    ];
    if (data === null || data === void 0 ? void 0 : data.constructor) {
        return binaryTypes.includes(data.constructor.name);
    }
    return false;
};


/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToNative.js":
/*!************************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToNative.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertToNative": () => (/* binding */ convertToNative)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

var convertToNative = function (data, options) {
    var e_1, _a;
    try {
        for (var _b = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(Object.entries(data)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var _d = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_c.value, 2), key = _d[0], value = _d[1];
            if (value !== undefined) {
                switch (key) {
                    case "NULL":
                        return null;
                    case "BOOL":
                        return Boolean(value);
                    case "N":
                        return convertNumber(value, options);
                    case "B":
                        return convertBinary(value);
                    case "S":
                        return convertString(value);
                    case "L":
                        return convertList(value, options);
                    case "M":
                        return convertMap(value, options);
                    case "NS":
                        return new Set(value.map(function (item) { return convertNumber(item, options); }));
                    case "BS":
                        return new Set(value.map(convertBinary));
                    case "SS":
                        return new Set(value.map(convertString));
                    default:
                        throw new Error("Unsupported type passed: ".concat(key));
                }
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    throw new Error("No value defined: ".concat(JSON.stringify(data)));
};
var convertNumber = function (numString, options) {
    if (options === null || options === void 0 ? void 0 : options.wrapNumbers) {
        return { value: numString };
    }
    var num = Number(numString);
    var infinityValues = [Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY];
    if ((num > Number.MAX_SAFE_INTEGER || num < Number.MIN_SAFE_INTEGER) && !infinityValues.includes(num)) {
        if (typeof BigInt === "function") {
            try {
                return BigInt(numString);
            }
            catch (error) {
                throw new Error("".concat(numString, " can't be converted to BigInt. Set options.wrapNumbers to get string value."));
            }
        }
        else {
            throw new Error("".concat(numString, " is outside SAFE_INTEGER bounds. Set options.wrapNumbers to get string value."));
        }
    }
    return num;
};
var convertString = function (stringValue) { return stringValue; };
var convertBinary = function (binaryValue) { return binaryValue; };
var convertList = function (list, options) {
    return list.map(function (item) { return convertToNative(item, options); });
};
var convertMap = function (map, options) {
    return Object.entries(map).reduce(function (acc, _a) {
        var _b;
        var _c = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(_a, 2), key = _c[0], value = _c[1];
        return ((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, acc), (_b = {}, _b[key] = convertToNative(value, options), _b)));
    }, {});
};


/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/index.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertToAttr": () => (/* reexport safe */ _convertToAttr__WEBPACK_IMPORTED_MODULE_0__.convertToAttr),
/* harmony export */   "convertToNative": () => (/* reexport safe */ _convertToNative__WEBPACK_IMPORTED_MODULE_1__.convertToNative),
/* harmony export */   "marshall": () => (/* reexport safe */ _marshall__WEBPACK_IMPORTED_MODULE_2__.marshall),
/* harmony export */   "unmarshall": () => (/* reexport safe */ _unmarshall__WEBPACK_IMPORTED_MODULE_4__.unmarshall)
/* harmony export */ });
/* harmony import */ var _convertToAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./convertToAttr */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToAttr.js");
/* harmony import */ var _convertToNative__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./convertToNative */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToNative.js");
/* harmony import */ var _marshall__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./marshall */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/marshall.js");
/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./models */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/models.js");
/* harmony import */ var _unmarshall__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./unmarshall */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/unmarshall.js");







/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/marshall.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/marshall.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "marshall": () => (/* binding */ marshall)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _convertToAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./convertToAttr */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToAttr.js");


function marshall(data, options) {
    var attributeValue = (0,_convertToAttr__WEBPACK_IMPORTED_MODULE_0__.convertToAttr)(data, options);
    var _a = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__read)(Object.entries(attributeValue)[0], 2), key = _a[0], value = _a[1];
    switch (key) {
        case "M":
        case "L":
            return value;
        case "SS":
        case "NS":
        case "BS":
        case "S":
        case "N":
        case "B":
        case "NULL":
        case "BOOL":
        case "$unknown":
        default:
            return attributeValue;
    }
}


/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/models.js":
/*!***************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/models.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./node_modules/@aws-sdk/util-dynamodb/dist-es/unmarshall.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@aws-sdk/util-dynamodb/dist-es/unmarshall.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "unmarshall": () => (/* binding */ unmarshall)
/* harmony export */ });
/* harmony import */ var _convertToNative__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./convertToNative */ "./node_modules/@aws-sdk/util-dynamodb/dist-es/convertToNative.js");

var unmarshall = function (data, options) {
    return (0,_convertToNative__WEBPACK_IMPORTED_MODULE_0__.convertToNative)({ M: data }, options);
};


/***/ }),

/***/ "./src/lambdas/todo/update.ts":
/*!************************************!*\
  !*** ./src/lambdas/todo/update.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.handler = void 0;
const lib_dynamodb_1 = __webpack_require__(/*! @aws-sdk/lib-dynamodb */ "./node_modules/@aws-sdk/lib-dynamodb/dist-es/index.js");
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    const { body } = event.pathParameters;
    const updateOne = new lib_dynamodb_1.UpdateCommand({
        TableName: process.env.TODO_TABLE,
        Key: Object.assign({}, body),
    });
});
exports.handler = handler;


/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__assign": () => (/* binding */ __assign),
/* harmony export */   "__asyncDelegator": () => (/* binding */ __asyncDelegator),
/* harmony export */   "__asyncGenerator": () => (/* binding */ __asyncGenerator),
/* harmony export */   "__asyncValues": () => (/* binding */ __asyncValues),
/* harmony export */   "__await": () => (/* binding */ __await),
/* harmony export */   "__awaiter": () => (/* binding */ __awaiter),
/* harmony export */   "__classPrivateFieldGet": () => (/* binding */ __classPrivateFieldGet),
/* harmony export */   "__classPrivateFieldIn": () => (/* binding */ __classPrivateFieldIn),
/* harmony export */   "__classPrivateFieldSet": () => (/* binding */ __classPrivateFieldSet),
/* harmony export */   "__createBinding": () => (/* binding */ __createBinding),
/* harmony export */   "__decorate": () => (/* binding */ __decorate),
/* harmony export */   "__exportStar": () => (/* binding */ __exportStar),
/* harmony export */   "__extends": () => (/* binding */ __extends),
/* harmony export */   "__generator": () => (/* binding */ __generator),
/* harmony export */   "__importDefault": () => (/* binding */ __importDefault),
/* harmony export */   "__importStar": () => (/* binding */ __importStar),
/* harmony export */   "__makeTemplateObject": () => (/* binding */ __makeTemplateObject),
/* harmony export */   "__metadata": () => (/* binding */ __metadata),
/* harmony export */   "__param": () => (/* binding */ __param),
/* harmony export */   "__read": () => (/* binding */ __read),
/* harmony export */   "__rest": () => (/* binding */ __rest),
/* harmony export */   "__spread": () => (/* binding */ __spread),
/* harmony export */   "__spreadArray": () => (/* binding */ __spreadArray),
/* harmony export */   "__spreadArrays": () => (/* binding */ __spreadArrays),
/* harmony export */   "__values": () => (/* binding */ __values)
/* harmony export */ });
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}


/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/lambdas/todo/update.ts");
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=update.js.map